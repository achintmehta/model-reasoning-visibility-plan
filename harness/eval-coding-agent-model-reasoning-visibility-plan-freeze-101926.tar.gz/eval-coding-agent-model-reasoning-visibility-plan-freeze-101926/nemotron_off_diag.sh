#!/usr/bin/env bash
# nemotron_off_diag.sh -- DIAGNOSTIC. Not part of any smoke set, and never part of the grid.
# Nemotron was RETIRED in plan v2.5.1 on the evidence this script produced (§5); the script
# is kept so its runs can be re-made.
#
# The question: with thinking OFF, how often does Nemotron-3-Nano abandon the tool-call format
# its template declares and write its own JSON agent protocol instead -- {"analysis", "plan",
# "commands": [{"tool": ..., "arguments": ...}], "task_complete"} and variants? In the
# 2026-09-25 smoke, 2 of 3 OFF runs did, from step 1, and repeated it after the nudge; the
# third used native tool calls on all 34 steps. Three runs cannot say whether the OFF arm is
# usable, so this runs more OFF-only runs -- fresh seeds, both tasks, all three conditions --
# and classifies every reply.
#
# It changes nothing. It calls run_one_with_server.sh exactly as the batch driver does
# (ARM=off, BLIND=0), writes to its OWN root so these runs can never mix with a certified
# smoke set, and copies only the logs -- not the app/ trees -- to D: for reading.
#
# Usage (after any running batch has finished -- the wrapper serves one model at a time):
#   ./nemotron_off_diag.sh                 # 2 runs per task x condition = 12 runs
#   REPS=3 ./nemotron_off_diag.sh          # 18 runs
#   SUMMARY_ONLY=1 ./nemotron_off_diag.sh  # just re-print the table from the copied logs
# Resumable: a run whose manifest already exists is skipped, so Ctrl-C and re-run is safe.
set -uo pipefail
cd "$(dirname "$0")"

MODEL=nemotron-q4
REPS="${REPS:-2}"
ROOT="${DIAG_ROOT:-/tmp/runs/diagnostics/nemotron-off}"
COPY_TO="${DIAG_COPY_TO:-/mnt/d/thinking_research_runs/diagnostics/nemotron-off}"
TASKS=(message-board kanban-board)
CONDITIONS=(no_verification execution interactive)
say() { printf '[%s] %s\n' "$(date '+%H:%M:%S')" "$*"; }

if [ -z "${SUMMARY_ONLY:-}" ]; then
  # plan v2.5.13: the batch driver was renamed from run_quantization_batch.sh.
  if pgrep -f run_thinking_batch.sh >/dev/null 2>&1; then
    say "a batch (run_thinking_batch.sh) is still running -- start this after it finishes"; exit 1
  fi
  if tasklist.exe 2>/dev/null | grep -qi 'llama-server'; then
    say "llama-server.exe is already running -- let its batch finish (or stop it) first"; exit 1
  fi

  total=$(( ${#TASKS[@]} * ${#CONDITIONS[@]} * REPS )); n=0
  # Repetition is the OUTER loop, so an interrupted batch still covers every cell evenly.
  for rep in $(seq 1 "$REPS"); do
    id=$(printf '1%02d' $((rep + 1)))     # 102, 103, ... -> seeds 2, 3, ...; the smoke used 101 (seed 1)
    for task in "${TASKS[@]}"; do
      for cond in "${CONDITIONS[@]}"; do
        n=$((n + 1))
        if [ -f "$ROOT/$task/$cond/runs/$id/smoke/logs/manifest.json" ]; then
          say "[$n/$total] $task/$cond/$id already done -- skipped"; continue
        fi
        say "[$n/$total] OFF  $task / $cond  run $id"
        ARM=off BLIND=0 OUTPUT_ROOT="$ROOT" ./run_one_with_server.sh "$MODEL" "$task" "$cond" "$id" </dev/null \
          || say "  the wrapper returned non-zero (an infrastructure fault, not an outcome) -- continuing"
      done
    done
  done

  say "copying logs (not the app/ trees) to $COPY_TO"
  for d in "$ROOT"/*/*/runs/*/smoke; do
    [ -d "$d" ] || continue
    rel="${d#"$ROOT"/}"
    mkdir -p "$COPY_TO/$rel" && cp -r "$d/." "$COPY_TO/$rel/"
  done
fi

COPY_TO="$COPY_TO" python3 - <<'PY'
import glob, io, json, os, re
root = os.environ["COPY_TO"]
# Keys of the agent-protocol JSON seen in the smoke. A reply is "drift" when it carries NO
# parsed tool call and its text is a JSON object built from these keys.
# "action" added 2026-09-25: the third dialect, {"action": ..., "args": {...}} after a line of
# prose in a ```json fence, was being counted as "other" (kanban-board/execution/103).
KEYS = {"commands", "analysis", "plan", "task_complete", "is_task_complete", "thoughts", "keystrokes",
        "action"}

def kind(resp):
    if resp.get("tool_calls"):
        return "native"
    text = ((resp.get("raw") or {}).get("content") or "").strip()
    body = re.sub(r"```(?:json)?", "", text)
    i = body.find("{")
    if i >= 0:
        try:
            obj, _ = json.JSONDecoder().raw_decode(body[i:])
            if isinstance(obj, dict) and KEYS & set(obj):
                return "drift"
        except ValueError:
            if any(f'"{k}"' in body for k in ("commands", "task_complete", "is_task_complete")):
                return "drift"
    return "other"

rows = []
for m in sorted(glob.glob(f"{root}/*/*/runs/*/smoke/logs/manifest.json")):
    d = json.load(open(m, encoding="utf-8"))
    kinds = []
    for line in io.open(os.path.join(os.path.dirname(m), "trace.jsonl"), encoding="utf-8", errors="replace"):
        if '"response"' not in line:
            continue
        try:
            r = json.loads(line)
        except ValueError:
            continue
        if r.get("kind") == "response":
            kinds.append(kind(r))
    rel = m[len(root) + 1:].split("/smoke/")[0]
    rows.append((rel, d.get("status"), d.get("steps"), kinds))

if not rows:
    print(f"\nno runs under {root}")
    raise SystemExit(0)
print(f"\n  {'run':44} {'status':24} {'steps':>5}  first   native drift other")
for rel, st, steps, k in rows:
    print(f"  {rel:44} {str(st):24} {steps:5}  {k[0] if k else '-':7} {k.count('native'):6} {k.count('drift'):5} {k.count('other'):5}")
n = len(rows)
any_drift = sum(1 for r in rows if "drift" in r[3])
first_drift = sum(1 for r in rows if r[3] and r[3][0] == "drift")
finished = sum(1 for r in rows if r[1] == "finished")
print(f"\n  {n} runs: finished {finished}/{n}; drifted at step 1 in {first_drift}/{n}; "
      f"drifted at any step in {any_drift}/{n}")
PY
