"""Batch runner: one frozen task, swept across conditions and replicates.

This implements the 'freeze then apply' protocol: you point it at ONE task prompt and
ONE model, and it runs the agent under each requested condition, N times each, into a
clean workspace per run with full logs. The task prompt is held byte-identical across
every run; only the condition (tool set) varies.

Example (LM Studio, local):
  python3 run_matrix.py \
      --task-file tasks/T1_retro_board.txt \
      --model qwen2.5-coder-32b-instruct \
      --conditions none execution behavioral static \
      --replicates 5 \
      --out runs/T1

Switch to OpenRouter by adding:
      --base-url https://openrouter.ai/api/v1 --api-key sk-or-...
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from harness.llm import DECODING_DEFAULTS


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task-file", required=True)
    ap.add_argument("--model", required=True)
    ap.add_argument("--conditions", nargs="+", required=True)
    ap.add_argument("--replicates", type=int, default=5)
    ap.add_argument("--out", required=True, help="root dir for this task's runs")
    ap.add_argument("--base-url", default="http://localhost:1234/v1")
    ap.add_argument("--api-key", default="lm-studio")
    ap.add_argument("--temperature", type=float,
                    default=DECODING_DEFAULTS["temperature"],
                    help="defaults to the study registry (harness/llm.py); overrides "
                         "are stamped decoding_overridden in every manifest")
    ap.add_argument("--top-p", type=float, default=DECODING_DEFAULTS["top_p"])
    ap.add_argument("--max-tokens", type=int, default=DECODING_DEFAULTS["max_tokens"],
                    help="per-turn token cap, passed through to the agent; defaults to "
                         "the study registry (harness/llm.py)")
    ap.add_argument("--max-steps", type=int, default=40)
    ap.add_argument("--max-total-tokens", type=int, default=3_000_000,
                    help="per-run total token budget (0 = unlimited). Default 3M: bounds "
                         "runaway runs (one was observed >10M tokens) and makes cost "
                         "comparable across conditions.")
    ap.add_argument("--seed", type=int, default=None,
                    help="sampling seed recorded in every manifest (best-effort per provider)")
    ap.add_argument("--seed-workspace", default=None,
                    help="starter codebase dir copied into each run's workspace "
                         "(brownfield tasks)")
    ap.add_argument("--no-briefing", action="store_true",
                    help="briefing-ablation sweep: run every cell without condition "
                         "briefings (recorded in manifests)")
    ap.add_argument("--test-cmd", default="npm test")
    ap.add_argument("--interactive", action="store_true",
                    help="Pause and prompt the user instead of exiting when the agent "
                         "finishes. WARNING: interactive runs accept human feedback and "
                         "are NOT valid autonomous data points; they are flagged "
                         "interactive=true in the manifest and should be excluded from "
                         "analysis.")
    args = ap.parse_args()

    if args.interactive:
        print("WARNING: --interactive runs are human-contaminated and will be flagged "
              "in manifests. Do not mix them into the study data.")

    task_name = Path(args.task_file).stem
    model_tag = args.model.replace("/", "_").replace(":", "_")
    out_root = Path(args.out)

    for cond in args.conditions:
        for rep in range(1, args.replicates + 1):
            run_id = f"{task_name}__{model_tag}__{cond}__r{rep}"
            ws = out_root / run_id / "workspace"
            run_dir = out_root / run_id / "logs"
            print(f">>> {run_id}")
           