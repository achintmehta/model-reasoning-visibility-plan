"""Verification of the file-state history note on write_file and edit_file (plan v2.5.13).

Run:  python3 test_file_history.py

When a write or edit call leaves a file with bytes that an earlier write or edit call of the
run had left it with, the tool result says how many such calls there have now been and how
many tool calls ago the previous one was:

    NOTE: <y> write or edit calls in this run, this one included, have left <path> with
    exactly this content; the previous one was <x> calls ago.

Part 1 drives Tools directly, setting call_index by hand the way the agent loop does.
Part 2 drives run_agent with a scripted client, to pin how calls are counted: every call
dispatched to a result, refused and malformed ones included, several per step.

No model, no network, no browser - just Tools against a temp workspace.
"""
import re
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from harness.agent import run_agent, build_messages
from harness.llm import ToolCall, Turn
from harness.runlog import RunLog
from harness.tools import Tools

FAILURES = []


def check(name, cond, detail=""):
    print(f"[{'ok ' if cond else 'FAIL'}] {name}" + (f"  -- {detail}" if not cond else ""))
    if not cond:
        FAILURES.append(name)


HIST = re.compile(r"NOTE: (\d+) write or edit calls in this run, this one included, have "
                  r"left (\S+) with exactly this content"
                  r"(?:; the previous one was (\d+) calls? ago)?\.")


def hist(text):
    """(path, y, x) from a result's history note; None when it carries none."""
    m = HIST.search(text)
    if not m:
        return None
    return m.group(2), int(m.group(1)), (int(m.group(3)) if m.group(3) else None)


ws = Path(tempfile.mkdtemp(prefix="file_history_ws_"))
t = Tools(workspace=ws, cmd_timeout=5)
n = 0


def call(fn, **kw):
    """One tool call, numbered as the agent loop numbers it."""
    global n
    n += 1
    t.call_index = n
    return getattr(t, fn)(**kw).text


LINK = '<link rel="stylesheet">\n'
S0, S1 = "<head>\n</head>", "<head>\n" + LINK + "</head>"

try:
    # ---- 1. Tools directly -------------------------------------------------------------
    r = call("write_file", path="a.txt", content="alpha")                          # 1
    check("a first write carries no history note", hist(r) is None, r)
    check("a first write still reports the write", r.startswith("wrote 5 chars to a.txt"), r)

    r = call("write_file", path="a.txt", content="alpha")                          # 2
    check("identical rewrite: 2 calls, the previous 1 call ago", hist(r) == ("a.txt", 2, 1), r)
    check("identical rewrite keeps the no-op note",
          "already contained exactly these bytes" in r, r)
    check("the no-op note comes before the history note",
          r.index("already contained") < r.index("write or edit calls"), r)
    check("singular: '1 call ago'", "was 1 call ago." in r, r)

    call("list_dir", path=".")                                                    # 3
    call("read_file", path="a.txt")                                               # 4
    r = call("write_file", path="a.txt", content="alpha")                          # 5
    check("counted in calls of any kind: 3 calls, the previous 3 calls ago",
          hist(r) == ("a.txt", 3, 3), r)
    check("plural: '3 calls ago'", "was 3 calls ago." in r, r)

    # A return to an earlier content: the bytes DID move, so there is no no-op note,
    # and the history note is the only thing that says so.
    r = call("write_file", path="a.txt", content="beta")                           # 6
    check("a new content carries no history note", hist(r) is None, r)
    r = call("write_file", path="a.txt", content="alpha")                          # 7
    check("revert by write: 4 calls, the previous 2 calls ago", hist(r) == ("a.txt", 4, 2), r)
    check("revert by write has no no-op note", "already contained" not in r, r)
    check("the file holds the reverted content", (ws / "a.txt").read_text() == "alpha")

    # Exact bytes: a trailing newline is a different content.
    r = call("write_file", path="a.txt", content="alpha\n")                        # 8
    check("a content differing by one byte is new", hist(r) is None, r)

    # Per path: the same content at another path is new there.
    r = call("write_file", path="b.txt", content="alpha")                          # 9
    check("the same content at a different path carries no note", hist(r) is None, r)

    # ---- edits ----
    call("write_file", path="page.html", content=S0)                              # 10
    r = call("edit_file", path="page.html", old_str="</head>", new_str=LINK + "</head>")  # 11
    check("a first edit to a new content carries no note", hist(r) is None, r)
    check("a real edit still reports edited", r.startswith("edited page.html"), r)
    r = call("edit_file", path="page.html", old_str=LINK, new_str="")             # 12
    check("edit back to the written content: 2 calls, the previous 2 calls ago",
          hist(r) == ("page.html", 2, 2), r)
    r = call("edit_file", path="page.html", old_str="</head>", new_str=LINK + "</head>")  # 13
    check("edit flip-flop: the added-link content, 2 calls, the previous 2 calls ago",
          hist(r) == ("page.html", 2, 2), r)
    r = call("edit_file", path="page.html", old_str=LINK, new_str="")             # 14
    check("edit flip-flop: the original content, 3 calls, the previous 2 calls ago",
          hist(r) == ("page.html", 3, 2), r)
    # Writes and edits share one history.
    r = call("write_file", path="page.html", content=S1)                          # 15
    check("a write landing on an edit's content counts with it: 3 calls, 2 calls ago",
          hist(r) == ("page.html", 3, 2), r)

    # An identical-string edit leaves the file as it was: it is counted, and keeps its
    # own note, which comes first.
    r = call("edit_file", path="page.html", old_str="<head>", new_str="<head>")   # 16
    check("identical-string edit keeps its own note", "No edit was applied" in r, r)
    check("identical-string edit is counted: 4 calls, the previous 1 call ago",
          hist(r) == ("page.html", 4, 1), r)
    check("the identical-string note comes before the history note",
          r.index("No edit was applied") < r.index("write or edit calls"), r)
    r = call("write_file", path="page.html", content=S1)                          # 17
    check("...and is the previous one for the next: 5 calls, 1 call ago",
          hist(r) == ("page.html", 5, 1), r)

    # Failed edits have no outcome and record nothing.
    before = dict(t.file_state_repeats)
    r = call("edit_file", path="page.html", old_str="zzz", new_str="y")           # 18
    check("old_str not found still errors, with no note",
          r.startswith("ERROR") and hist(r) is None, r)
    call("write_file", path="dup.txt", content="xx")                              # 19
    r = call("edit_file", path="dup.txt", old_str="x", new_str="y")               # 20
    check("ambiguous old_str still errors, with no note",
          "matches 2 times" in r and hist(r) is None, r)
    r = call("edit_file", path="missing.txt", old_str="a", new_str="b")           # 21
    check("an edit to a missing file still errors, with no note",
          r.startswith("ERROR") and hist(r) is None, r)
    check("failed edits leave the tallies alone", t.file_state_repeats == before,
          f"{before} -> {t.file_state_repeats}")
    r = call("write_file", path="page.html", content=S1)                          # 22
    check("failed edits are not a previous one: 6 calls, 5 calls ago (call 17)",
          hist(r) == ("page.html", 6, 5), r)

    # Path aliasing: one file however it is spelled; the note shows the spelling used.
    call("write_file", path="src/app.js", content="let x = 1;")                  # 23
    r = call("write_file", path="./src/app.js", content="let x = 1;")            # 24
    check("'./src/app.js' is 'src/app.js'", hist(r) == ("./src/app.js", 2, 1), r)
    r = call("write_file", path="src/../src/app.js", content="let x = 1;")       # 25
    check("'src/../src/app.js' is 'src/app.js'",
          hist(r) == ("src/../src/app.js", 3, 1), r)

    # Content no file tool left there is not history. A file made by a shell command and
    # rewritten with the same bytes gets the no-op note only; so does the first
    # identical-string edit of another, and the second is counted against the first.
    (ws / "made-by-shell.txt").write_text("from a command")
    r = call("write_file", path="made-by-shell.txt", content="from a command")    # 26
    check("bytes a command put there: no-op note, no history note",
          "already contained" in r and hist(r) is None, r)
    (ws / "shell2.txt").write_text("cmd output")
    r = call("edit_file", path="shell2.txt", old_str="cmd", new_str="cmd")        # 27
    check("first identical-string edit of a command's file: no history note",
          "No edit was applied" in r and hist(r) is None, r)
    r = call("edit_file", path="shell2.txt", old_str="cmd", new_str="cmd")        # 28
    check("the same identical-string edit again: 2 calls, 1 call ago",
          hist(r) == ("shell2.txt", 2, 1), r)

    # The stale-process note still comes last.
    call("write_file", path="srv.js", content="setInterval(()=>{}, 1000);")       # 29
    call("run_background_command", command="node srv.js")                          # 30
    r = call("write_file", path="srv.js", content="setInterval(()=>{}, 1000);")   # 31
    check("with a server running: the history note, then the stale-process note",
          hist(r) == ("srv.js", 2, 2) and "still running" in r
          and r.index("write or edit calls") < r.index("still running"), r)

    # The tallies. Notes at calls 2, 5, 7 (writes, a.txt); 12, 13, 14 (edits), 15 (write),
    # 16 (identical edit), 17, 22 (writes, page.html); 24, 25 (writes, src/app.js); 28
    # (identical edit, shell2.txt); 31 (write, srv.js). Of those, 7 and 12-15 moved the
    # bytes. The most calls for one file and content: page.html's link content, 6.
    check("tallies", t.file_state_repeats == {"count": 14, "writes": 9, "edits": 5,
                                              "reverts": 5, "max_times": 6},
          str(t.file_state_repeats))

    # Without the agent loop's numbering the note gives the count alone.
    t2 = Tools(workspace=Path(tempfile.mkdtemp(prefix="file_history_ws2_")))
    t2.write_file(path="c.txt", content="c")
    r = t2.write_file(path="c.txt", content="c").text
    check("without call_index: the count, no distance",
          hist(r) == ("c.txt", 2, None) and "ago" not in r, r)
    t2.teardown()
finally:
    t.teardown()


# ---- 2. Through the agent loop -------------------------------------------------------------
class ScriptedClient:
    """Returns whatever tool calls `fn(step_number)` asks for."""

    def __init__(self, fn):
        self.fn, self.n = fn, 0

    def chat(self, messages, schemas):
        self.n += 1
        calls = self.fn(self.n)
        return Turn(text="", raw={}, finish_reason="tool_calls",
                    usage={"prompt_tokens": 1, "completion_tokens": 1},
                    tool_calls=[ToolCall(id=f"s{self.n}c{i}", name=nm, arguments=ar)
                                for i, (nm, ar) in enumerate(calls)])


def script(step):
    return {
        1: [("write_file", {"path": "a.txt", "content": "A"})],               # call 1
        2: [("list_dir", {"path": "."})],                                      # call 2
        3: [("no_such_tool", {"x": 1})],                                       # call 3: refused
        4: [("write_file", {"__raw__": '{"path": "a.txt", "cont'})],           # call 4: malformed
        5: [("write_file", {"path": "a.txt", "content": "A"})],               # call 5
        6: [("write_file", {"path": "a.txt", "content": "B"}),                # call 6
            ("write_file", {"path": "a.txt", "content": "A"})],               # call 7
        7: [("finish", {"summary": "done"})],                                  # call 8
    }[step]


d = Path(tempfile.mkdtemp(prefix="file_history_agent_"))
tools = Tools(workspace=d / "ws")
log = RunLog(d / "logs", {"condition": "execution"})
messages = build_messages("task", str(d / "ws"))
try:
    status, extra = run_agent(ScriptedClient(script), tools, "execution", messages, log,
                              max_steps=20)
finally:
    tools.teardown()
    log.trace.close()

results = {m["tool_call_id"]: m["content"] for m in messages if m.get("role") == "tool"}
check("agent: the run finished", status == "finished", status)
check("agent: the refused call got a result", "not available" in results.get("s3c0", ""),
      results.get("s3c0", ""))
check("agent: the malformed call got a result", "not valid JSON" in results.get("s4c0", ""),
      results.get("s4c0", ""))
r = results.get("s5c0", "")
check("agent: refused and malformed calls are counted -- 4 calls ago",
      hist(r) == ("a.txt", 2, 4), r)
r = results.get("s6c1", "")
check("agent: calls within one step are counted one by one -- 2 calls ago",
      hist(r) == ("a.txt", 3, 2), r)
check("agent: the tools saw the last call's number", tools.call_index == 8,
      str(tools.call_index))
check("agent: the manifest carries the tallies",
      extra.get("file_state_repeats") == {"count": 2, "writes": 2, "edits": 0,
                                          "reverts": 1, "max_times": 3},
      str(extra.get("file_state_repeats")))
check("agent: the manifest's copy is not the live dict",
      extra.get("file_state_repeats") is not tools.file_state_repeats)

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILURE(S): " + ", ".join(FAILURES))
    sys.exit(1)
print("ALL CHECKS PASSED")
