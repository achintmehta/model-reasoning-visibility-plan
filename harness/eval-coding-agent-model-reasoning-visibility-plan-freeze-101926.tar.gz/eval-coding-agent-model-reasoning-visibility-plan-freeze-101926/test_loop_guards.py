"""Verification of the three loop guards, especially the no-progress guard.

Run:  python3 test_loop_guards.py

Drives run_agent with a scripted client so each pathology is reproduced exactly:
  1. rotating near-identical variants (the failure that defeated both order-based
     guards in a real run and burned 250+ steps)
  2. exact repetition            -> same_calls guard still wins the label
  3. strict A,B alternation      -> cycle guard still wins the label
  4. legitimate progressing work -> NO guard fires (false-positive check)
  5. progress interleaved with a repeated harmless call -> NO guard fires
  6. max_repeat_steps=0          -> pre-2026-08 behavior restored
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from harness.agent import run_agent, build_messages
from harness.llm import ToolCall, Turn
from harness.runlog import RunLog
from harness.tools import Tools

FAILURES = []


def check(name, cond, detail=""):
    print(f"[{'ok ' if cond else 'FAIL'}] {name}" + (f"  -- {detail}" if not cond else ""))
    if not cond:
        FAILURES.append(name)


class ScriptedClient:
    """Returns whatever tool calls `fn(step_number)` asks for."""

    def __init__(self, fn):
        self.fn, self.n = fn, 0

    def chat(self, messages, schemas):
        self.n += 1
        calls = self.fn(self.n)
        return Turn(text="", raw={}, finish_reason="tool_calls",
                    usage={"prompt_tokens": 1, "completion_tokens": 1},
                    tool_calls=[ToolCall(id=f"c{i}", name=nm, arguments=ar)
                                for i, (nm, ar) in enumerate(calls)])


def drive(fn, max_steps=60, **kw):
    """Run the loop against a scripted client; return (status, extra)."""
    d = Path(tempfile.mkdtemp())
    tools = Tools(workspace=d / "ws")
    log = RunLog(d / "logs", {"condition": "execution"})
    try:
        return run_agent(ScriptedClient(fn), tools, "execution",
                         build_messages("task", str(d / "ws")), log,
                         max_steps=max_steps, **kw)
    finally:
        tools.teardown()
        log.trace.close()


# package.json variants that differ only cosmetically — the observed pathology.
VARIANTS = [
    '{\n  "name": "message-board",\n  "scripts": {"dev": "concurrently \\"vite\\"\n}',
    '{\n  "name": "message-board",\n  "version": "1.0.0",\n  "scripts": {"dev": "concurrently \\"vite\\"\n}',
    '{\n  "name": "message-board",\n  "main": "server.js",\n  "scripts": {"dev": "concurrently \\"vite\\"\n}',
]

# 1. rotating variants -> no_progress guard
status, extra = drive(lambda n: [("write_file", {"path": "package.json",
                                                 "content": VARIANTS[(n - 1) % 3]})])
g = extra.get("loop_guard_fired") or {}
check("rotating variants -> stuck_looping", status == "stuck_looping", status)
check("rotating variants -> no_progress guard", g.get("guard") == "no_progress", str(g))
check("rotating variants stopped by step 9", (g.get("step") or 99) <= 9, str(g))

# 2. exact repetition -> same_calls guard keeps the more specific label
status, extra = drive(lambda n: [("write_file", {"path": "a.txt", "content": "x"})])
g = extra.get("loop_guard_fired") or {}
check("exact repeat -> stuck_looping", status == "stuck_looping", status)
check("exact repeat -> same_calls guard", g.get("guard") == "same_calls", str(g))

# 3. strict A,B alternation -> cycle guard keeps its label
status, extra = drive(lambda n: [("write_file", {"path": "a.txt",
                                                 "content": "A" if n % 2 else "B"})])
g = extra.get("loop_guard_fired") or {}
check("A,B alternation -> stuck_looping", status == "stuck_looping", status)
check("A,B alternation -> cycle guard", g.get("guard") == "cycle", str(g))

# 4. FALSE-POSITIVE CHECK: every call novel (real iterative work), then finish
def progressing(n):
    if n <= 20:
        return [("write_file", {"path": f"f{n}.txt", "content": f"content {n}"})]
    return [("finish", {"summary": "done"})]


status, extra = drive(progressing)
check("progressing work finishes", status == "finished", status)
check("progressing work: no guard fired", extra.get("loop_guard_fired") is None,
      str(extra.get("loop_guard_fired")))

# 5. FALSE-POSITIVE CHECK: novel edits interleaved with a repeated harmless call
def progress_with_repeats(n):
    if n > 24:
        return [("finish", {"summary": "done"})]
    if n % 2:
        return [("write_file", {"path": f"g{n}.txt", "content": f"v{n}"})]
    return [("list_dir", {"path": "."})]          # identical every time


status, extra = drive(progress_with_repeats)
check("progress + repeated harmless call finishes", status == "finished", status)
check("progress + repeated harmless call: no guard fired",
      extra.get("loop_guard_fired") is None, str(extra.get("loop_guard_fired")))

# 6. disabling restores pre-2026-08 behavior (rotating variants run to the step cap)
status, extra = drive(lambda n: [("write_file", {"path": "package.json",
                                                 "content": VARIANTS[(n - 1) % 3]})],
                      max_steps=15, max_repeat_steps=0)
check("max_repeat_steps=0 disables the guard", status == "budget_exhausted", status)

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILURE(S): " + ", ".join(FAILURES))
    sys.exit(1)
print("ALL CHECKS PASSED")
