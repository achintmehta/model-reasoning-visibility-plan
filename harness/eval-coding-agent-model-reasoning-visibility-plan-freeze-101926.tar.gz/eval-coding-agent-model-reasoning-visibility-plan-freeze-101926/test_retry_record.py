"""Verification of the retry record (plan 42 v2.5.8).

Run:  python3 test_retry_record.py

A retried model call is a RE-ROLLED generation -- the server starts the reply again from zero
and only the last attempt reaches the trace -- and a read timeout re-rolls exactly the longest
replies. Pinned here:

  1. RealClient records every retry in retry_log: which call, which retry, why, how long the
     failed attempt ran. Checked for a read timeout, a transient HTTP status, and a retry
     budget that runs out (the record must survive the raise).
  2. A call that succeeds first time records nothing.
  3. End to end, through harness.agent's own main() against a scripted local server: the
     run's manifest carries api_retries {count, timeouts, events}.

No model, no GPU, no network beyond 127.0.0.1: a stdlib HTTP server plays the model.
"""
import json
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
from harness.llm import RealClient  # noqa: E402

FAILURES = []


def check(name, cond, detail=""):
    print(f"[{'ok ' if cond else 'FAIL'}] {name}" + (f"  -- {detail}" if not cond else ""))
    if not cond:
        FAILURES.append(name)


def completion(tool_call=None, content="done"):
    msg = {"role": "assistant", "content": content}
    if tool_call:
        msg["content"] = None
        msg["tool_calls"] = [{"id": "c1", "type": "function",
                              "function": {"name": tool_call[0],
                                           "arguments": json.dumps(tool_call[1])}}]
    return {"choices": [{"index": 0, "message": msg,
                         "finish_reason": "tool_calls" if tool_call else "stop"}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}}


class Script:
    """What the fake server does with each POST, in order: ("ok", body) | ("status", code)
    | ("sleep", seconds, body). An exhausted script answers "ok"."""

    def __init__(self):
        self.items, self.lock = [], threading.Lock()

    def next(self):
        with self.lock:
            return self.items.pop(0) if self.items else ("ok", completion())


SCRIPT = Script()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        data = json.dumps(obj).encode()
        try:
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass                     # the client gave up on this one -- that is the test

    def do_GET(self):
        if self.path.rstrip("/").endswith("/models"):
            return self._send(200, {"data": [{"id": "fake-model"}]})
        return self._send(404, {"error": "not found"})

    def do_POST(self):
        self.rfile.read(int(self.headers.get("Content-Length") or 0))
        item = SCRIPT.next()
        if item[0] == "sleep":
            time.sleep(item[1])
            return self._send(200, item[2])
        if item[0] == "status":
            return self._send(item[1], {"error": {"message": f"scripted {item[1]}"}})
        return self._send(200, item[1])


server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{server.server_address[1]}/v1"
MSGS = [{"role": "user", "content": "hi"}]

# 1. a read timeout, then success -------------------------------------------------------
SCRIPT.items = [("sleep", 2.5, completion()), ("ok", completion())]
c = RealClient(base_url=BASE, model="fake-model", timeout=1, max_retries=2, retry_backoff=0.01)
turn = c.chat(MSGS, [])
ev = c.retry_log
check("timeout: the call still succeeds on its retry", turn is not None and turn.text == "done")
check("timeout: exactly one retry recorded", len(ev) == 1, ev)
check("timeout: kind is 'timeout'", bool(ev) and ev[0]["kind"] == "timeout", ev)
check("timeout: call 1, retry 1", bool(ev) and ev[0]["call"] == 1 and ev[0]["retry"] == 1, ev)
check("timeout: failed_after_s is the socket timeout, not the backoff",
      bool(ev) and 0.8 <= ev[0]["failed_after_s"] <= 2.0, ev)
time.sleep(1.8)                  # let the sleeping handler finish before the next script

# 2. a call that succeeds first time records nothing ------------------------------------
SCRIPT.items = [("ok", completion())]
c.chat(MSGS, [])
check("clean call: nothing new recorded", len(c.retry_log) == 1, c.retry_log)

# 3. a transient HTTP status ------------------------------------------------------------
SCRIPT.items = [("status", 503), ("ok", completion())]
c.chat(MSGS, [])
check("HTTP 503: one more retry recorded", len(c.retry_log) == 2, c.retry_log)
check("HTTP 503: kind 'http_503', on call 3",
      c.retry_log[-1]["kind"] == "http_503" and c.retry_log[-1]["call"] == 3, c.retry_log[-1])

# 4. a retry budget that runs out still leaves its record -------------------------------
c2 = RealClient(base_url=BASE, model="fake-model", timeout=5, max_retries=1, retry_backoff=0.01)
SCRIPT.items = [("status", 503), ("status", 503)]
raised = False
try:
    c2.chat(MSGS, [])
except urllib.error.HTTPError:
    raised = True
check("exhausted: the call raises", raised)
check("exhausted: the one retry it made is recorded",
      len(c2.retry_log) == 1 and c2.retry_log[0]["kind"] == "http_503", c2.retry_log)

# 5. end to end: harness.agent's main() writes api_retries into the manifest ------------
with tempfile.TemporaryDirectory() as tmp:
    tmp = Path(tmp)
    ws, rd, task = tmp / "ws", tmp / "run", tmp / "task.md"
    ws.mkdir()
    task.write_text("Write nothing. Call finish.\n", encoding="utf-8")
    SCRIPT.items = [("status", 503), ("ok", completion(("finish", {"summary": "ok"})))]
    cmd = [sys.executable, "-m", "harness.agent", "--task-file", str(task),
           "--condition", "no_verification", "--workspace", str(ws), "--run-dir", str(rd),
           "--base-url", BASE, "--model", "fake-model", "--no-preflight", "--max-steps", "3"]
    p = subprocess.run(cmd, cwd=str(HERE), capture_output=True, text=True, timeout=300)
    found = sorted(rd.rglob("manifest.json"))
    man = json.loads(found[0].read_text(encoding="utf-8")) if found else {}
    if not found:
        print("---- agent stdout (tail) ----\n" + p.stdout[-2500:])
        print("---- agent stderr (tail) ----\n" + p.stderr[-2500:])
    ar = man.get("api_retries")
    check("end to end: the run finished", man.get("status") == "finished",
          f"status={man.get('status')!r} rc={p.returncode}")
    check("end to end: the manifest carries api_retries", isinstance(ar, dict), ar)
    check("end to end: one retry, no timeout",
          isinstance(ar, dict) and ar.get("count") == 1 and ar.get("timeouts") == 0, ar)
    check("end to end: the event says http_503 on call 1",
          isinstance(ar, dict) and ar.get("events")
          and ar["events"][0]["kind"] == "http_503" and ar["events"][0]["call"] == 1, ar)

server.shutdown()
print("\nALL CHECKS PASSED" if not FAILURES else f"\n{len(FAILURES)} CHECK(S) FAILED: {FAILURES}")
sys.exit(1 if FAILURES else 0)
