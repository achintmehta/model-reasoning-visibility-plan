# Controlled coding-agent harness (verification-surface study)

A deliberately thin agent for studying **whether giving a coding agent a verification
surface during implementation changes the quality of what it builds**. The whole point
is control: one constant system prompt, one universal briefing, one task prompt — all
byte-identical across conditions — and the *only* thing that varies is the set of tool
schemas the model receives. No hidden prompts, no off-the-shelf scaffold you can't
inspect.

## Why hand-rolled and not a framework

The study's thesis is that the scaffold shapes the output. An off-the-shelf agent
(Antigravity, Cursor, etc.) injects its own system prompt and context management you
can't see or pin — which is exactly the confound being measured. ~1,300 lines you fully
control is both less code than it sounds and the thing that lets you *prove* inputs were
identical across conditions (see `verify_inputs.py`).

## Layout

    harness/llm.py         OpenAI-compatible client + offline mock + DECODING_DEFAULTS
                           (the frozen decoding registry: temp 0.0 / top_p 1.0 / 32768)
    harness/tools.py       file ops (always on) + verification surfaces (gated):
                           shell + background-process lifecycle, check_boot, start_app,
                           start_server, screenshot, run_tests, lint/typecheck
    harness/conditions.py  condition -> allowed tool set (the independent variable),
                           briefing registry (universal + per-condition), retired names
    harness/runlog.py      per-run manifest + full trace + commands.json audit log
    harness/agent.py       the loop + CLI (finish nudge, loop/cycle guards, token
                           budget, delayed-verification unlock, workspace fingerprint)
    run.sh                 single-run launcher (spec x condition x model x replicate)
    run_matrix.py          sweep one task across conditions x replicates
    verify_inputs.py       prove only the tool set varied across a batch
    selftest.py            offline end-to-end test (no GPU, no network)
    tasks/<spec>           ONE tool-silent spec per task (per-condition variants retired)
    tasks/brownfield-starter  seeded codebase for the brownfield spec

The grader (artifact scoring + visual-rubric merge) lives in the runs repo:
`../eval-coding-agent-runs/grader/`. Workflow docs: `../eval-coding-agent-runs/README.md`.

## Conditions (the independent variable)

Core ladder — run on every spec (monotone verification surface):

| condition       | surface granted on top of file tools             | for |
|-----------------|---------------------------------------------------|-----|
| no_verification | (nothing executes, nothing observed)              | all specs; baseline |
| static          | run_typecheck + run_lint (nothing executes)       | all specs |
| boot_check      | check_boot (one-shot install+boot probe)          | all specs |
| execution       | full shell incl. background-process lifecycle     | all specs; control for visual |
| visual          | full shell + start_server + screenshot            | all specs; needs a vision model |

Targeted conditions — run on specific specs where they are diagnostic (full per-spec
assignment, including which conditions are NOT valid per spec and why, in
`../eval-coding-agent-runs/guidelines/research-context.md`):

| condition            | surface                                   | run on |
|----------------------|-------------------------------------------|--------|
| visual_no_shell      | start_app + screenshot (no shell)         | calendar-week-view, metrics-dashboard |
| delayed_verification | full shell, unlocked on first finish call | kanban-board, seat-booking |
| behavioral           | run_tests                                 | seat-booking |

Retired/renamed — the CLI rejects these with a pointer (`_RETIRED` in conditions.py):
`none` (duplicated the baseline), `self_built` (duplicated execution), and `blind`
(renamed to `no_verification`: collision with the literature's unrelated "blind
execution" term, plus imprecision — static/boot_check/execution are equally sightless;
the baseline uniquely lacks *any verification*). Archived manifests keep their old
names and remain valid data; `harness_git` distinguishes instrument versions.

File tools (read/write/edit/list/finish) are always available — they're needed to
produce code at all, so they are not part of the variable. Grading happens after the
run, identically for every condition (see the grader); the condition only governs what
the agent can *observe while building*.

## Briefing modes (prompt assembly)

The system prompt = constant base + a briefing, chosen by `--briefing-mode`:

- `universal` (default, main batches): ONE briefing byte-identical in every condition —
  the whole prompt is constant; only the tool schemas differ. Points the model at
  whatever tools it has without naming any.
- `per_condition`: registered per-condition environment descriptions (stronger
  orientation; prompt varies across conditions by exactly the registered text).
- `none`: ablation arm, base prompt only.

The manifest records `briefing_mode`, `base_prompt_sha` (workspace-independent
template hash), `condition_briefing_sha`, and `task_sha`. One mode per batch —
`verify_inputs.py` enforces it.

## Setup on the RTX 6000 (LM Studio)

1. In LM Studio: load a coding model, open the **Developer / Local Server** tab, start
   the server (default `http://localhost:1234/v1`).
2. For the `visual` / `visual_no_shell` conditions you need a browser on the run host:
   `pip install playwright && playwright install chromium`
   and a **vision-capable** model (text-only models can't be in the visual arms —
   scope that out explicitly).
3. No API key needed for LM Studio; pass any placeholder.

## Run it

Offline sanity check first (no model needed):

    python3 selftest.py

A single run (preferred — handles paths, briefing mode, brownfield seeding):

    ./run.sh message-board execution openai/gpt-5.5 1
    ./run.sh kanban-labels-brownfield no_verification anthropic/claude-sonnet-4.6 2

Or directly:

    python3 -m harness.agent \
        --task-file tasks/message-board \
        --condition execution \
        --workspace runs/demo/ws --run-dir runs/demo/logs \
        --model qwen2.5-coder-32b-instruct \
        --base-url http://localhost:1234/v1 --api-key lm-studio \
        --max-total-tokens 3000000

The full sweep for one task (freeze-then-apply protocol):

    python3 run_matrix.py \
        --task-file tasks/kanban-board \
        --model qwen2.5-coder-32b-instruct \
        --conditions no_verification static boot_check execution visual \
        --replicates 3 --out runs/kanban

Then confirm the experiment was clean:

    python3 verify_inputs.py runs/kanban
    # -> task constant, base prompt constant, one briefing mode matching the
    #    registry, one decoding configuration, no contaminated runs
    #    CLEAN: only the tool set varied.

Full end-to-end workflow (runs -> audit -> auto grading -> manual visual grading ->
merge): `../eval-coding-agent-runs/README.md`.

## Switching to OpenRouter (for models you can't run locally)

Same harness, two flags (run.sh does this automatically for namespaced models):

    --base-url https://openrouter.ai/api/v1 --api-key $OPENROUTER_API_KEY

Pin the upstream provider per model and log it (OpenRouter can route the same model to
different hosts/quantizations). Decoding params come from the frozen registry
(`harness/llm.py`); overrides are stamped `decoding_overridden` and fail verification.

## Run hygiene (hard-won rules)

- **Never `--interactive` for study runs.** Human feedback mid-run contaminates the
  data point; the manifest flags it (`interactive`, `human_turns`) and analysis must
  exclude it.
- **One briefing mode and one decoding config per batch** — `verify_inputs.py` fails
  the batch otherwise.
- **Token budget, not steps, is the cost guard**: `--max-total-tokens` (run.sh default
  3M) terminates runaway runs (`token_budget_exhausted`).
- **Runs are sequential** — parallel runs fight over ports.
- Commit the harness before a study batch; every manifest records `harness_git`. Never
  mix instrument versions in one analysis table.

## Known limitations

- **`visual` couples in the full shell** — the model must start the app before it can
  screenshot it, so "visual" means "execution + sight"; `execution` is its control.
  `visual_no_shell` (harness-managed `start_app` + screenshot) decomposes the sum from
  the other side.
- **`screenshot` is passive** — it renders but cannot click, so event-driven UI bugs
  (drag-and-drop) are a lower bound for the visual arms; the manual rubrics cover them.
- **Tool-call reliability varies by model.** Smoke-test every model on a trivial
  write+finish task before committing run budget; the loop surfaces bad arguments as
  tool errors, and a one-time finish nudge separates "forgot to call finish" from
  failure — but a model that never emits valid calls can't be scored.
- **Four newer specs grade as boot + visual rubric only** (calendar-week-view,
  metrics-dashboard, kanban-labels-brownfield, log-explorer-perf): their API probe
  modules in the grader are future work.
