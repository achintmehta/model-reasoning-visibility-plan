#!/usr/bin/env python3
"""Build or update quant-registry.json from the GGUF files themselves.

WHY THIS EXISTS. The manifest's `quantization` field is a declaration: the operator
types Q8_0 and the harness believes them. That is enough to group runs, and not enough
to interpret them. When a pilot shows one rung behaving differently from another, the
first question is whether the two rungs actually differ in precision or merely in who
built them and how — and a typed label cannot answer that.

So this tool does not ask what you believe about a file. It opens the GGUF, reads the
metadata the quantizer wrote into it, and records that:

    general.quantized_by        who built it        -> publisher
    quantize.imatrix.file       importance matrix   -> imatrix, imatrix_dataset
    general.file_type           the actual quant    -> gguf_file_type
    general.architecture        model family        -> architecture
    general.base_model.0.repo_url / general.repo_url

plus sha256 and size, which pin the exact bytes.

METHOD (PTQ vs QAT) IS NOT IN THE FILE and cannot be measured this way. GGUF has no key
for it. It defaults to "PTQ" with `method_source: "assumed"`, and you must set it by
hand for anything quantization-aware-trained. That distinction is D9's whole subject —
a QAT rung is a different treatment, not a different precision — so the field is
deliberately loud about being unverified rather than quietly wrong.

Usage
    python3 tools/hash_quants.py --model gemma-4-31b \\
        /path/to/gemma-4-31B-it-Q8_0.gguf /path/to/gemma-4-31B-it-Q5_K_M.gguf

    # metadata only, skip the multi-minute hash while you are still setting things up
    python3 tools/hash_quants.py --model gemma-4-31b --no-sha256 *.gguf

    # write somewhere other than ./quant-registry.json
    python3 tools/hash_quants.py --model gemma-4-31b --registry /path/reg.json *.gguf

The rung label is taken from general.file_type in the file, so the registry key is what
the file IS rather than what its name says. Override with --label when you need to
(a BF16 file whose file_type reads F16, say). Existing entries are updated in place and
any hand-added fields on them are preserved.

--key files the entry under a registry key of your choosing while gguf_file_type keeps what
the header says (added in plan v2.5.2). It exists for unsloth's Dynamic quants, whose header
records the base type -- Q4_K_M -- while the rung a run declares is UD-Q4_K_M. --label cannot
do that job: it overwrites gguf_file_type as well, which is right for a misleading ftype and
wrong here. Magistral's UD-Q4_K_XL entry is the precedent, keyed that way by hand. One file
per call when --key is given.

    python3 tools/hash_quants.py --model qwen3.6-35b-a3b --key UD-Q4_K_M \\
        /path/to/Qwen3.6-35B-A3B-UD-Q4_K_M.gguf
"""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Minimal GGUF metadata reader.
#
# Only the header is parsed: magic, version, counts, then the key/value block. That
# block sits at the very start of the file, so this reads a few hundred KB of a 30 GB
# model rather than all of it. Tensor data is never touched.
#
# Spec: https://github.com/ggml-org/ggml/blob/master/docs/gguf.md
# ---------------------------------------------------------------------------

(UINT8, INT8, UINT16, INT16, UINT32, INT32, FLOAT32, BOOL, STRING, ARRAY,
 UINT64, INT64, FLOAT64) = range(13)

_FMT = {UINT8: "<B", INT8: "<b", UINT16: "<H", INT16: "<h", UINT32: "<I",
        INT32: "<i", FLOAT32: "<f", BOOL: "<?", UINT64: "<Q", INT64: "<q",
        FLOAT64: "<d"}

# general.file_type -> label. Values are the ggml ftype enum. Only the ones a precision
# ladder plausibly uses are named; anything else is reported as ftype:<n> rather than
# guessed at, so an unknown value is visible instead of silently mislabelled.
_FTYPE = {0: "F32", 1: "F16", 2: "Q4_0", 3: "Q4_1", 7: "Q8_0", 8: "Q5_0", 9: "Q5_1",
          10: "Q2_K", 11: "Q3_K_S", 12: "Q3_K_M", 13: "Q3_K_L", 14: "Q4_K_S",
          15: "Q4_K_M", 16: "Q5_K_S", 17: "Q5_K_M", 18: "Q6_K", 19: "IQ2_XXS",
          20: "IQ2_XS", 21: "Q2_K_S", 22: "IQ3_XS", 23: "IQ3_XXS", 24: "IQ1_S",
          25: "IQ4_NL", 26: "IQ3_S", 27: "IQ3_M", 28: "IQ2_S", 29: "IQ2_M",
          30: "IQ4_XS", 31: "IQ1_M", 32: "BF16"}


class GGUFError(RuntimeError):
    pass


class _Reader:
    """Buffered forward-only reader over the header region."""

    def __init__(self, fh):
        self.fh = fh

    def raw(self, n: int) -> bytes:
        b = self.fh.read(n)
        if len(b) != n:
            raise GGUFError(f"unexpected EOF reading {n} bytes")
        return b

    def scalar(self, t: int):
        fmt = _FMT.get(t)
        if fmt is None:
            raise GGUFError(f"unknown value type {t}")
        return struct.unpack(fmt, self.raw(struct.calcsize(fmt)))[0]

    def string(self) -> str:
        n = self.scalar(UINT64)
        return self.raw(n).decode("utf-8", "replace")

    def value(self, t: int, array_cap: int = 8):
        if t == STRING:
            return self.string()
        if t == ARRAY:
            et = self.scalar(UINT32)
            n = self.scalar(UINT64)
            # Vocabularies run to 262144 entries. Read them all (we must, to stay aligned
            # for the keys that follow) but keep only a head sample in memory.
            out = []
            for i in range(n):
                v = self.value(et, array_cap)
                if i < array_cap:
                    out.append(v)
            return {"_array_len": n, "_head": out}
        return self.scalar(t)


def read_gguf_meta(path: Path, array_cap: int = 8) -> dict:
    with path.open("rb") as fh:
        r = _Reader(fh)
        if r.raw(4) != b"GGUF":
            raise GGUFError("not a GGUF file (bad magic)")
        version = r.scalar(UINT32)
        n_tensors = r.scalar(UINT64)
        n_kv = r.scalar(UINT64)
        if n_kv > 100_000:
            raise GGUFError(f"implausible kv count {n_kv}; refusing to parse")
        kv = {}
        for _ in range(n_kv):
            key = r.string()
            kv[key] = r.value(r.scalar(UINT32), array_cap)
    return {"gguf_version": version, "tensor_count": n_tensors, "kv": kv}


def sha256_file(path: Path, show_progress: bool = True) -> str:
    """Full-file sha256. Minutes per rung — which is exactly why the registry exists,
    so this runs once per file rather than once per run."""
    h = hashlib.sha256()
    # Only animate on a terminal; in a captured log the \r rewrites become duplicate
    # lines rather than an updating counter.
    show_progress = show_progress and sys.stderr.isatty()
    total = path.stat().st_size
    done = 0
    step = max(total // 20, 1)
    next_mark = step
    with path.open("rb") as fh:
        while chunk := fh.read(8 * 1024 * 1024):
            h.update(chunk)
            done += len(chunk)
            if show_progress and done >= next_mark:
                pct = 100 * done / total
                print(f"\r    sha256 {pct:5.1f}%", end="", file=sys.stderr, flush=True)
                next_mark += step
    if show_progress:
        print("\r    sha256 100.0%", file=sys.stderr)
    return h.hexdigest()


def entry_for(path: Path, want_sha: bool, label_override: str | None) -> tuple[str, dict]:
    meta = read_gguf_meta(path)
    kv = meta["kv"]
    ftype = kv.get("general.file_type")
    label = label_override or _FTYPE.get(ftype, f"ftype:{ftype}")
    imatrix_file = kv.get("quantize.imatrix.file")
    entry = {
        "publisher": kv.get("general.quantized_by") or "unknown",
        "repo": kv.get("general.repo_url") or kv.get("general.base_model.0.repo_url"),
        "architecture": kv.get("general.architecture"),
        "gguf_file_type": label,
        "gguf_file_type_raw": ftype,
        # PTQ unless told otherwise; GGUF cannot tell us. Flagged as assumed so a QAT
        # build cannot pass as post-training quantized just because nobody looked.
        "method": "PTQ",
        "method_source": "assumed",
        "imatrix": bool(imatrix_file),
        "imatrix_file": imatrix_file,
        "imatrix_dataset": kv.get("quantize.imatrix.dataset"),
        "imatrix_chunks": kv.get("quantize.imatrix.chunks_count"),
        "file": str(path),
        "file_name": path.name,
        "file_size_bytes": path.stat().st_size,
        "tensor_count": meta["tensor_count"],
        "recorded_by": "tools/hash_quants.py",
    }
    entry["file_sha256"] = sha256_file(path) if want_sha else None
    return label, entry


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+", help="GGUF files to record")
    ap.add_argument("--model", required=True,
                    help="model id as the harness will pass it in --model, e.g. gemma-4-31b")
    ap.add_argument("--registry", default="quant-registry.json")
    ap.add_argument("--label", default=None,
                    help="force the rung label instead of reading general.file_type "
                         "(only when the file's own ftype is misleading)")
    ap.add_argument("--key", default=None,
                    help="file the entry under this registry key (e.g. UD-Q4_K_M) while "
                         "gguf_file_type keeps what the header says; one file per call")
    ap.add_argument("--no-sha256", action="store_true",
                    help="skip the full-file hash (fast, but the entry is then not "
                         "pinned to specific bytes)")
    args = ap.parse_args()
    if args.key and len(args.files) != 1:
        sys.exit("--key names ONE registry entry, so give exactly one file with it")

    reg_path = Path(args.registry)
    reg = {}
    if reg_path.is_file():
        try:
            reg = json.loads(reg_path.read_text(encoding="utf-8"))
        except Exception as e:  # noqa: BLE001
            sys.exit(f"{reg_path} exists but is not valid JSON: {e}")
    reg.setdefault("_comment",
                   "Quantization rungs, keyed model -> rung label. Generated by "
                   "tools/hash_quants.py; `method` is ASSUMED PTQ and must be set by "
                   "hand for QAT builds (see D9). Referenced by harness/agent.py "
                   "--quant-registry and recorded per run as quantization_detail.")
    section = reg.setdefault(args.model, {})

    for f in args.files:
        p = Path(f)
        if not p.is_file():
            print(f"!! skipping {p}: not a file", file=sys.stderr)
            continue
        print(f"reading {p.name} ...", file=sys.stderr)
        try:
            label, entry = entry_for(p, not args.no_sha256, args.label)
        except GGUFError as e:
            print(f"!! skipping {p.name}: {e}", file=sys.stderr)
            continue
        # Preserve hand-edited fields (notably `method` once someone has set it to QAT).
        key = args.key or label
        prev = section.get(key) or {}
        if prev.get("method_source") == "manual":
            entry["method"] = prev.get("method", entry["method"])
            entry["method_source"] = "manual"
        for k, v in prev.items():
            if k.startswith("note") or k not in entry:
                entry.setdefault(k, v)
        section[key] = entry
        print(f"  -> {args.model}/{key}: publisher={entry['publisher']} "
              f"imatrix={entry['imatrix']} size={entry['file_size_bytes']/2**30:.2f} GiB "
              f"sha256={str(entry['file_sha256'])[:16]}", file=sys.stderr)

    reg_path.write_text(json.dumps(reg, indent=2, sort_keys=False) + "\n",
                        encoding="utf-8")
    print(f"wrote {reg_path}", file=sys.stderr)


if __name__ == "__main__":
    main()
