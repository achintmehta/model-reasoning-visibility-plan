#!/usr/bin/env python3
"""Does this server round-trip `reasoning_content` on an assistant turn?

Run this BEFORE a batch with --replay-reasoning on. It answers the one question the
harness cannot answer for itself, in about ten seconds and without spending a run.

Three outcomes, all actionable:

  ACCEPTED  the server took an assistant message carrying reasoning_content alongside
            tool_calls and answered normally. Replay is safe on this server + template.

  REJECTED  the server refused it — typically llama.cpp's template error, "Cannot pass
            both content and thinking in an assistant message with tool calls!"
            (ggml-org/llama.cpp#19703, regressed again in #20500). Run the batch with
            --no-replay-reasoning until the build or template is fixed.

  IGNORED   the server accepted the request but the reasoning never reached the prompt,
            so replay is a silent no-op — the worst case, because a batch would look
            fine while the setting did nothing. Detected by asking the model to echo a
            nonce that appears ONLY inside the replayed reasoning.

Usage
    python3 tools/probe_reasoning_replay.py --base-url http://192.168.1.110:7777/v1 \\
        --model-key glm-q4

--model-key reads the model's alias, its THINKING-arm request body and its replay format
out of run_one_with_server.sh -- the same functions template_probe.sh evals -- so the probe
sends what a SEEN run sends. Until plan v2.5.0 (where GLM became the roster's sixth model)
it sent no chat_template_kwargs at all, and that made it wrong in a way that looked like a
model failure: the probe's last message is a USER message, and every template that clears
history by default -- GLM (clear_thinking unset), Nemotron and Granite
(truncate_history_thinking true), Gemma and Qwen (preserve_thinking false) -- drops a
reasoning block that sits before the last user message. It would have reported IGNORED for
a replay the study's own SEEN runs carry intact. --model and --extra-body remain for
probing a server by hand.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

# A nonce that cannot plausibly be produced by chance, placed ONLY in the replayed
# reasoning. If the model can repeat it, the reasoning demonstrably reached the prompt.
NONCE = "ZQ7-KESTREL-4419"

TOOL = [{
    "type": "function",
    "function": {
        "name": "read_file",
        "description": "Read a file in the workspace.",
        "parameters": {"type": "object",
                       "properties": {"path": {"type": "string"}},
                       "required": ["path"]},
    },
}]


def post(base, model, messages, tools, timeout=120, **extra):
    payload = {"model": model, "messages": messages, "max_tokens": 200,
               "temperature": 0, "top_p": 1, **extra}
    if tools:
        payload["tools"] = tools
        payload["tool_choice"] = "auto"
    req = urllib.request.Request(
        base.rstrip("/") + "/chat/completions",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json", "Authorization": "Bearer probe"},
        method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return 200, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")
    except Exception as e:  # noqa: BLE001
        return 0, f"{type(e).__name__}: {e}"


def from_wrapper(wrapper, key):
    """The alias, THINKING-arm body and replay format run_one_with_server.sh uses for `key`.

    Evals the wrapper's own resolve_model() and think_body(), extracted exactly the way
    template_probe.sh extracts them, so there is one statement of what a SEEN run sends
    rather than two that can drift apart.
    """
    script = r'''
set -e
W="$1"; K="$2"
eval "$(sed -n '/^PLAIN_BODY=/,/^}/p' "$W")"
eval "$(sed -n '/^resolve_model()/,/^}/p' "$W")"
eval "$(awk '/^think_body\(\)/,/^}/' "$W")"
resolve_model "$K"
printf '%s\n%s\n%s\n' "$ALIAS" "$(think_body on)" "$REPLAY_FORMAT_KEY"
'''
    p = subprocess.run(["bash", "-c", script, "probe", str(wrapper), key],
                       capture_output=True, text=True)
    if p.returncode != 0:
        sys.exit(f"could not resolve model key '{key}' from {wrapper}: {p.stderr.strip()}")
    alias, body, fmt = (p.stdout.splitlines() + ["", "", ""])[:3]
    return alias, json.loads(body or "{}"), fmt or "field"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-url", required=True,
                    help="e.g. http://192.168.1.110:7777/v1")
    ap.add_argument("--model-key",
                    help="a run_one_with_server.sh model key (e.g. glm-q4): take the alias, the "
                         "THINKING-arm body and the replay format from the wrapper, so the "
                         "probe sends exactly what a SEEN run sends")
    ap.add_argument("--model", help="the served alias (implied by --model-key)")
    ap.add_argument("--extra-body", default=None,
                    help="JSON merged into the request body, over the wrapper's")
    ap.add_argument("--replay-format", choices=("field", "inline-think"), default=None,
                    help="how the reasoning is carried back (implied by --model-key)")
    ap.add_argument("--max-tokens", type=int, default=4096,
                    help="per reply; was a fixed 200, which a thinking model can spend "
                         "entirely on thinking without ever reaching the answer")
    ap.add_argument("--wrapper",
                    default=str(Path(__file__).resolve().parent.parent / "run_one_with_server.sh"))
    args = ap.parse_args()

    req_body, replay_format, model = {}, "field", args.model
    if args.model_key:
        alias, req_body, replay_format = from_wrapper(args.wrapper, args.model_key)
        model = model or alias
    if args.extra_body:
        req_body = {**req_body, **json.loads(args.extra_body)}
    if args.replay_format:
        replay_format = args.replay_format
    if not model:
        ap.error("give --model-key (preferred) or --model")
    extra = {**req_body, "max_tokens": args.max_tokens}

    # The exact message shape the harness builds when replay is on: an assistant turn
    # carrying content, tool_calls AND reasoning_content, followed by its tool result.
    messages = [
        {"role": "system", "content": "You are a software engineer."},
        {"role": "user", "content": "Read config.json and tell me what you find."},
        {"role": "assistant",
         "content": "",
         "reasoning_content": (
             f"I should read the file first. Note to self: my working codeword for this "
             f"task is {NONCE}. I will need to repeat it if asked."),
         "tool_calls": [{"id": "call_0", "type": "function",
                         "function": {"name": "read_file",
                                      "arguments": json.dumps({"path": "config.json"})}}]},
        {"role": "tool", "tool_call_id": "call_0", "content": '{"debug": true}'},
        {"role": "user",
         "content": ("Before continuing: earlier you noted a working codeword for this "
                     "task. Reply with that codeword and nothing else.")},
    ]
    if replay_format == "inline-think":
        # Magistral's route (harness REPLAY_FORMATS): the reasoning rides inline in the
        # content as [THINK]…[/THINK] and never in the field -- sending the field is what
        # makes llama.cpp delete the prose for that family. Inline content always reaches
        # the prompt, so on this route the probe confirms the plumbing; it cannot test a gate.
        a = messages[2]
        a["content"] = f"[THINK]{a.pop('reasoning_content')}[/THINK]" + a["content"]

    print(f"server : {args.base_url}")
    print(f"model  : {model}" + (f"   (key {args.model_key}, from the wrapper)"
                                 if args.model_key else ""))
    print(f"body   : {json.dumps(req_body) if req_body else '(none -- template defaults)'}")
    print(f"replay : {replay_format}, max_tokens {args.max_tokens}")
    print("probe  : assistant turn carrying the reasoning + tool_calls, then a user question\n")

    code, body = post(args.base_url, model, messages, TOOL, **extra)

    if code == 0:
        print(f"UNREACHABLE — {body}")
        return 2
    if code != 200:
        text = body if isinstance(body, str) else json.dumps(body)
        print(f"REJECTED — HTTP {code}")
        print(f"  {text.strip()[:600]}")
        low = text.lower()
        if "thinking" in low or "reasoning" in low or "template" in low:
            print("\n  This is the template failure this probe exists to catch.")
            print("  Run batches with --no-replay-reasoning until the build is fixed.")
        return 1

    msg = (body.get("choices") or [{}])[0].get("message") or {}
    out = (msg.get("content") or "").strip()
    rsn = (msg.get("reasoning_content") or "").strip()
    print(f"HTTP 200. Model replied: {out[:200]!r}")
    if rsn:
        print(f"          and reasoned:  {rsn[:200]!r}")
    print()

    # The nonce exists ONLY inside the replayed reasoning, so the model producing it
    # ANYWHERE -- in its answer or in its own new reasoning -- proves the reasoning reached
    # the prompt. Checking only the content would fail a thinking model that recalled the
    # codeword while thinking and ran out of tokens before it answered.
    if NONCE in out or NONCE in rsn:
        print("ACCEPTED — the nonce came back, so the replayed reasoning demonstrably")
        print("reached the prompt. Replay works on this server and template.")
        return 0

    # 200 but no nonce. Distinguish "reasoning was dropped" from "the model simply
    # would not comply" by re-asking with the SAME text as ordinary content: if the
    # nonce comes back that way, the model can follow the instruction and the earlier
    # failure was the reasoning field being ignored.
    control = [dict(m) for m in messages]
    if "reasoning_content" in control[2]:
        control[2]["content"] = control[2].pop("reasoning_content")
    code2, body2 = post(args.base_url, model, control, TOOL, **extra)
    out2 = ""
    if code2 == 200:
        m2 = (body2.get("choices") or [{}])[0].get("message") or {}
        out2 = ((m2.get("content") or "") + "\n" + (m2.get("reasoning_content") or "")).strip()

    if NONCE in out2:
        print("IGNORED — the server accepted the request but the reasoning never reached")
        print("the prompt (the same text as ordinary `content` DID come back). Replay")
        print("would be a silent no-op on this template: runs would look fine and the")
        print("setting would do nothing. Treat as unsupported.")
        return 1
    print("INCONCLUSIVE — the nonce came back in neither form, so this model would not")
    print(f"follow the echo instruction regardless (control reply: {out2[:120]!r}).")
    print("Re-run against a more instruction-following model, or inspect the server's")
    print("prompt directly with `--verbose-prompt` / the /props chat template.")
    return 3


if __name__ == "__main__":
    sys.exit(main())
