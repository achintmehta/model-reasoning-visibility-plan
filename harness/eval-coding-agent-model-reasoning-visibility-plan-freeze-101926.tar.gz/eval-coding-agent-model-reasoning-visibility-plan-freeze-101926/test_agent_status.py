"""Verification of terminal-status classification and reasoning capture.

Run:  python3 test_agent_status.py

Two things are pinned here, both added in the 2026-08 feedback pass:

  1. truncated_no_tool_call — a turn with no tool calls because it was CUT OFF at the
     token limit must not be scored as stopped_no_tool_call. Conflating them turns an
     infrastructure fault (a server serving a smaller context than configured) into a
     verdict about the model's tool-calling ability. Five runs were misattributed that
     way before the distinction existed.

  2. reasoning capture — provider-side chain-of-thought is recorded for the audit trail
     but MUST NOT be echoed back to the model. Replaying it would change what the model
     is conditioned on, and would do so only for reasoning models: a second treatment
     riding along with the one under study.

No model, no network, no browser - scripted client against a temp workspace.
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from harness.agent import run_agent, build_messages
from harness.llm import RealClient, ToolCall, Turn
from harness.runlog import RunLog
from harness.tools import Tools

FAILURES = []


def check(name, cond, detail=""):
    print(f"[{'ok ' if cond else 'FAIL'}] {name}" + (f"  -- {detail}" if not cond else ""))
    if not cond:
        FAILURES.append(name)


class ScriptedClient:
    """Returns whatever Turn `fn(step_number)` asks for, recording what it was sent."""

    max_tokens = 32768

    def __init__(self, fn):
        self.fn, self.n = fn, 0
        self.seen_messages = []

    def chat(self, messages, schemas):
        self.n += 1
        self.seen_messages.append([dict(m) for m in messages])
        return self.fn(self.n)


def drive(fn, max_steps=20, **kw):
    d = Path(tempfile.mkdtemp())
    tools = Tools(workspace=d / "ws")
    log = RunLog(d / "logs", {"condition": "execution"})
    client = ScriptedClient(fn)
    try:
        status, extra = run_agent(client, tools, "execution",
                                  build_messages("task", str(d / "ws")), log,
                                  max_steps=max_steps, **kw)
        return status, extra, client
    finally:
        tools.teardown()
        log.trace.close()


def call(name, args):
    return [ToolCall(id="c0", name=name, arguments=args)]


# --- 1. truncation is classified separately from a genuine stop --------------------
status, extra, _ = drive(lambda n: Turn(
    text="", raw={}, finish_reason="length", tool_calls=[],
    usage={"prompt_tokens": 4041, "completion_tokens": 55}))
check("no tool call + finish_reason=length -> truncated_no_tool_call",
      status == "truncated_no_tool_call", status)

td = extra.get("truncation_detected") or {}
check("truncation records the step", td.get("step") == 1, str(td))
check("truncation records prompt tokens", td.get("prompt_tokens") == 4041, str(td))
check("truncation records completion tokens", td.get("completion_tokens") == 55, str(td))
check("truncation records the requested max_tokens",
      td.get("max_tokens_requested") == 32768, str(td))
check("truncation fires on the first bad turn, no nudge first",
      extra.get("finish_nudges") == 0, str(extra.get("finish_nudges")))

# --- 2. REGRESSION: a real stop still takes the old path (nudge, then stop) --------
status, extra, client = drive(lambda n: Turn(
    text="I have finished the work.", raw={}, finish_reason="stop", tool_calls=[],
    usage={"prompt_tokens": 100, "completion_tokens": 10}))
check("no tool call + finish_reason=stop -> stopped_no_tool_call",
      status == "stopped_no_tool_call", status)
check("a real stop is still nudged exactly once",
      extra.get("finish_nudges") == 1, str(extra.get("finish_nudges")))
check("a real stop records no truncation",
      extra.get("truncation_detected") is None, str(extra.get("truncation_detected")))

# --- 3. reasoning is captured for the record but never replayed to the model -------
SECRET = "INTERNAL-THOUGHT-MARKER: the user probably wants a file."


def with_reasoning(n):
    if n == 1:
        return Turn(text="Writing it now.", raw={}, finish_reason="tool_calls",
                    reasoning=SECRET, usage={"prompt_tokens": 10, "completion_tokens": 5},
                    tool_calls=call("write_file", {"path": "a.txt", "content": "hi"}))
    return Turn(text="", raw={}, finish_reason="tool_calls",
                usage={"prompt_tokens": 10, "completion_tokens": 5},
                tool_calls=call("finish", {"summary": "done"}))


status, extra, client = drive(with_reasoning)
check("run with reasoning completes normally", status == "finished", status)
check("reasoning turns counted", extra.get("reasoning_turns") == 1,
      str(extra.get("reasoning_turns")))
check("reasoning chars counted", extra.get("reasoning_chars") == len(SECRET),
      str(extra.get("reasoning_chars")))

second_request = client.seen_messages[1]
blob = "\n".join(str(m.get("content", "")) for m in second_request)
check("reasoning is NOT echoed back to the model", SECRET not in blob,
      "reasoning leaked into the next request")
check("the visible assistant text IS echoed back", "Writing it now." in blob)

# --- 4. the parser picks reasoning out of either provider's key -------------------
t = RealClient._parse({"choices": [{"finish_reason": "stop", "message": {
    "content": "", "reasoning_content": "lm-studio style"}}]})
check("reasoning_content is captured", t.reasoning == "lm-studio style", str(t.reasoning))

t = RealClient._parse({"choices": [{"finish_reason": "stop", "message": {
    "content": "", "reasoning": "openrouter style"}}]})
check("reasoning is captured", t.reasoning == "openrouter style", str(t.reasoning))

t = RealClient._parse({"choices": [{"finish_reason": "stop", "message": {
    "content": "", "reasoning": {"content": "nested style"}}}]})
check("nested reasoning dict is flattened", t.reasoning == "nested style", str(t.reasoning))

t = RealClient._parse({"choices": [{"finish_reason": "stop",
                                    "message": {"content": "plain"}}]})
check("absent reasoning stays None", t.reasoning is None, str(t.reasoning))
check("empty reasoning is normalized to None",
      RealClient._parse({"choices": [{"finish_reason": "stop", "message": {
          "content": "x", "reasoning_content": ""}}]}).reasoning is None)

# Whitespace-only reasoning must not count as reasoning. Observed with Gemma 4 via
# LM Studio: every turn carried reasoning_content="\n", which is truthy, so every step
# printed an empty "Reasoning (0 chars):" line and reasoning_turns climbed to the step
# count — a recorded study measure reporting thinking that never happened.
for blank in ("\n", " ", "\n\n", "\t \n"):
    check(f"whitespace-only reasoning {blank!r} -> None",
          RealClient._parse({"choices": [{"finish_reason": "stop", "message": {
              "content": "x", "reasoning_content": blank}}]}).reasoning is None)

status, extra, _ = drive(lambda n: Turn(
    text="", raw={}, finish_reason="tool_calls", reasoning="\n",
    usage={"prompt_tokens": 1, "completion_tokens": 1},
    tool_calls=call("finish", {"summary": "done"})))
check("whitespace reasoning does not inflate reasoning_turns",
      extra.get("reasoning_turns") == 0, str(extra.get("reasoning_turns")))
check("whitespace reasoning does not inflate reasoning_chars",
      extra.get("reasoning_chars") == 0, str(extra.get("reasoning_chars")))

# --- 5. the new fields actually reach manifest.json -------------------------------
# The testing docs tell the operator to diagnose a failed screening run by reading
# these keys out of the manifest, so pin that they survive the trip through finalize().
d = Path(tempfile.mkdtemp())
tools = Tools(workspace=d / "ws")
log = RunLog(d / "logs", {"condition": "execution"})
try:
    status, extra = run_agent(
        ScriptedClient(lambda n: Turn(text="", raw={}, finish_reason="length",
                                      tool_calls=[],
                                      usage={"prompt_tokens": 4041,
                                             "completion_tokens": 55})),
        tools, "execution", build_messages("task", str(d / "ws")), log, max_steps=5)
    log.finalize(status, extra=extra)
finally:
    tools.teardown()

import json  # noqa: E402 - local to this check
manifest = json.loads((d / "logs" / "manifest.json").read_text())
check("manifest records the truncated status", manifest.get("status") == status,
      str(manifest.get("status")))
check("manifest carries truncation_detected",
      (manifest.get("truncation_detected") or {}).get("prompt_tokens") == 4041,
      str(manifest.get("truncation_detected")))
check("manifest carries the reasoning counters",
      "reasoning_turns" in manifest and "reasoning_chars" in manifest,
      str(sorted(manifest)[:12]))

# --- 6. tool-call malformation counter, three classes -----------------------------
# The H1 mechanical measure. Each class fails at a different layer, and before this
# only the first was visible at all.
from harness.agent import looks_like_tool_call_attempt  # noqa: E402

ALLOWED = ["run_command", "write_file", "browser_type", "finish", "list_dir"]
for text, want, label in [
    ('```json\n{"action": "run_command", "command": "mkdir x"}\n```<tool_call|>',
     True, "gemma's real unparsed call"),
    ('{"name": "write_file", "arguments": {"path": "a", "content": "{}"}}',
     True, "nested arguments and braces inside a string"),
    ('<tool_call>{"name":"write_file"}</tool_call>', True, "delimiter form"),
    ("I will now write the file and then run the tests.", False, "plain prose"),
    ('Here is the package.json:\n{"name": "kanban-board", "version": "1.0"}',
     False, "package.json name key is NOT a tool call"),
    ('{"scripts": {"dev": "vite"}, "name": "app"}', False, "nested package.json"),
    ('{"action": "deploy_to_prod"}', False, "names a tool this run does not have"),
    ('const x = "{ not json";', False, "brace inside a string literal"),
    ("", False, "empty text"), (None, False, "no text"),
]:
    check(f"class 3 detector: {label}",
          looks_like_tool_call_attempt(text, ALLOWED) is want)

# class 1 — arguments that are not valid JSON (parser stashed them under __raw__)
status, extra, _ = drive(lambda n: Turn(
    text="", raw={}, finish_reason="tool_calls",
    usage={"prompt_tokens": 1, "completion_tokens": 1},
    tool_calls=[ToolCall(id="c0", name="write_file",
                         arguments={"__raw__": '{"path": "a.txt", "content": "trunc'})]
) if n == 1 else Turn(text="", raw={}, finish_reason="tool_calls",
                      usage={"prompt_tokens": 1, "completion_tokens": 1},
                      tool_calls=call("finish", {"summary": "done"})))
tc = extra.get("tool_calls") or {}
check("class 1 counted as unparseable_arguments",
      tc.get("unparseable_arguments") == 1, str(tc))
check("class 1 counts toward attempts", tc.get("attempts") == 2, str(tc))

# class 2 — valid JSON, wrong shape for the tool's signature (the Q4 selector bug)
status, extra, _ = drive(lambda n: Turn(
    text="", raw={}, finish_reason="tool_calls",
    usage={"prompt_tokens": 1, "completion_tokens": 1},
    tool_calls=call("write_file", {"path": "a.txt"})      # 'content' missing
) if n == 1 else Turn(text="", raw={}, finish_reason="tool_calls",
                      usage={"prompt_tokens": 1, "completion_tokens": 1},
                      tool_calls=call("finish", {"summary": "done"})))
tc = extra.get("tool_calls") or {}
check("class 2 counted as invalid_arguments", tc.get("invalid_arguments") == 1, str(tc))
check("class 2 does not land in tool_errors_other",
      tc.get("tool_errors_other") == 0, str(tc))

# class 3 — the model tried, the provider's parser missed it
status, extra, _ = drive(lambda n: Turn(
    text='```json\n{"action": "run_command", "command": "ls"}\n```<tool_call|>',
    raw={}, finish_reason="stop", tool_calls=[],
    usage={"prompt_tokens": 1, "completion_tokens": 1}))
tc = extra.get("tool_calls") or {}
check("class 3 counted as unparsed_in_content",
      tc.get("unparsed_in_content") == 2, str(tc))     # once per turn, incl. the nudge
check("class 3 run still ends stopped_no_tool_call",
      status == "stopped_no_tool_call", status)

# a clean run must report a zero rate, not a missing field
status, extra, _ = drive(lambda n: Turn(
    text="", raw={}, finish_reason="tool_calls",
    usage={"prompt_tokens": 1, "completion_tokens": 1},
    tool_calls=call("finish", {"summary": "done"})))
tc = extra.get("tool_calls") or {}
check("clean run reports attempts and a zero rate",
      tc.get("attempts") == 1 and tc.get("malformed") == 0
      and tc.get("malformation_rate") == 0.0, str(tc))

# a tool that refuses (path escape) is NOT malformation
status, extra, _ = drive(lambda n: Turn(
    text="", raw={}, finish_reason="tool_calls",
    usage={"prompt_tokens": 1, "completion_tokens": 1},
    tool_calls=call("write_file", {"path": "../../etc/passwd", "content": "x"})
) if n == 1 else Turn(text="", raw={}, finish_reason="tool_calls",
                      usage={"prompt_tokens": 1, "completion_tokens": 1},
                      tool_calls=call("finish", {"summary": "done"})))
tc = extra.get("tool_calls") or {}
check("a refused call is not counted as malformed",
      tc.get("malformed") == 0 and tc.get("tool_errors_other") == 1, str(tc))

# --- 7. a crashed SERVER is not a bad request -------------------------------------
# LM Studio reports a crashed or unloaded model as HTTP 400 — the same status it uses
# for a genuinely malformed request. Treating all 4xx as permanent killed a run
# outright. Matching is on the body so a real 400 still fails fast.
import io  # noqa: E402
import urllib.error  # noqa: E402

import harness.llm as _L  # noqa: E402

CRASH_BODY = json.dumps({"error": "The model has crashed without additional "
                                  "information. (Exit code: 18446744072635812000)"})
BADPARAM_BODY = json.dumps({"error": "`top_p` is deprecated for this model"})


def _http_error(code, body):
    return urllib.error.HTTPError("http://x/v1/chat/completions", code, "Bad Request",
                                  {}, io.BytesIO(body.encode()))


# Body classification. The first version of this list matched the substring "no model
# loaded" while the server said "No models loaded" — one character of pluralisation, and
# a real outage was classified as a bad request and never retried.
for _body, _want, _label in [
    ('{"error":"The model has crashed without additional information. (Exit code: 1)"}',
     True, "model crashed"),
    ('{"error":{"message":"No models loaded. Please load a model in the developer '
     'page or use the \'lms load\' command."}}', True, "no modelS loaded (plural)"),
    ('{"error":"no model is loaded"}', True, "no model is loaded"),
    ('{"error":"Failed to load model"}', True, "failed to load"),
    ('{"error":"Model \'gemma-4-31b\' not found"}', True, "model not found"),
    ('{"error":"`top_p` is deprecated for this model"}', False,
     "rejected decoding param is NOT a server failure"),
    ('{"error":"Invalid value for temperature"}', False, "bad parameter"),
    ('{"error":"context length exceeded"}', False, "context overflow"),
]:
    check(f"server_is_down: {_label}", _L.server_is_down(_body) is _want)

_real_urlopen, _real_sleep = _L.urllib.request.urlopen, _L.time.sleep
_L.time.sleep = lambda s: None            # do not actually wait out the backoff
try:
    seen = {"n": 0}

    def _crash_twice(req, timeout=None):
        seen["n"] += 1
        if seen["n"] <= 2:
            raise _http_error(400, CRASH_BODY)

        class _R:
            def read(self):
                return json.dumps({"choices": [{"finish_reason": "stop", "message": {
                    "content": "ok", "tool_calls": []}}], "usage": {}}).encode()

            def __enter__(self):
                return self

            def __exit__(self, *a):
                return False
        return _R()

    _L.urllib.request.urlopen = _crash_twice
    client = _L.RealClient(base_url="http://x/v1", model="m", max_retries=5)
    turn = client.chat([{"role": "user", "content": "hi"}], [])
    check("a model-crash 400 is retried until the server reloads",
          turn.text == "ok" and seen["n"] == 3, f"attempts={seen['n']}")

    seen["n"] = 0

    def _always_bad(req, timeout=None):
        seen["n"] += 1
        raise _http_error(400, BADPARAM_BODY)

    _L.urllib.request.urlopen = _always_bad
    try:
        client.chat([{"role": "user", "content": "hi"}], [])
        check("a genuine 400 still fails immediately", False, "it was retried")
    except urllib.error.HTTPError as exc:
        check("a genuine 400 still fails immediately, without retrying",
              seen["n"] == 1, f"attempts={seen['n']}")
        check("a genuine 400 is not flagged as a server crash",
              getattr(exc, "harness_model_crash", None) is False)
        check("the response body is stashed for the manifest",
              "deprecated" in (getattr(exc, "harness_body", "") or ""))
    # Preflight: catch a dead or mis-named server BEFORE the workspace is wiped.
    def _models(payload=None, err=None):
        def f(req, timeout=None):
            if err:
                raise err

            class _R:
                def read(self):
                    return json.dumps(payload).encode()

                def __enter__(self):
                    return self

                def __exit__(self, *a):
                    return False
            return _R()
        return f

    for _model, _payload, _want, _label in [
        ("gemma-4-31b", {"data": [{"id": "gemma-4-31b"}, {"id": "z"}]}, True,
         "exact match"),
        # A strict equality check rejected a model the server WOULD have served: LM
        # Studio lists google/gemma-4-31b and answers to the bare suffix, as every
        # earlier run in this project did. Blocking those is worse than the typo it
        # was guarding against, and the obvious workaround (use the namespaced id)
        # collides with run.sh's local-vs-remote routing.
        ("gemma-4-31b", {"data": [{"id": "google/gemma-4-31b"}]}, True,
         "short name against a namespaced id"),
        ("google/gemma-4-31b", {"data": [{"id": "gemma-4-31b"}]}, True,
         "namespaced request against a short id"),
        ("gemma-4-31b",
         {"data": [{"id": "google/gemma-4-31b"}, {"id": "meta/gemma-4-31b"}]}, False,
         "ambiguous suffix is refused, not guessed"),
        ("gemma-4-31b", {"data": [{"id": "google/gemma-4-27b"}]}, False,
         "a genuine typo is still caught"),
        ("gemma-4-31b", {"data": []}, False, "server up but nothing loaded"),
        ("gemma-4-31b", {"data": [{"id": "gemma-4-31B-it"}]}, False, "id differs by case"),
    ]:
        _L.urllib.request.urlopen = _models(_payload)
        _ok, _msg = _L.RealClient(base_url="http://x/v1", model=_model).preflight()
        check(f"preflight: {_label}", _ok is _want, _msg[:140])
    for _fn, _want, _label in [
        (_models(err=urllib.error.URLError("Connection refused")), False, "unreachable"),
        (_models({"models": ["x"]}), True, "unknown shape passes rather than blocks"),
    ]:
        _L.urllib.request.urlopen = _fn
        _ok, _msg = _L.RealClient(base_url="http://x/v1", model="m").preflight()
        check(f"preflight: {_label}", _ok is _want, _msg[:120])
finally:
    _L.urllib.request.urlopen, _L.time.sleep = _real_urlopen, _real_sleep


# ---------------------------------------------------------------------------
# reasoning replay (2026-08-13): the model's chain of thought goes back with the
# assistant turn that produced it. This is a TREATMENT, recorded per run.
# ---------------------------------------------------------------------------

from harness.llm import reasoning_replay_rejected as _rrr  # noqa: E402


def _replay_run(replay):
    import tempfile
    from pathlib import Path as _P
    from harness.llm import Turn as _T, ToolCall as _TC, MockClient as _MC
    from harness.tools import Tools as _Tools
    from harness.runlog import RunLog as _RL
    from harness.agent import run_agent as _ra
    msgs = [{"role": "system", "content": "s"}, {"role": "user", "content": "u"}]
    step = lambda m: _T(text="", reasoning="thinking hard about it", raw={},
                        tool_calls=[_TC(id="c1", name="finish", arguments={"summary": "d"})])
    log = _RL(_P(tempfile.mkdtemp()), {})
    st, ex = _ra(_MC([step]), _Tools(workspace=_P(tempfile.mkdtemp())), "execution",
                 msgs, log, max_steps=2, replay_reasoning=replay)
    return [m for m in msgs if m["role"] == "assistant"][0], ex


_a, _e = _replay_run(True)
check("replay on: assistant turn carries reasoning_content",
      _a.get("reasoning_content") == "thinking hard about it", str(_a)[:160])
check("replay on: tool_calls still present alongside reasoning", bool(_a.get("tool_calls")))
check("replay on: counters record what was sent back",
      _e["reasoning_replayed_turns"] == 1 and _e["reasoning_replayed_chars"] > 0)
check("replay on: manifest flag set", _e["reasoning_replayed"] is True)

_a, _e = _replay_run(False)
check("replay off: assistant turn carries no reasoning_content",
      "reasoning_content" not in _a, str(_a)[:160])
check("replay off: counters stay at zero",
      _e["reasoning_replayed_turns"] == 0 and _e["reasoning_replayed_chars"] == 0)
check("replay off: reasoning is still COUNTED for audit",
      _e["reasoning_turns"] == 1 and _e["reasoning_chars"] > 0)

# The rejection classifier must fire on template refusals and stay silent on error
# classes that already have their own handling — misattributing a crashed server to
# this setting would stop it being retried, which is the opposite of what we want.
check("rejection: llama.cpp content+thinking template error matched",
      _rrr("Cannot pass both content and thinking in an assistant message with tool calls!"))
check("rejection: generic thinking-with-tool-calls refusal matched",
      _rrr('{"error":{"message":"thinking is not supported with tool calls"}}'))
check("rejection: unknown reasoning_content field matched",
      _rrr("Unknown field reasoning_content"))
check("rejection: a crashed server is NOT blamed on replay", not _rrr("No models loaded"))
check("rejection: a rejected decoding param is NOT blamed on replay",
      not _rrr("temperature must be >= 0"))
check("rejection: empty body is not a match", not _rrr(""))


# ---------------------------------------------------------------------------
# --extra-body (2026-08-13): non-schema request fields. An escape hatch that can
# silently rewrite the treatment is worse than none, so the guard is the feature.
# ---------------------------------------------------------------------------

from harness.llm import validate_extra_body as _veb, RealClient as _RC  # noqa: E402

check("extra_body: a sampler field the OpenAI schema omits is allowed",
      _veb({"top_k": 1}) == [])
check("extra_body: chat_template_kwargs (the thinking toggle) is allowed",
      _veb({"chat_template_kwargs": {"enable_thinking": False}}) == [])
check("extra_body: several allowed keys at once",
      _veb({"cache_prompt": False, "min_p": 0.0, "repeat_penalty": 1.0}) == [])

for _k in ("model", "messages", "max_tokens"):
    _p = _veb({_k: "x"})
    check(f"extra_body: {_k} refused (would CLOBBER the harness's value)",
          len(_p) == 1 and "OVERWRITE" in _p[0], str(_p)[:120])
for _k in ("temperature", "top_p", "tools", "tool_choice"):
    _p = _veb({_k: "x"})
    check(f"extra_body: {_k} refused (would be SILENTLY IGNORED)",
          len(_p) == 1 and "IGNORED" in _p[0], str(_p)[:120])
for _k in ("stream", "n"):
    check(f"extra_body: {_k} refused (loop parses one non-streamed choice)",
          len(_veb({_k: 1})) == 1)

check("extra_body: every problem is reported, not just the first",
      len(_veb({"top_k": 1, "temperature": 0.7, "model": "x"})) == 2)
check("extra_body: a non-object is refused", len(_veb([])) == 1)
check("extra_body: empty dict is fine", _veb({}) == [])

# The wire path: allowed keys must actually arrive, and must NOT be able to displace
# the decoding registry values the study pins.
_sent = {}


class _FakeResp:
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def read(self):
        return json.dumps({"choices": [{"message": {"content": "hi"},
                                        "finish_reason": "stop"}]}).encode()


_saved = _L.urllib.request.urlopen
try:
    _L.urllib.request.urlopen = lambda req, timeout=None: (
        _sent.update(json.loads(req.data)), _FakeResp())[1]
    _RC(base_url="http://x/v1", model="m",
        extra_body={"top_k": 1, "seed": 7}).chat([{"role": "user", "content": "hi"}], [])
finally:
    _L.urllib.request.urlopen = _saved

check("extra_body: allowed key reaches the request body", _sent.get("top_k") == 1)
check("extra_body: seed still reaches the request body", _sent.get("seed") == 7)
check("extra_body: pinned temperature survives the merge", _sent.get("temperature") == 0.0)
check("extra_body: pinned max_tokens survives the merge", _sent.get("max_tokens") == 32768)

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILURE(S): " + ", ".join(FAILURES))
    sys.exit(1)
print("ALL CHECKS PASSED")
