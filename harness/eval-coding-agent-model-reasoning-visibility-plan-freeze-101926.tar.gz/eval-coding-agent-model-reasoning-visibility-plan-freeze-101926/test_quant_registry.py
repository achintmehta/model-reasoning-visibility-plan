#!/usr/bin/env python3
"""Checks for the quantization-provenance path: registry lookup, GGUF header parsing,
the /props serving probe, and the declaration-vs-measurement comparison.

Run: python3 test_quant_registry.py
"""

from __future__ import annotations

import json
import struct
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent / "tools"))

from harness.agent import load_quant_detail, check_serving_probe  # noqa: E402
from harness.llm import RealClient  # noqa: E402
import hash_quants  # noqa: E402

PASS = FAIL = 0


def ok(cond, label):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"[ok ] {label}")
    else:
        FAIL += 1
        print(f"[FAIL] {label}")


# ---------------------------------------------------------------------------
# registry lookup
# ---------------------------------------------------------------------------

TMP = Path("/tmp/quantreg-test")
TMP.mkdir(exist_ok=True)
REG = TMP / "quant-registry.json"
REG.write_text(json.dumps({
    "_comment": "test fixture",
    "gemma-4-31b": {
        "Q8_0": {"publisher": "Unsloth", "method": "PTQ", "imatrix": True,
                 "file": "/models/gemma-4-31B-it-Q8_0.gguf", "file_sha256": "aa" * 32},
        "Q5_K_M": {"publisher": "Unsloth", "method": "PTQ",
                   "file": "/models/gemma-4-31B-it-Q5_K_M.gguf"},
    },
    "devstral-24b": {"Q4_K_M": {"publisher": "Unsloth"}},
}), encoding="utf-8")

d = load_quant_detail(str(REG), "gemma-4-31b", "Q8_0")
ok(d["status"] == "ok", "registry: exact hit resolves")
ok(d["publisher"] == "Unsloth" and d["file_sha256"] == "aa" * 32,
   "registry: entry fields copied through")
ok(len(d["registry_sha"]) > 0, "registry: file sha recorded (declaration is pinned)")

d2 = load_quant_detail(str(REG), "gemma-4-31b", "Q8_0")
ok(d2["registry_sha"] == d["registry_sha"], "registry: sha stable across reads")
REG.write_text(REG.read_text() + "\n")
ok(load_quant_detail(str(REG), "gemma-4-31b", "Q8_0")["registry_sha"] != d["registry_sha"],
   "registry: editing the registry changes the recorded sha")

ok(load_quant_detail(str(REG), "google/gemma-4-31b", "Q8_0")["status"] == "ok",
   "registry: namespaced model id matches on the final segment")
ok(load_quant_detail(str(REG), "gemma-4-31b", "Q6_K")["status"] == "rung_missing",
   "registry: unknown rung reports rung_missing, not a silent null")
ok(load_quant_detail(str(REG), "qwen3.6-27b", "Q8_0")["status"] == "model_missing",
   "registry: unknown model reports model_missing")
ok(load_quant_detail(str(REG), "gemma-4-31b", None)["status"] == "no_label",
   "registry: no --quantization reports no_label")
ok(load_quant_detail(str(TMP / "nope.json"), "gemma-4-31b", "Q8_0")["status"] == "no_registry",
   "registry: missing file reports no_registry")
ok(load_quant_detail(str(TMP / "nope.json"), "gemma-4-31b", None) is None,
   "registry: no registry AND no label -> None (field stays null)")
BAD = TMP / "bad.json"
BAD.write_text("{not json", encoding="utf-8")
ok(load_quant_detail(str(BAD), "gemma-4-31b", "Q8_0")["status"] == "unreadable",
   "registry: unparseable file reports unreadable rather than raising")

# A registry lookup must never take the run down, whatever it is handed.
try:
    load_quant_detail(str(REG), "", "")
    load_quant_detail(None, "x", "y")
    raised = False
except Exception:  # noqa: BLE001
    raised = True
ok(not raised, "registry: degenerate inputs do not raise")

# ---------------------------------------------------------------------------
# declaration vs measurement
# ---------------------------------------------------------------------------

detail = {"quantization": "Q8_0", "file": "/models/gemma-4-31B-it-Q8_0.gguf"}
ok("matches" in check_serving_probe(
    {"model_path": "/models/gemma-4-31B-it-Q8_0.gguf"}, detail),
   "probe: identical path matches")
ok("matches" in check_serving_probe(
    {"model_path": "D:\\llm_models\\unsloth\\gemma-4-31B-it-Q8_0.gguf"}, detail),
   "probe: Windows path vs POSIX path matches on basename")
note = check_serving_probe({"model_path": "/models/gemma-4-31B-it-Q5_K_M.gguf"}, detail)
ok(note is not None and note.startswith("MISMATCH"),
   "probe: WRONG RUNG LOADED is caught and named")
ok(check_serving_probe(None, detail) is None, "probe: no probe -> no note")
ok(check_serving_probe({"model_path": "/a.gguf"}, {"status": "no_registry"}) is None,
   "probe: no declared file -> no note")

# ---------------------------------------------------------------------------
# GGUF header parsing
# ---------------------------------------------------------------------------

UINT32, UINT64, STRING, ARRAY, BOOL = 4, 10, 8, 9, 7


def _s(x: str) -> bytes:
    b = x.encode()
    return struct.pack("<Q", len(b)) + b


def _kv(k, t, payload):
    return _s(k) + struct.pack("<I", t) + payload


def make_gguf(path: Path, ftype: int, extra=()):
    pairs = [_kv("general.architecture", STRING, _s("gemma4")),
             _kv("general.quantized_by", STRING, _s("Unsloth")),
             # a long array before the keys we care about: proves the reader stays
             # aligned through a real vocabulary rather than only tiny fixtures
             _kv("tokenizer.ggml.tokens", ARRAY,
                 struct.pack("<I", STRING) + struct.pack("<Q", 5000)
                 + b"".join(_s(f"t{i}") for i in range(5000))),
             _kv("general.file_type", UINT32, struct.pack("<I", ftype))] + list(extra)
    path.write_bytes(b"GGUF" + struct.pack("<I", 3) + struct.pack("<Q", 833)
                     + struct.pack("<Q", len(pairs)) + b"".join(pairs) + b"\x00" * 1024)


g8 = TMP / "m-Q8_0.gguf"
make_gguf(g8, 7, [_kv("quantize.imatrix.file", STRING, _s("imatrix_unsloth.gguf"))])
label, entry = hash_quants.entry_for(g8, want_sha=True, label_override=None)
ok(label == "Q8_0", "gguf: file_type 7 -> Q8_0 label read from the file, not the name")
ok(entry["publisher"] == "Unsloth", "gguf: publisher read from general.quantized_by")
ok(entry["imatrix"] is True, "gguf: imatrix detected")
ok(entry["architecture"] == "gemma4", "gguf: architecture read past a 5000-item array")
ok(len(entry["file_sha256"]) == 64, "gguf: sha256 computed")
ok(entry["method"] == "PTQ" and entry["method_source"] == "assumed",
   "gguf: method defaults to PTQ and is flagged ASSUMED (D9 cannot be measured here)")

g5 = TMP / "m-Q5_K_M.gguf"
make_gguf(g5, 17)
label5, entry5 = hash_quants.entry_for(g5, want_sha=False, label_override=None)
ok(label5 == "Q5_K_M", "gguf: file_type 17 -> Q5_K_M")
ok(entry5["imatrix"] is False, "gguf: absent imatrix reported as False")
ok(entry5["file_sha256"] is None, "gguf: --no-sha256 leaves the hash null")

gbf = TMP / "m-BF16.gguf"
make_gguf(gbf, 32)
ok(hash_quants.entry_for(gbf, False, None)[0] == "BF16", "gguf: file_type 32 -> BF16")

gu = TMP / "m-weird.gguf"
make_gguf(gu, 199)
ok(hash_quants.entry_for(gu, False, None)[0] == "ftype:199",
   "gguf: unknown ftype surfaces as ftype:N rather than being guessed")

notgguf = TMP / "not.gguf"
notgguf.write_bytes(b"XXXX" + b"\x00" * 100)
try:
    hash_quants.entry_for(notgguf, False, None)
    bad = False
except hash_quants.GGUFError:
    bad = True
ok(bad, "gguf: non-GGUF file raises GGUFError (caught and skipped by the CLI)")

# ---------------------------------------------------------------------------
# serving probe over HTTP
# ---------------------------------------------------------------------------

PROPS = {"model_path": "/models/gemma-4-31B-it-Q8_0.gguf",
         "chat_template": "{%- macro format_parameters(x) -%}" + "x" * 5000,
         "total_slots": 1,
         "default_generation_settings": {"n_ctx": 65536, "temperature": 0.0}}


class H(BaseHTTPRequestHandler):
    routes: dict = {}

    def do_GET(self):  # noqa: N802
        payload = self.routes.get(self.path)
        if payload is None:
            self.send_response(404); self.end_headers(); return
        b = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def log_message(self, *a):  # silence
        pass


def serve(routes):
    H.routes = routes
    srv = HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]

# llama-server layout: /props at the ROOT while the client's base_url carries /v1
srv, port = serve({"/props": PROPS})
c = RealClient(base_url=f"http://127.0.0.1:{port}/v1", model="gemma-4-31b", api_key="x")
p = c.props()
ok(p is not None, "props: found at server root even though base_url ends in /v1")
ok(p["model_path"] == PROPS["model_path"], "props: model_path captured")
ok(p["n_ctx"] == 65536, "props: n_ctx lifted out of default_generation_settings")
ok(len(p["chat_template_sha"]) == 16 and p["chat_template_chars"] > 5000,
   "props: chat template HASHED, not stored verbatim")
ok(all(not isinstance(v, (dict, list)) for k, v in p.items() if k != "keys_seen"),
   "props: no nested blobs leak into the manifest")
srv.shutdown()

# /v1/props layout
srv, port = serve({"/v1/props": PROPS})
c = RealClient(base_url=f"http://127.0.0.1:{port}/v1", model="m", api_key="x")
ok(c.props() is not None, "props: also found under /v1/props")
srv.shutdown()

# provider without the endpoint (LM Studio, OpenRouter) -> None, never an exception
srv, port = serve({})
c = RealClient(base_url=f"http://127.0.0.1:{port}/v1", model="m", api_key="x")
ok(c.props() is None, "props: 404 everywhere -> None, not an error")
srv.shutdown()

c = RealClient(base_url="http://127.0.0.1:9/v1", model="m", api_key="x")
ok(c.props(timeout=2) is None, "props: dead server -> None, run continues")

srv, port = serve({"/props": ["unexpected", "shape"]})
c = RealClient(base_url=f"http://127.0.0.1:{port}/v1", model="m", api_key="x")
ok(c.props() is None, "props: non-dict JSON -> None rather than a crash")
srv.shutdown()

print()
print(f"{PASS} passed, {FAIL} failed")
print("ALL CHECKS PASSED" if not FAIL else "FAILURES PRESENT")
sys.exit(1 if FAIL else 0)
