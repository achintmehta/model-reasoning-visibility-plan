"""Verify the experiment was clean across a batch of runs.

THE INVARIANT (post condition-briefing revision):
  1. task_sha is constant WITHIN each task — a multi-task batch is fine; each task must
     be byte-identical across all of its runs (conditions are only ever compared within a
     task, never pooled across tasks).
  2. base_prompt_sha is identical across every run — the base system prompt never varies.
  3. Exactly ONE briefing_mode across the batch, and the briefing hashes match it:
       universal     -> every run carries sha(UNIVERSAL_BRIEFING): the WHOLE prompt is
                        byte-identical across conditions (the strongest claim).
       per_condition -> each condition single-valued AND matching the registry.
       none          -> ablation arm, reported as such.
  4. No run is human-contaminated (interactive=true or human_turns>0).
  5. GATING INTEGRITY: every tool call outside the run's allowed set (and every
     shell call before a delayed_verification unlock) was REFUSED by the loop, never
     executed. Refused attempts are reported as behavioral counts; an executed
     out-of-condition tool is a critical instrument bug and fails the batch.
  6. Decoding (temperature/top_p/max_tokens — seed excluded, it is the per-replicate
     variable) is constant WITHIN each model. Cross-model differences are allowed: they
     are the registered per-model provider defaults (some providers reject temp/top_p),
     applied uniformly across a model's runs, so within-model condition contrasts stay
     clean. Only a model that varies its OWN decoding across runs fails the batch.

Older-instrument runs (no base_prompt_sha field) are reported separately: for those,
only the whole-prompt system_prompt_sha and task_sha consistency can be checked.

Run after every batch and put the output in the paper's reproducibility section.
"""

import json
import sys
from collections import defaultdict
from pathlib import Path


_REFUSAL_MARKER = "not available"   # loop's refusal text: "ERROR: tool '<x>' not available"
_SHELL_TOOLS = {"run_command", "run_background_command", "run_command_and_capture_output",
                "list_background_commands", "stop_background_command"}


def check_gating(manifest_path, d):
    """Verify executed tools were a subset of the condition's allowed set.

    Uses commands.json (every ATTEMPTED call incl. step) + trace.jsonl tool_results
    (to see whether each out-of-set attempt was refused). Returns
    (breaches: list, blocked_attempts: int). Older runs without commands.json
    return ([], -1) meaning 'not checkable'."""
    run_logs = manifest_path.parent
    cmds_f = run_logs / "commands.json"
    trace_f = run_logs / "trace.jsonl"
    if not cmds_f.exists():
        return [], -1
    try:
        cmds = json.loads(cmds_f.read_text())
    except json.JSONDecodeError:
        return [], -1
    allowed = set(d.get("allowed_tools") or [])
    unlock = d.get("verification_unlocked_at_step")
    delayed = d.get("condition") in ("delayed_verification",)

    def out_of_set(c):
        if c["tool"] not in allowed:
            return True
        if delayed and c["tool"] in _SHELL_TOOLS:
            # pre-unlock shell calls are out-of-set for phase 1
            return unlock is None or c["step"] < unlock
        return False

    suspects = [c for c in cmds if out_of_set(c)]
    if not suspects:
        return [], 0
    # confirm each suspect was refused, via the trace's tool_results at that step
    refused_steps = {}          # step -> set of refused tool names
    if trace_f.exists():
        with trace_f.open() as fh:
            for line in fh:
                if '"tool_result"' not in line:
                    continue
                try:
                    j = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if j.get("kind") == "tool_result" and _REFUSAL_MARKER in str(j.get("result", ""))[:120]:
                    refused_steps.setdefault(j.get("step"), set()).add(j.get("tool"))
    breaches, blocked = [], 0
    for c in suspects:
        if c["tool"] in refused_steps.get(c["step"], set()):
            blocked += 1
        else:
            breaches.append(c)
    return breaches, blocked


def main(root: str, expect_mode: str | None = None):
    """Verify a batch's input identity.

    expect_mode, when given, additionally requires the batch to have been run in that
    briefing mode. The existing checks prove a batch is INTERNALLY consistent — one
    mode, one hash per condition, matching the registry — but a batch run entirely in
    the wrong mode is internally consistent too. Once a study registers its mode, that
    registration should be mechanically enforced rather than remembered, because the
    mode is set by an environment variable that is easy to add or drop by accident.
    """
    manifests = list(Path(root).rglob("manifest.json"))
    if not manifests:
        print("no manifests found"); return

    task_shas, base_shas, legacy_sys_shas = set(), set(), set()
    briefing_by_cond = defaultdict(set)
    conds = defaultdict(int)
    legacy, contaminated, ablation = [], [], []
    modes, universal_shas = set(), set()
    decoding_configs = {}          # frozen (temp, top_p, max_tokens) -> count
    overridden = []
    task_sha_by_task = defaultdict(set)   # task name -> set of task_sha (per-task identity)
    dec_by_model = defaultdict(set)       # model -> set of decoding configs (per-model identity)
    ovr_by_model = defaultdict(set)       # model -> set of decoding_overridden (per-model)
    root_path = Path(root)

    rows = []
    gating_breaches, gating_blocked, gating_unchecked = [], 0, 0
    for m in manifests:
        d = json.loads(m.read_text())
        rows.append((m, d))
        br, bl = check_gating(m, d)
        if bl == -1:
            gating_unchecked += 1
        else:
            gating_blocked += bl
            for c in br:
                gating_breaches.append((str(m), c))
        conds[d.get("condition")] += 1
        task_shas.add(d.get("task_sha"))
        try:
            _task = m.relative_to(root_path).parts[0]
        except Exception:
            _task = "?"
        task_sha_by_task[_task].add(d.get("task_sha"))
        if d.get("interactive") or (d.get("human_turns") or 0) > 0:
            contaminated.append(str(m))
        dec = d.get("decoding") or {}
        key = (dec.get("temperature"), dec.get("top_p"), dec.get("max_tokens"))
        decoding_configs[key] = decoding_configs.get(key, 0) + 1
        dec_by_model[d.get("model")].add(key)
        if d.get("decoding_overridden"):
            overridden.append((str(m), d["decoding_overridden"]))
            ovr_by_model[d.get("model")].add(
                json.dumps(d["decoding_overridden"], sort_keys=True))
        if "base_prompt_sha" in d:
            base_shas.add(d["base_prompt_sha"])
            mode = d.get("briefing_mode") or ("none" if d.get("no_briefing") else "per_condition")
            modes.add(mode)
            if mode == "none":
                ablation.append(str(m))
            elif mode == "universal":
                universal_shas.add(d.get("condition_briefing_sha"))
            else:
                briefing_by_cond[d.get("condition")].add(d.get("condition_briefing_sha"))
        else:
            legacy.append(str(m))
            legacy_sys_shas.add(d.get("system_prompt_sha"))

    print(f"runs: {len(manifests)}  (new-instrument: {len(manifests)-len(legacy)}, "
          f"legacy: {len(legacy)})")
    print(f"conditions: {dict(conds)}")

    ok = True

    # 1. task identity — PER TASK. A multi-task batch is fine; what must hold is that
    #    each task is byte-identical across all of ITS runs (conditions are only ever
    #    compared within a task, never pooled across tasks).
    print(f"distinct task_sha: {task_shas}  ({len(task_sha_by_task)} task(s) in batch)")
    task_drift = {t: sorted(s) for t, s in task_sha_by_task.items() if len(s) != 1}
    _sha_to_tasks = defaultdict(set)
    for t, s in task_sha_by_task.items():
        for _sh in s:
            _sha_to_tasks[_sh].add(t)
    shared_sha = {sh: sorted(ts) for sh, ts in _sha_to_tasks.items() if len(ts) > 1}
    if task_drift:
        ok = False
        print("WARNING: task text DRIFTS within a task — same task, different task_sha "
              "across its runs (a hidden change to the spec mid-batch):")
        for t, s in sorted(task_drift.items()):
            print(f"  {t}: {s}")
    elif shared_sha:
        ok = False
        print(f"WARNING: a task_sha is shared by multiple task dirs (unexpected): {shared_sha}")
    else:
        print(f"note: {len(task_sha_by_task)} task(s), each with exactly ONE task_sha — "
              f"task text is constant within every task. Compare conditions only WITHIN a task.")

    # 2. base prompt identity
    if base_shas:
        print(f"distinct base_prompt_sha: {base_shas}")
        if len(base_shas) != 1:
            ok = False
            print("WARNING: base system prompt differs across runs. (base_prompt_sha "
                  "hashes the TEMPLATE, which is workspace-independent - a difference "
                  "here means the prompt text itself changed between runs.)")

    # 3. briefing mode + hashes
    if len(modes) > 1:
        ok = False
        print(f"WARNING: mixed briefing modes in one batch: {modes}. Runs under "
              f"different modes received different prompt scaffolding - split the "
              f"batch.")
    if expect_mode is not None:
        wrong = sorted(m for m in modes if m != expect_mode)
        if wrong:
            ok = False
            print(f"WARNING: this batch was run in briefing mode(s) {wrong}, but the "
                  f"registered mode for this study is '{expect_mode}'. The prompt "
                  f"scaffolding differs from every other batch - these runs are not "
                  f"comparable and must be re-run.")
        else:
            print(f"briefing mode matches the registered '{expect_mode}'.")
    try:
        from harness.conditions import CONDITION_BRIEFINGS, UNIVERSAL_BRIEFING
        from harness.runlog import sha
        registry = {c: sha(b) for c, b in CONDITION_BRIEFINGS.items()}
        universal_expected = sha(UNIVERSAL_BRIEFING)
    except Exception as e:  # noqa: BLE001 - verification should degrade, not crash
        registry = None
        universal_expected = None
        print(f"(could not load briefing registry: {e}; checking consistency only)")

    if universal_shas:
        print(f"briefing mode: universal (whole prompt byte-identical across conditions)")
        if len(universal_shas) != 1:
            ok = False
            print(f"WARNING: multiple universal-briefing hashes: {universal_shas}")
        elif universal_expected and next(iter(universal_shas)) != universal_expected:
            ok = False
            print(f"WARNING: universal briefing hash does not match the registry - "
                  f"the briefing text changed between this batch and the current "
                  f"harness.")

    for cond, shas in sorted(briefing_by_cond.items()):
        if len(shas) != 1:
            ok = False
            print(f"WARNING: condition '{cond}' has multiple briefing hashes: {shas}")
            continue
        got = next(iter(shas))
        if registry is not None:
            want = registry.get(cond)
            if want is None:
                ok = False
                print(f"WARNING: condition '{cond}' is not in the current briefing "
                      f"registry (renamed or retired?)")
            elif got != want:
                ok = False
                print(f"WARNING: condition '{cond}' briefing hash {got} does not match "
                      f"the registered briefing {want} — the briefing text changed "
                      f"between this batch and the current harness.")

    # 4. decoding consistency — PER MODEL. Cross-model differences are allowed and
    #    expected: they are the registered per-model provider defaults (some providers
    #    reject temperature/top_p), applied uniformly across a model's runs, so
    #    within-model condition contrasts stay clean. What fails the batch is a model
    #    that varies its OWN decoding across runs (a hidden second treatment).
    print(f"decoding configs across batch (temperature, top_p, max_tokens -> n_runs): "
          f"{len(decoding_configs)} distinct")
    for k, n in sorted(decoding_configs.items(), key=lambda x: -x[1]):
        print(f"  {k}: {n} run(s)")
    dec_drift = {mo: sorted(map(str, cfgs)) for mo, cfgs in dec_by_model.items()
                 if len(cfgs) != 1}
    if dec_drift:
        ok = False
        print("WARNING: a model used MORE THAN ONE decoding config across its runs — "
              "same model, different effective sampling (a hidden second treatment):")
        for mo, cfgs in sorted(dec_drift.items()):
            print(f"  {mo}: {cfgs}")
    else:
        print("note: every model used ONE decoding config across all its runs; "
              "cross-model differences are the registered per-model provider defaults "
              "(within-model contrasts clean):")
        for mo, cfgs in sorted(dec_by_model.items(), key=lambda x: str(x[0])):
            print(f"  {mo}: {sorted(cfgs)[0]}")
    # decoding_overridden mirrors the launch-time omission for provider-rejecting models;
    # it is NOT a failure on its own — only INCONSISTENCY within a model is (caught above).
    ovr_inconsistent = {mo: sorted(v) for mo, v in ovr_by_model.items() if len(v) > 1}
    if ovr_inconsistent:
        ok = False
        print("WARNING: a model has INCONSISTENT decoding_overridden across its runs:")
        for mo, v in sorted(ovr_inconsistent.items()):
            print(f"  {mo}: {v}")
    elif overridden:
        print(f"note: {len(overridden)} run(s) carry decoding_overridden (the registered "
              f"per-model provider defaults), consistent within each model.")

    # 5. gating integrity
    if gating_breaches:
        ok = False
        print(f"WARNING: {len(gating_breaches)} GATING BREACH(ES) - out-of-condition "
              f"tool calls that were NOT refused (critical instrument bug; exclude "
              f"these runs and audit the batch):")
        for path, c in gating_breaches[:10]:
            print(f"  {path}: step {c['step']} tool {c['tool']} args {c['args_head'][:60]!r}")
    if gating_blocked:
        print(f"note: {gating_blocked} out-of-condition tool attempt(s) were correctly "
              f"refused across the batch - behavioral data (capability inference), "
              f"not an error. Counts per run are in commands.json.")
    if gating_unchecked:
        print(f"note: {gating_unchecked} run(s) predate commands.json - gating not "
              f"mechanically checkable for them (audit via trace if needed).")

    # 5b. decoding self-heal consistency: if a model rejected a param at runtime
    # (decoding_dropped_params), every run of that model must show the SAME drops -
    # otherwise the same model sampled under different effective decoding across runs.
    drops_by_model = {}
    for _, d in rows:
        if "decoding_dropped_params" in d:
            drops_by_model.setdefault(d.get("model"), set()).add(
                tuple(d["decoding_dropped_params"]))
    for model, configs in sorted(drops_by_model.items()):
        if len(configs) > 1:
            ok = False
            print(f"WARNING: model '{model}' has INCONSISTENT runtime decoding drops "
                  f"across runs: {sorted(configs)} - same model, different effective "
                  f"sampling. Investigate (provider routing?) before comparing its runs.")
        elif next(iter(configs)):
            print(f"note: model '{model}' rejected decoding param(s) "
                  f"{list(next(iter(configs)))} at runtime - provider defaults applied, "
                  f"uniformly across its runs (registered self-heal; see llm.py). "
                  f"Within-model condition contrasts remain clean.")

    # 6. contamination
    if contaminated:
        ok = False
        print(f"WARNING: {len(contaminated)} human-contaminated run(s) "
              f"(interactive/human_turns) — exclude from analysis:")
        for c in contaminated:
            print(f"  {c}")

    if ablation:
        print(f"note: {len(ablation)} briefing-ablation run(s) (no_briefing=true) — a "
              f"deliberate instrument-validation arm. Analyze separately from "
              f"briefing-on runs; do not pool them in condition comparisons.")

    if legacy:
        print(f"note: {len(legacy)} legacy run(s) carry only a whole-prompt hash "
              f"(distinct system_prompt_sha: {legacy_sys_shas}); group them by "
              f"harness_git and do not mix with new-instrument runs in one table.")

    print("CLEAN: task constant within each task, base prompt constant, briefings match "
          "the registry, and decoding constant within each model."
          if ok else "NOT CLEAN: investigate the warnings above before analyzing.")


if __name__ == "__main__":
    # verify_inputs.py <root> [--expect-briefing-mode MODE]
    _argv = sys.argv[1:]
    _expect = None
    if "--expect-briefing-mode" in _argv:
        _i = _argv.index("--expect-briefing-mode")
        _expect = _argv[_i + 1] if _i + 1 < len(_argv) else None
        del _argv[_i:_i + 2]
    main(_argv[0] if _argv else "runs", expect_mode=_expect)
