"""Reasoning left in the reply text is moved to the reasoning field (plan 42 v2.5.37).

Run:  python3 test_reasoning_recovery.py

A model that starts thinking without writing its opening tag gets the whole thought filed
by the server as reply text, closing tag and all (Seed-OSS in the 2026-10-04 smoke). The
harness must then treat that text as reasoning: counted as reasoning, replayed in SEEN,
discarded in UNSEEN and OFF -- never shown again as reply text.

No model, no network -- a scripted client against a temp workspace.
"""
import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from harness.agent import run_agent, build_messages, split_reasoning_from_text
from harness.llm import ToolCall, Turn
from harness.runlog import RunLog
from harness.tools import Tools

FAILURES = []


def check(name, cond, detail=""):
    print(f"[{'ok ' if cond else 'FAIL'}] {name}" + (f"  -- {detail}" if not cond else ""))
    if not cond:
        FAILURES.append(name)


# --- 1. the split itself ---------------------------------------------------------------
THOUGHT = "Now let's set up the backend.\n1. src/server.js\n2. src/db.js"
r, rec, mk = split_reasoning_from_text(THOUGHT + "</seed:think>\n\n\nLet's create the dirs:\n")
check("closer without opener: split at the closer", mk == "</seed:think>", str(mk))
check("closer without opener: thought recovered", rec == THOUGHT, repr(rec))
check("closer without opener: reply kept and trimmed", r == "Let's create the dirs:", repr(r))

r, rec, mk = split_reasoning_from_text("<think>plan A</think>plan B</think> Done.")
check("several closers: split at the LAST", rec == "plan Aplan B" and r == "Done.", repr((rec, r)))

r, rec, mk = split_reasoning_from_text("Sure. <seed:think>I was cut off while thin")
check("opener with no closer: split at the opener",
      mk == "<seed:think>" and rec == "I was cut off while thin" and r == "Sure.", repr((mk, rec, r)))

r, rec, mk = split_reasoning_from_text("</think>\n\nOnly a stray tag.")
check("stray closer only: tag removed, nothing recovered", rec == "" and r == "Only a stray tag.",
      repr((rec, r)))

r, rec, mk = split_reasoning_from_text("<|channel>thought\nplan the API<channel|>Here is the plan.")
check("Gemma channel, opened and closed: name dropped, split at the closer",
      mk == "<channel|>" and rec == "plan the API" and r == "Here is the plan.", repr((mk, rec, r)))

r, rec, mk = split_reasoning_from_text("<|channel>thought\nstill thinking when the cap hit")
check("Gemma thought channel opened and never closed: all of it is reasoning",
      mk == "<|channel>thought" and rec == "still thinking when the cap hit" and r == "",
      repr((mk, rec, r)))

call_txt = "<|channel>call:run_command{command:<|\"|>ls<|\"|>}<tool_call|>"
r, rec, mk = split_reasoning_from_text(call_txt)
check("bare <|channel> (a tool call with the wrong opener, 2026-10-06) is NOT split",
      (r, rec, mk) == (call_txt, None, None), repr((r, rec, mk)))

bare = "<|channel>1.1 Initialize\n1.1 Initialize"
check("bare <|channel> with no channel name is NOT split",
      split_reasoning_from_text(bare) == (bare, None, None), repr(split_reasoning_from_text(bare)))

r, rec, mk = split_reasoning_from_text("thinking about it<channel|>\nDone.")
check("Gemma closer with no opener", mk == "<channel|>" and rec == "thinking about it"
      and r == "Done.", repr((mk, rec, r)))

harmony = "<|channel|>analysis<|message|>gpt-oss syntax is not split here"
r, rec, mk = split_reasoning_from_text(harmony)
check("gpt-oss channel syntax is left alone (G4 catches it)", (r, rec, mk) == (harmony, None, None),
      repr((r, rec, mk)))

plain = "No tags here, just a reply with <b>html</b> and think about it."
r, rec, mk = split_reasoning_from_text(plain)
check("no tags: text untouched", (r, rec, mk) == (plain, None, None), repr((r, rec, mk)))
check("empty / None text untouched", split_reasoning_from_text(None) == (None, None, None)
      and split_reasoning_from_text("") == ("", None, None))


# --- 2. inside the agent loop ----------------------------------------------------------
class ScriptedClient:
    max_tokens = 32768

    def __init__(self, fn):
        self.fn, self.n, self.seen = fn, 0, []

    def chat(self, messages, schemas):
        self.n += 1
        self.seen.append(json.loads(json.dumps(messages)))
        return self.fn(self.n)


def call(name, args):
    return [ToolCall(id="c0", name=name, arguments=args)]


LEAK = "PRIVATE-PLAN: write a.txt first, then finish."
USAGE = {"prompt_tokens": 10, "completion_tokens": 5}


def leaky(n):
    if n == 1:
        return Turn(text=LEAK + "</seed:think>\n\nWriting it now.", raw={"content": "x"},
                    finish_reason="tool_calls", usage=USAGE,
                    tool_calls=call("write_file", {"path": "a.txt", "content": "hi"}))
    return Turn(text="", raw={}, finish_reason="tool_calls", usage=USAGE,
                tool_calls=call("finish", {"summary": "done"}))


def drive(replay):
    d = Path(tempfile.mkdtemp())
    tools = Tools(workspace=d / "ws")
    log = RunLog(d / "logs", {"condition": "execution"})
    client = ScriptedClient(leaky)
    try:
        status, extra = run_agent(client, tools, "execution",
                                  build_messages("task", str(d / "ws")), log,
                                  max_steps=10, replay_reasoning=replay)
    finally:
        tools.teardown()
        log.trace.close()
    rows = [json.loads(l) for l in (d / "logs" / "trace.jsonl").read_text().splitlines()]
    return status, extra, client, [x for x in rows if x.get("kind") == "response"]


for replay, arm in ((False, "UNSEEN/OFF"), (True, "SEEN")):
    status, extra, client, resp = drive(replay)
    nxt = client.seen[1]
    asst = [m for m in nxt if m.get("role") == "assistant"][-1]
    check(f"{arm}: run finishes", status == "finished", status)
    check(f"{arm}: the leaked thought is NOT in the reply text sent back",
          LEAK not in (asst.get("content") or "") and "</seed:think>" not in (asst.get("content") or ""),
          repr(asst.get("content")))
    check(f"{arm}: the reply after the tag IS sent back", asst.get("content") == "Writing it now.",
          repr(asst.get("content")))
    if replay:
        check("SEEN: the recovered thought is replayed as reasoning",
              asst.get("reasoning_content") == LEAK, repr(asst.get("reasoning_content")))
    else:
        check("UNSEEN/OFF: the recovered thought is discarded",
              "reasoning_content" not in asst and LEAK not in json.dumps(nxt))
    check(f"{arm}: counted as reasoning", extra.get("reasoning_turns") == 1
          and extra.get("reasoning_chars") == len(LEAK), str((extra.get("reasoning_turns"),
                                                               extra.get("reasoning_chars"))))
    check(f"{arm}: manifest records the recovery",
          extra.get("reasoning_recovered_turns") == 1
          and extra.get("reasoning_recovered_chars") == len(LEAK)
          and extra.get("reasoning_recovered_markers") == {"</seed:think>": 1},
          str({k: v for k, v in extra.items() if k.startswith("reasoning_recovered")}))
    check(f"{arm}: trace row records it; raw untouched; text is the reply as kept",
          resp[0].get("reasoning_recovered", {}).get("marker") == "</seed:think>"
          and resp[0].get("raw") == {"content": "x"} and resp[0].get("text") == "Writing it now."
          and "reasoning_recovered" not in resp[1], json.dumps(resp[0])[:300])

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {FAILURES}")
    sys.exit(1)
print("all reasoning-recovery checks passed")
