#!/usr/bin/env bash
# run_one_with_server.sh — start llama-server.exe (Windows) from WSL for one model,
# wait until it is truly up and serving the RIGHT file, run one eval-coding-agent
# run, stop the server, and archive the server log into that run's logs folder.
#
# Usage (classic layout — condition and run id are directory levels):
#   ./run_one_with_server.sh <model-key> <task> <condition> <run-id>
#   ./run_one_with_server.sh qwen-q8 kanban-board execution 3214
#   REPLAY_REASONING=0 ./run_one_with_server.sh qwen-q8 message-board interactive 3215
#
# Blind layout (BLIND=1): the output path contains NEITHER the condition NOR a
# meaningful run id — the run lands in <OUTPUT_ROOT>/<task>/runs/<random 6-digit id>.
# Ids are drawn at random and never reused: every id ever drawn is appended to an
# append-only ledger (blind-state/blind-ids.txt) the moment it is chosen, and draws
# are rejected against the ledger, the key file, and whatever is on disk — so runs
# moved elsewhere and deleted from OUTPUT_ROOT still keep their ids reserved. The
# condition (and arm, quant, model) are still recorded in manifest.json; a key line
# per run is appended to blind-state/blind-key.jsonl (the un-blinding index).
#   BLIND=1 ./run_one_with_server.sh qwen-q8 message-board execution
#   BLIND=1 REPLAY_REASONING=0 ./run_one_with_server.sh qwen-q8 message-board execution seen-r07
#   (the optional 4th arg is a free-text label written only to the key file, never to a path)
#
# Loop example (arms via env):
#   for id in 3301 3302 3303; do REPLAY_REASONING=0 ./run_one_with_server.sh qwen-q8 message-board execution "$id" || exit 1; done
#
# Arms (recommended): ARM=off|unseen|seen derives REPLAY_REASONING, EXTRA_BODY and
# THINK_PREAMBLE from each model's documented thinking mechanism, so the JSON bodies and
# the preamble key can't be mistyped:
#   ARM=seen   ./run_one_with_server.sh qwen-q4 message-board execution 301
#   ARM=unseen ./run_one_with_server.sh qwen-q4 message-board execution 201
#   ARM=off    ./run_one_with_server.sh qwen-q4 message-board execution 101
# ARM refuses to run if any of those three are also set (no silent mixing), and ARM=off
# refuses a model with no off-switch (gpt-oss, and Muse Glimmer since plan v2.5.19). The two THINKING arms are
# always byte-identical in body AND system prompt and differ only in replay, so the
# primary unseen->seen contrast never varies anything but what the model can see.
#
# Overridable via environment: ARM, PORT (7777), SERVER_HOST, BASE_URL, LOCAL_BASE_URL,
# OUTPUT_ROOT, SERVER_TIMEOUT_S, BLIND, BLIND_STATE_DIR, BLIND_IDS_FILE, BLIND_KEY_FILE,
# REPLAY_REASONING, EXTRA_BODY, THINK_PREAMBLE, MAGISTRAL_PREAMBLE (which registered
# preamble Magistral's thinking arms use: 'mistral-min', the trimmed variant and the
# default, or 'mistral' for the vendor text verbatim), QUANT_REGISTRY,
# MAX_SAME_CALLS, MAX_CYCLE_REPEATS, MAX_BLOCKED_CALLS, MAX_REPEAT_STEPS,
# MAX_TOTAL_TOKENS, SERVER_VERBOSITY (llama-server -lv; FROZEN at 5 since plan v2.5.27, so
# unset or 5 is a study run; any other level is a DIAGNOSTIC run that fails gate G17).

set -u

# ----------------------------------------------------------------------------
# Fixed locations (edit if your layout changes)
# ----------------------------------------------------------------------------
# Pinned engine build. Override SERVER_EXE only when deliberately re-pinning the study
# (and re-run the marker probe + thinking canaries on the new build before any real run).
SERVER_EXE_WSL="${SERVER_EXE:-/mnt/d/tools/llama-b10964-bin-win-cuda-13.3-x64/llama-server.exe}"
# plan v2.5.31: the harness is the one beside this wrapper, so a checkout of the frozen tag
# runs ITS OWN harness/ and run.sh (it was hard-coded to /mnt/d/eval-coding-agent, so every
# copy ran that folder's code). Override with AGENT_DIR only deliberately.
AGENT_DIR="${AGENT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)}"
MODELS_ROOT_WSL="${MODELS_ROOT:-/mnt/d/llm_models/LM Studio/unsloth}"

PORT="${PORT:-7777}"
# From WSL, a Windows-side server is reached via the machine's LAN IP (this is the
# address your existing runs recorded in serving_probe). If DHCP moves it, override
# SERVER_HOST — the WSL->Windows gateway 172.18.192.1 is the stable alternative.
SERVER_HOST="${SERVER_HOST:-192.168.1.110}"
BASE_URL="${BASE_URL:-http://${SERVER_HOST}:${PORT}}"          # health/props live at root
# run.sh reaches the model through its LOCAL_BASE_URL (OpenAI-compatible, so /v1). Its
# built-in default points at LM Studio (:1234); we repoint it at llama-server.
LOCAL_BASE_URL="${LOCAL_BASE_URL:-http://${SERVER_HOST}:${PORT}/v1}"
OUTPUT_ROOT="${OUTPUT_ROOT:-/tmp/runs/final-runs}"
SERVER_TIMEOUT_S="${SERVER_TIMEOUT_S:-600}"   # big GGUFs load slowly on first (cold) load
QUANT_REGISTRY="${QUANT_REGISTRY:-$AGENT_DIR/quant-registry.json}"
BLIND="${BLIND:-0}"
ARM="${ARM:-}"
# Blind-run state lives OUTSIDE the runs tree (a grader handed OUTPUT_ROOT never sees
# it) and OUTSIDE /tmp (WSL may wipe /tmp on restart; runs get moved off and deleted
# for disk space). Default: a blind-state/ folder beside this script.
#   blind-ids.txt   — append-only ledger of every id ever drawn; a drawn id is written
#                     here BEFORE the run starts and is never drawn again, even after
#                     the run's directory has been moved away or deleted.
#   blind-key.jsonl — one line per blind run: the un-blinding index.
# After archiving runs elsewhere, COPY (don't move) both files alongside the archive;
# the originals here are what the next run reads.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---- decoding ---------------------------------------------------------------------------
# Sampling lives in a CONFIG FILE, not in this script and not in the harness (plan §4.4.1).
# The harness knows nothing about models: it accepts sampler values and records what it was
# given. This wrapper is the only thing that maps (model, arm) -> a profile, and it does so
# by reading the registry rather than by carrying a second copy of the numbers.
DECODING_REGISTRY="${DECODING_REGISTRY:-$SCRIPT_DIR/decoding-registry.json}"

# Print the agent flags for one alias+mode, or die naming what is missing. Every value is
# passed explicitly, including the ones set to 0: llama.cpp applies its OWN defaults
# (top_k 40, min_p 0.05) to anything a request omits, so "the vendor did not specify it"
# has to be sent as an explicit disable or the engine quietly chooses instead.
decoding_flags() {
  local alias="$1" mode="$2" out
  # plan v2.5.19: `2>&1` belongs on THIS line. It used to sit on a line of its own after the
  # heredoc, where bash parses it as a separate, always-successful command, so this function
  # never died: a missing profile printed its error and returned EMPTY flags -- llama.cpp's
  # defaults -- and only G15 caught it, after the run.
  out="$(REG="$DECODING_REGISTRY" ALIAS="$alias" MODE="$mode" python3 - 2>&1 <<'PY'
import json, os, sys
reg, alias, mode = os.environ["REG"], os.environ["ALIAS"], os.environ["MODE"]
try:
    d = json.load(open(reg, encoding="utf-8"))
except Exception as e:
    sys.exit(f"cannot read decoding registry {reg}: {e}")
if alias not in d:
    sys.exit(f"no decoding profile registered for model {alias!r} in {reg}. "
             f"Known: {', '.join(k for k in d if not k.startswith('_'))}")
entry = d[alias]
if mode not in entry:
    sys.exit(f"model {alias!r} has no {mode!r} profile in {reg}. This is deliberate for a "
             f"model with no such documented mode (gpt-oss has no non-thinking mode and "
             f"runs two arms); it is an error rather than a silent fallback.")
prof = entry[mode]
flag = {"temperature": "--temperature", "top_p": "--top-p", "top_k": "--top-k",
        "min_p": "--min-p", "presence_penalty": "--presence-penalty"}
missing = [k for k in flag if k not in prof]
if missing:
    sys.exit(f"{alias}/{mode} is missing {missing} — every sampler is pinned explicitly, "
             f"because an omitted one becomes llama.cpp's default rather than the vendor's")
print(" ".join(f"{flag[k]} {prof[k]}" for k in flag))
PY
)" || die "decoding: $out"
  printf '%s' "$out"
}
BLIND_STATE_DIR="${BLIND_STATE_DIR:-$SCRIPT_DIR/blind-state}"
BLIND_IDS_FILE="${BLIND_IDS_FILE:-$BLIND_STATE_DIR/blind-ids.txt}"
BLIND_KEY_FILE="${BLIND_KEY_FILE:-$BLIND_STATE_DIR/blind-key.jsonl}"

# Stuck-loop guards. run.sh's OWN defaults are the SMOKE config (3/3/3/6), which is NOT
# a study run and aborts almost immediately. The pilots (and the study) use these; the
# loop MEASURE is defined by them, so they are set here and forwarded. Override per run.
MAX_SAME_CALLS="${MAX_SAME_CALLS:-500}"
MAX_CYCLE_REPEATS="${MAX_CYCLE_REPEATS:-3}"
MAX_BLOCKED_CALLS="${MAX_BLOCKED_CALLS:-3}"
MAX_REPEAT_STEPS="${MAX_REPEAT_STEPS:-30}"
# Per-run token budget (plan §4.4). run.sh's own default is 6,000,000, which the study
# RAISED TO 12,000,000 on 2026-09-23, from 8M. Under vendor sampling (§4.4.1) Granite runs
# far longer than it did greedy: three of its nine smoke runs hit the 8M ceiling, peaking at
# 8,051,137, and its UNSEEN arm went from 3/3 finished at 224 steps to 2/3 budget-exhausted
# at 337. The raise is safe for everything else and measurably so rather than by assumption:
# across the 51-run set of 2026-09-23 the heaviest NON-Granite run used 2,719,615 tokens --
# 34% of the old cap, 23% of the new one -- and the median run used 148,789. No other model
# came within 2.5x of the ceiling, so the cap was causally inert for them at 8M and remains
# so at 12M.
# (historical) # raised to 8,000,000 after the smokes: the heaviest single run came in at 3.15M, and 6M
# left under 2x headroom on the arm whose whole point is carrying more context. Set here
# so the wrapper -- not run.sh's default -- is what every study run records as
# max_total_tokens, and so a drift between this plan and the tooling shows up in the
# manifest rather than in a run that dies at 6M.
# plan v2.5.12 -- RAISED TO 20,000,000 on 2026-09-26, at the study lead's decision on gate G9,
# after a GLM-4.7-Flash SEEN smoke run under the reinstated briefing exhausted 12M (12,008,378
# tokens). That run was cycling -- starting its server, probing the port, starting it again --
# so the raise may only let such a cycle run longer, and the plan records it so (§4.4). For
# every other model the cap stays causally inert, and measurably: the heaviest of their runs in
# the two latest smoke sets used 4,780,566 tokens, 24% of the new cap.
MAX_TOTAL_TOKENS="${MAX_TOTAL_TOKENS:-20000000}"

# Frozen serving flags — identical for every study run (context size is per model).
# plan v2.5.26: --swa-full for EVERY model (v2.5.24 had it for gpt-oss only). It keeps a
# sliding-window model's whole attention cache, so a partly reused prompt cache is reused
# exactly; for a model without sliding-window layers (Qwen3.6, Seed-OSS, GLM) it changes
# nothing. Drop it only with the diagnostic NO_SWA_FULL=1 below, which fails gate G17.
# plan v2.5.27: -lv 5 is FROZEN for every run (last, so the banner reads as the 2026-10-01
# smoke's did). See the verbosity block below.
FROZEN_FLAGS=(-np 1 -ngl 999 -fa on -b 2048 --cache-type-k f16 --cache-type-v f16 --jinja --swa-full --seed 0 --host 0.0.0.0 --port "$PORT" -lv 5)

# SERVER VERBOSITY -- FROZEN at 5 since plan v2.5.27 (it was a diagnostic-only setting, with
# the server's default of 3 frozen, until then). llama-server's -lv takes 0 generic / 1 error /
# 2 warning / 3 info / 4 and 5 for trace and debug. At 5 the log carries, for every request,
# the prompt the server rendered from the chat template and the model's raw output before
# parsing -- so every run records for itself that its arm reached the template, and every
# output the parser rejected is kept whole.
#
# The cost is volume: the rendered prompt is the WHOLE conversation so far, re-logged on every
# step. The 66-run smoke of 2026-10-01 wrote 1.7 GB of server logs (median 18.5 MB a run, the
# largest 127 MB), which puts the 2,640-run grid near 70 GB uncompressed; zstd -19 shrinks a
# log about 18 times. The batch pauses below 20 GB free (MIN_FREE_GB), so move finished runs
# off between batches as before.
#
# SERVER_VERBOSITY=<other digit> runs at another level for a DIAGNOSTIC run only: it replaces
# the frozen -lv 5, the banner says so, and gate G17 fails the run.
SERVER_VERBOSITY="${SERVER_VERBOSITY:-5}"
SERVER_EXTRA_FLAGS=()
case "$SERVER_VERBOSITY" in
  5) ;;
  [0-9]) FROZEN_FLAGS[${#FROZEN_FLAGS[@]}-1]="$SERVER_VERBOSITY" ;;   # the value after -lv
  *) echo "FATAL: SERVER_VERBOSITY must be a single digit 0-9 (llama-server -lv), got '$SERVER_VERBOSITY'" >&2; exit 2 ;;
esac
VERBOSITY_DIAG=""; [ "$SERVER_VERBOSITY" = 5 ] || VERBOSITY_DIAG=1

# ----------------------------------------------------------------------------
# Model map: key -> gguf (relative to MODELS_ROOT_WSL), alias, quant label, ctx
# ----------------------------------------------------------------------------
# THINK_KIND is the model's documented thinking mechanism, used by ARM=…:
#   enable_thinking  chat_template_kwargs.enable_thinking true/false      (Gemma, Qwen)
#   thinking_budget  chat_template_kwargs.thinking_budget, 0 = off        (Seed-OSS)
#   always           always-thinking; no off-switch -> ARM=off refused    (gpt-oss, Muse)
#   system_preamble  thinking is driven by the SYSTEM PROMPT, not the template. Our own
#                    system prompt displaces the vendor's reasoning instructions, so the
#                    model does not think at all unless a registered preamble is appended
#                    (harness THINK_PREAMBLES). ON = preamble appended; OFF = omitted,
#                    which is a measured off-switch: 36/36 Magistral smoke responses with
#                    no preamble carried empty reasoning_content.               (Magistral)
# THINK_ON_BODY (optional) is a model-specific ON body, e.g. gpt-oss's reasoning effort.
# Every path below is VERIFIED against the disk and every file is fingerprinted in
# quant-registry.json; all five resolved with quantization_detail.status=ok in the
# 2026-09-20 smokes. If a file ever moves, find it again with
#   find "/mnt/d/llm_models/LM Studio" -name "*.gguf"
# and fix the line here rather than guessing (LM Studio's layout is not consistent: some
# unsloth folders keep the "-GGUF" suffix, some don't). NOTE: gemma and qwen exist under BOTH
# lmstudio-community/ and unsloth/ with different bytes; the study uses the unsloth copies
# (the ones in quant-registry.json), which is what these paths point at.
resolve_model() {
  THINK_ON_BODY=""
  # Per-model serving flags, added after FROZEN_FLAGS and recorded in the log banner's args
  # line (verify_smokes.py G17 checks them). Empty for every model since plan v2.5.26, which
  # moved gpt-oss's --swa-full into FROZEN_FLAGS for all; kept for any flag one model needs.
  MODEL_SERVER_FLAGS=()
  THINK_PREAMBLE_KEY=""
  # How this model wants a replayed thought carried back (harness REPLAY_FORMATS).
  # "field" suits every template with a reasoning slot; Magistral has none, and sending one
  # makes llama.cpp delete the assistant's prose, so it takes the reasoning inline in the
  # reply as [THINK]…[/THINK] — the bytes it emits in the first place.
  REPLAY_FORMAT_KEY="field"
  case "$1" in
    # plan v2.5.32 -- every model at its native window where the card's memory allows it.
    # Gemma-4-31B CANNOT be: with --swa-full every layer keeps a full cache (~880 KB a token
    # at f16), so its native 262,144 would need ~236 GB, and the 96 GB card holds about
    # 89,000 tokens. It stays at 65,536 (~59 GB of cache); its smokes never passed ~20,000.
    gemma-q4)      GGUF_REL="gemma-4-31B-it-GGUF/gemma-4-31B-it-Q4_K_M.gguf";            ALIAS="gemma-4-31b";     QUANT="Q4_K_M";     CTX=65536;  THINK_KIND=enable_thinking ;;
    gemma-q5)      GGUF_REL="gemma-4-31B-it-GGUF/gemma-4-31B-it-Q5_K_M.gguf";            ALIAS="gemma-4-31b";     QUANT="Q5_K_M";     CTX=65536;  THINK_KIND=enable_thinking ;;
    gemma-q8)      GGUF_REL="gemma-4-31B-it-GGUF/gemma-4-31B-it-Q8_0.gguf";              ALIAS="gemma-4-31b";     QUANT="Q8_0";       CTX=65536;  THINK_KIND=enable_thinking ;;
    # plan v2.5.32: native 262,144 (16 attention layers of 64; ~17 GB of cache).
    qwen-q4)       GGUF_REL="Qwen3.6-27B-GGUF/Qwen3.6-27B-Q4_K_M.gguf";                  ALIAS="qwen3.6-27b";     QUANT="Q4_K_M";     CTX=262144; THINK_KIND=enable_thinking ;;
    qwen-q5)       GGUF_REL="Qwen3.6-27B-GGUF/Qwen3.6-27B-Q5_K_M.gguf";                  ALIAS="qwen3.6-27b";     QUANT="Q5_K_M";     CTX=131072; THINK_KIND=enable_thinking ;;
    qwen-q8)       GGUF_REL="Qwen3.6-27B-GGUF/Qwen3.6-27B-Q8_0.gguf";                    ALIAS="qwen3.6-27b";     QUANT="Q8_0";       CTX=131072; THINK_KIND=enable_thinking ;;
    # plan v2.5.32: 262,144 -- the most that fits, NOT its native 524,288, which would need
    # ~137 GB of cache (64 full-attention layers, 256 KB a token). 262,144 is ~69 GB of cache
    # beside 21.8 GB of weights; llama-server allocates the cache at boot, so a card that
    # cannot hold it fails at startup, never mid-run.
    seed-q4)       GGUF_REL="Seed-OSS-36B/Seed-OSS-36B-Instruct-Q4_K_M.gguf";            ALIAS="seed-oss-36b";    QUANT="Q4_K_M";     CTX=262144; THINK_KIND=thinking_budget ;;
    seed-q8)       GGUF_REL="Seed-OSS-36B/Seed-OSS-36B-Instruct-Q8_0.gguf";              ALIAS="seed-oss-36b";    QUANT="Q8_0";       CTX=131072; THINK_KIND=thinking_budget ;;
    # EXAONE-4.0-32B (LG AI Research) — the roster's named substitute (plan §5), added
    # UNVERIFIED, and on present evidence probably NOT a drop-in. Its card documents the
    # same switch Gemma and Qwen use, chat_template_kwargs.enable_thinking true/false, and
    # llama.cpp has supported the architecture since b5932 (we pin b10964, well past it).
    # That covers OFF->UNSEEN. UNSEEN->SEEN is the problem. LG's published
    # chat_template.jinja gates replayed reasoning on TWO conditions:
    #     {%- if not skip_think is defined %}{%- set skip_think = true %}
    #     {%- if (not skip_think and loop.last) and reasoning_content is defined %}
    # It does read msg.reasoning_content, so the `field` replay route is right. But
    # skip_think DEFAULTS TO TRUE, and the name this template knows is skip_think — NOT
    # the preserve_thinking that EXAONE inherits here by sharing THINK_KIND with Gemma and
    # Qwen, which it never reads. And even with skip_think:false, `loop.last` means only
    # the FINAL message may render reasoning; in an agentic history that is a tool result,
    # never an assistant turn. The else-branch writes an empty <think></think> in its
    # place. If that is what the shipped GGUF contains, SEEN renders nothing and no
    # chat_template_kwargs value fixes it — only --chat-template-file would, which is a
    # registered deviation, not a config tweak (plan §5).
    # The above is read from the repo's published template, NOT from a GGUF on this
    # machine, so it is a strong prior and not a measurement. Confirm it before trusting
    # either way; the sequence every other model went through still applies:
    #   1. hash it into quant-registry.json (tools/hash_quants.py)
    #   2. extract its template      (gguf_chat_template.py --out templates)
    #   3. read what the template does with each arm, WITH a nudge in the history
    #   4. prove it on the live server (template_probe.sh exaone-q4) — for EXAONE this is
    #      the step that decides whether the standby is usable at all, not a formality
    #   5. smoke it, then register its expected body/format/preamble in verify_smokes.py
    # Until step 5, G11/G12/G13 fail it with "no expected ... registered for this model",
    # which is the intended forcing function rather than an oversight.
    # NOTE the path: there is NO unsloth build of EXAONE — the file comes from LG's own
    # LGAI-EXAONE/EXAONE-4.0-32B-GGUF (licence-gated on the Hub) or an ungated mirror
    # (bartowski, lmstudio-community, mradermacher). MODELS_ROOT_WSL points at unsloth/,
    # so either drop EXAONE-4.0-32B-GGUF/ under that folder or override MODELS_ROOT.
    exaone-q4)     GGUF_REL="EXAONE-4.0-32B-GGUF/EXAONE-4.0-32B-Q4_K_M.gguf";        ALIAS="exaone-4.0-32b";  QUANT="Q4_K_M";     CTX=131072; THINK_KIND=enable_thinking ;;
    exaone-q8)     GGUF_REL="EXAONE-4.0-32B-GGUF/EXAONE-4.0-32B-Q8_0.gguf";          ALIAS="exaone-4.0-32b";  QUANT="Q8_0";       CTX=131072; THINK_KIND=enable_thinking ;;
    # RETIRED in plan v2.4.4: its SEEN arm finished 0 of 3 under two decoders, every run spending
    # its 32,768-token reply allowance in a repetition loop. Kept in this map -- and registered
    # in verify_smokes.py -- so its probes, smokes and diagnostics can be re-made by name. Not
    # in the batch driver since v2.5.5. What follows is its history as written at the time.
    # Granite 4.2-30B (IBM) — the roster's standby as of v2.3.13, and the better bet than
    # EXAONE: dense 30B, 128K context, Apache 2.0, ungated, and the only candidate whose
    # card documents an opt-out from history-thinking truncation (see think_body above).
    # Engine support is not a question mark: bartowski quantised it at llama.cpp b10603
    # and this study pins b10964, so the architecture predates the pin rather than chasing
    # it. Still UNVERIFIED in the sense that matters — nobody has read the template out of
    # the GGUF that will actually be served, and EXAONE is the reason that distinction is
    # written down. Same five steps before it goes anywhere near a grid:
    #   1. hash it into quant-registry.json (tools/hash_quants.py)
    #   2. extract its template      (gguf_chat_template.py --out templates)
    #   3. read what the template does with each arm, WITH a nudge in the history, and
    #      confirm truncate_history_thinking is the name it reads and FALSE is the value
    #      that keeps history
    #   4. prove it on the live server (template_probe.sh granite-q4)
    #   5. smoke it, then register its expected body/format/preamble in verify_smokes.py
    # Until step 5, G11/G12/G13 fail it by design.
    # PATH: there is no unsloth build of 4.2 (unsloth stops at granite-4.1-30b). The file
    # on this machine is IBM's own, 17,721,455,328 bytes, and it lives beside the roster
    # rather than under it -- LM Studio/ibm-granite/ -- so the key carries an ABSOLUTE
    # path. The Q8_0 line below is a placeholder: that file is NOT on this machine.
    granite-q4)    GGUF_REL="/mnt/d/llm_models/LM Studio/ibm-granite/granite-4.2-30b-Q4_K_M.gguf"; ALIAS="granite-4.2-30b"; QUANT="Q4_K_M"; CTX=131072; THINK_KIND=enable_thinking_granite ;;
    granite-q8)    GGUF_REL="/mnt/d/llm_models/LM Studio/ibm-granite/granite-4.2-30b-Q8_0.gguf";   ALIAS="granite-4.2-30b"; QUANT="Q8_0";   CTX=131072; THINK_KIND=enable_thinking_granite ;;
    # Nemotron-3-Nano-30B-A3B (NVIDIA) -- proposed on 2026-09-25 to replace Granite, whose
    # SEEN arm went 0/3 on a within-reply repetition loop and which took 49% of the smoke
    # set's model-generation time on its own (2.25x the next model).
    # A hybrid Mamba-2 / Transformer MIXTURE-OF-EXPERTS model: 30B total, ~3.5B active per
    # token -- per its GGUF header 6 of 128 routed experts per token plus 1 shared (the
    # card summary said 5; the header is what llama.cpp runs) -- with 23 Mamba-2/MoE
    # layers and only 6 attention layers. It is the roster's second sparse model: gpt-oss-20b (20.9B total,
    # ~3.6B active) was the first, and is the best performer in the smoke set. The roster
    # is deliberately mixed dense/MoE -- every contrast is climbed inside one model, so
    # architecture is described, never selected on.
    # ENGINE: the architecture string `nemotron_h_moe` is present in the pinned b10964
    # llama.dll, so it loads without an engine bump. That does NOT prove its reasoning comes
    # back in reasoning_content rather than as inline <think> tags -- the only Nemotron-named
    # chat parser in llama-common.dll is "Nemotron Nano v2" -- so that is the first thing
    # the live probe has to show.
    # COMPETENCE is the open risk, not sparsity: study 08's gate failed a ~3B-active MoE
    # (qwen3-coder-next) on these same tasks -- 92 steps of thrashing, no working app.
    # RETIRED in plan v2.5.1 (2026-09-25): out of the batch driver and the standby slot. It
    # stays in this map, unregistered, so the probe, smoke and nemotron_off_diag.sh runs the
    # plan cites can be re-made by name -- as EXAONE's and Granite's entries are kept.
    # STATUS at retirement -- steps 1-4 passed; step 5 smoked but NOT registered (plan §5):
    #   1. hashed: sha256 0e7f6e51fdd90399..., 24,574,373,664 bytes, publisher Unsloth,
    #      imatrix, architecture nemotron_h_moe, header rung Q4_K_M (matches QUANT below)
    #   2. template extracted: sha256 b3043677cd5fc67f, 10,653 chars -- unsloth's patched
    #      version of NVIDIA's, which is the one served. It declares enable_thinking and
    #      truncate_history_thinking, BOTH defaulting to true, reads reasoning_content as a
    #      field, and gates history in BOTH assistant branches on
    #      `not (truncate_history_thinking and loop.index0 < ns.last_user_idx)` -- Granite's
    #      gate verbatim, so FALSE defeats it unconditionally. No loop.last trap.
    #   3. desk-rendered with a nudge: UNSEEN->SEEN +150 chars (Granite's offline delta
    #      exactly), prose survives in every arm, OFF differs from UNSEEN only in the
    #      pre-closed <think></think>; nudged SEEN keeps both turns with FALSE and loses both
    #      at the default TRUE. Past tool-call arguments render only as a MAPPING -- as a JSON
    #      string they vanish silently -- but that is true of Qwen's and Seed's templates too,
    #      and harmless because llama.cpp parses them first; template_probe.py now checks it.
    #   4. live probe PASSED: UNSEEN->SEEN +150 chars on the server, the desk delta exactly
    #   5. smoked (9 runs, plus 12 OFF-only diagnostics). The thinking arms parse cleanly. With
    #      thinking OFF it abandons tool calls for a JSON agent protocol of its own in 11 of
    #      15 runs -- Terminus-style envelopes; NVIDIA's report says its terminal training
    #      data came from the Terminus-1 and Terminus-2 agents -- and none of its finished
    #      runs ever ran what it had built. NOT registered; plan §5 has the record.
    # G11/G12/G13 fail it by design until someone registers it deliberately.
    # PATH: unsloth's own build, under the models root like the rest of the roster --
    # but LM Studio saved this one WITHOUT the -GGUF folder suffix (on disk 2026-09-25,
    # 24,574,373,664 bytes), which is exactly the inconsistency the note above warns of.
    nemotron-q4)   GGUF_REL="Nemotron-3-Nano-30B-A3B/Nemotron-3-Nano-30B-A3B-Q4_K_M.gguf"; ALIAS="nemotron-3-nano-30b-a3b"; QUANT="Q4_K_M"; CTX=131072; THINK_KIND=enable_thinking_nemotron ;;
    # GLM-4.7-Flash (Zhipu / Z.ai) -- the roster's sixth model as of plan v2.5.0 (2026-09-25).
    # Wired that morning as the second-line standby behind Nemotron; it passed all five steps
    # below and went into the grid rather than onto the bench.
    # MIXTURE-OF-EXPERTS, 31B total / ~3B active -- per its GGUF header 4 of 64 routed experts
    # per token plus 1 shared, 47 layers of which the first is dense, MLA attention -- MIT
    # licence, built for local agentic coding. Architecture `deepseek2`, which the pinned
    # b10964 llama.dll carries, so no engine bump.
    # ONLY A POST-21-JANUARY-2026 FILE WILL DO. The launch GGUFs looped and produced garbage
    # from a llama.cpp expert-scoring bug (softmax where it should be sigmoid); llama.cpp fixed
    # it and unsloth re-uploaded every quant on 2026-01-21. The file here is the re-upload: its
    # sha256 is the one Hugging Face publishes, and its header records sigmoid gating
    # (deepseek2.expert_gating_func = 2).
    # STATUS 2026-09-25 -- all five steps done:
    #   1. hashed: sha256 29837ed2c0fc5f51..., 18,312,339,808 bytes, publisher Unsloth,
    #      imatrix, header rung Q4_K_M (matches QUANT below)
    #   2. template extracted: sha256 d63ad536c3c81880, 3,120 chars -- the chat_template_sha
    #      every GLM smoke recorded from /props. It reads clear_thinking, FALSE keeps history
    #   3. desk-rendered with a nudge: UNSEEN->SEEN +158 chars, prose intact
    #   4. live probe PASSED (template_probe.sh glm-q4): +158 chars on the server as well
    #   5. smoked (9 runs, all gates but G11-G13) and registered in verify_smokes.py's
    #      EXPECTED_* tables, so G11-G13 now test it instead of failing it by design
    # plan v2.5.29: CTX raised from 131,072 to its native 202,752 (deepseek2.context_length in
    # the GGUF header). The 2026-10-01 smoke's kanban/execution SEEN run outgrew 131,072
    # (a 132,135-token request, refused with HTTP 400), and the rule for every model's window
    # is the smallest with no overflow in its smoke runs. MLA keeps the cache small: about
    # 11-21 GB at 202,752 tokens, beside 18.3 GB of weights.
    glm-q4)        GGUF_REL="GLM-4.7-Flash-GGUF/GLM-4.7-Flash-Q4_K_M.gguf"; ALIAS="glm-4.7-flash"; QUANT="Q4_K_M"; CTX=202752; THINK_KIND=enable_thinking_glm ;;
    # MIXTURE-OF-EXPERTS TWINS of two roster models -- proposed in plan v2.5.2; probed, smoked and
    # registered in verify_smokes.py's EXPECTED_* tables in plan v2.5.4; in the GRID since v2.5.5.
    # Qwen3.6-35B-A3B (Alibaba) and Gemma-4-26B-A4B-it (Google) are the MoE siblings of qwen-q4
    # and gemma-q4: same vendor, same chat-template family, same switch names. A pair is only
    # worth having if architecture is the main thing that differs inside it, so each twin
    # takes its sibling's settings BY CONSTRUCTION rather than by copy:
    #   - the same THINK_KIND (enable_thinking), so think_body() sends both members of a pair
    #     the same bytes, {"enable_thinking": ..., "preserve_thinking": true};
    #   - the sibling's context window, 131,072 for Qwen -- but NOT for Gemma since plan v2.5.4:
    #     its smoke overflowed the 31B's 65,536 and §4.3's window rule raised it (below);
    #   - decoding-registry.json entries with the sibling's values, which the vendors' cards
    #     give for the twins too (so the Qwen twin inherits the 27B's mode split).
    # If a twin's probe ever disagrees with its sibling's, it gets a THINK_KIND of its own then,
    # and the plan has to record that the pair's bodies are no longer identical.
    # What still differs inside a pair besides the routing: active parameters (3B and 3.8B
    # against 27B and 31B dense), and the quantization recipe -- unsloth publishes these MoE
    # builds only as Dynamic quants, so the twins run UD-Q4_K_M against their siblings' plain
    # Q4_K_M. The header will say Q4_K_M; the registry key is UD-Q4_K_M on purpose, as
    # Magistral's is UD-Q4_K_XL (plan §5) -- hash with tools/hash_quants.py --key UD-Q4_K_M.
    #   Qwen3.6-35B-A3B: 35B total / 3B active (8 of 256 routed experts + 1 shared), Apache
    #     2.0, architecture qwen35moe (in the pinned b10964 llama.dll). Its published
    #     template's history gate is the 27B's: (preserve_thinking is defined and
    #     preserve_thinking is true) or (loop.index0 > ns.last_query_index).
    #   Gemma-4-26B-A4B-it: 25.2B total / 3.8B active (8 of 128 routed + 1 shared), Apache
    #     2.0, architecture gemma4. Google's template of 2026-07-09, the 31B's: thinking_gate =
    #     (loop.index0 > last_user_idx) or (preserve_thinking and tool_calls). unsloth's
    #     UD-Q4_K_M was last re-uploaded with "Added Gemma official chat template update"
    #     (September 2026); step 2 must confirm the served file reads preserve_thinking.
    # The five steps, as for every model:
    #   1. hash:   python3 tools/hash_quants.py --model <alias> --key UD-Q4_K_M <gguf>
    #   2. extract the template (gguf_chat_template.py --out templates) and read it
    #   3. desk-render (render_arms.py -- the gemma and Qwen rows match the twins by prefix)
    #   4. prove it on the live server (template_probe.sh qwen-moe-q4 gemma-moe-q4)
    #   5. smoke it, then register its expected body/format/preamble in verify_smokes.py
    # PATH: LM Studio saved both files (2026-09-25) under folders named for the rung, "-UD",
    # not for the repo, "-GGUF" -- the same kind of surprise as Nemotron's folder, so the
    # keys below say where the files actually are rather than where the repos would put them.
    # plan v2.5.32: native 262,144 (10 attention layers of 40; ~5 GB of cache).
    qwen-moe-q4)   GGUF_REL="Qwen3.6-35B-A3B-UD/Qwen3.6-35B-A3B-UD-Q4_K_M.gguf"; ALIAS="qwen3.6-35b-a3b"; QUANT="UD-Q4_K_M"; CTX=262144; THINK_KIND=enable_thinking ;;
    # CONTEXT (plan v2.5.4, §4.3): the Gemma twin is served 131072, NOT its sibling's 65536.
    # Its first smoke (2026-09-25) overflowed 65536 once -- a repetition loop filled the window
    # at step 79 of kanban-board/interactive UNSEEN, prompt 46793 + reply 18743 -- and §4.3
    # sets every model's window as the smallest that produces zero overflow deaths in its own
    # smokes; its prompts reached 60087 tokens where the 31B's never passed 19047. The window
    # changes no byte either model is sent, so the pair's bodies stay identical by construction.
    # plan v2.5.32: native 262,144 (~59 GB of cache with --swa-full, ~76 GB with weights).
    # Its OFF kanban/execution smoke run of 2026-10-03 outgrew 131,072 at step 196.
    gemma-moe-q4)  GGUF_REL="gemma-4-26B-A4B-it-UD/gemma-4-26B-A4B-it-UD-Q4_K_M.gguf"; ALIAS="gemma-4-26b-a4b"; QUANT="UD-Q4_K_M"; CTX=262144; THINK_KIND=enable_thinking ;;
    # Magistral: RETIRED in plan v2.5.9 (plan §5.1) and out of the batch driver; this entry stays
    # so its probes, smokes and preamble runs can be re-made by name.
    magistral-q4xl) GGUF_REL="Magistral-Small-2509-GGUF/Magistral-Small-2509-UD-Q4_K_XL.gguf"; ALIAS="magistral-small-2509"; QUANT="UD-Q4_K_XL"; CTX=65536; THINK_KIND=system_preamble
                   # 'mistral-min', chosen on 10 runs per variant rather than the 1 that
                   # first picked the vendor text and picked it wrong. The trimmed preamble
                   # beat it on every measure: reasoning on 94/94 steps against 85/93, ten
                   # of ten runs reasoning on every step against eight of ten, median 477
                   # chars against 381, zero of ten writing prose at step 1 against four of
                   # ten, ten of ten finishing against nine. The probe that chose the vendor
                   # text had caught 'mistral-min' on a run where it reasoned once and
                   # stopped; over ten runs it never does, and it is the VENDOR text that
                   # intermittently stops, twice at ~25%. A registered deviation from the
                   # model card, with the measurement that justifies it.
                   THINK_PREAMBLE_KEY="${MAGISTRAL_PREAMBLE:-mistral-min}"
                   REPLAY_FORMAT_KEY="inline-think" ;;
    # gpt-oss-20b: removed from the grid in plan v2.5.6 by mistake and restored in plan v2.5.7.
    # gpt-oss ships MXFP4-native inside an F16-typed GGUF; the label follows the file header
    # so the serving probe's declared-vs-served check passes (the registry records the detail).
    gptoss-20b)    GGUF_REL="gpt-oss-20b-GGUF/gpt-oss-20b-F16.gguf";                      ALIAS="gpt-oss-20b";     QUANT="F16";        CTX=131072; THINK_KIND=always
                   # plan v2.5.24 gave gpt-oss --swa-full (llama.cpp #27720: its malformed
                   # harmony headers follow partial prompt-cache reuse); v2.5.26 serves every
                   # model with it, so it now lives in FROZEN_FLAGS.
                   THINK_ON_BODY='{"chat_template_kwargs":{"reasoning_effort":"medium"}}' ;;
    # Muse Glimmer 30B (Meta, released 2026-08-10) -- wired in plan v2.5.19 for a pilot; in the
    # GRID since plan v2.5.20, as tier 6, two arms. STATUS 2026-09-30 -- all five steps done:
    #   1. hashed into quant-registry.json (UD-Q4_K_XL)
    #   2. template extracted: sha256 114f55ebdc1804c1, 7,167 chars; it reads reasoning_strength
    #      (default 'high') and renders every past turn's reasoning_content as a `to=self`
    #      message with no flag. It drops an assistant turn's prose when the turn has tool calls,
    #      in both arms alike; Muse wrote no prose beside a call in its pilot.
    #   3-4. live probe: UNSEEN->SEEN +232 chars, both turns' reasoning; marker test ACCEPTED
    #   5. pilot smoke (6 runs, 30 min): all 16 gates pass once registered, 0 parse voids, 6/6
    #      finished; registered in verify_smokes.py's EXPECTED_* tables
    # What follows is the note as written at wiring.
    # DENSE, ~29.6B including a 1.8B vision encoder that is not loaded here (no --mmproj: text
    # only); 52 layers of local/global attention (a 2,048-token window, every fourth layer
    # global), 2 KV heads; Apache 2.0. Architecture `muse-glimmer`, which llama.cpp has
    # supported since b10353, so the pinned b10964 loads it without an engine bump.
    # TWO ARMS, like gpt-oss: its reasoning strength (low / medium / high / xhigh) has no off
    # level -- Meta's llama.cpp guide: reasoning "can't be turned off". The template reads
    # chat_template_kwargs.reasoning_strength and defaults it to 'high', the level Meta advises
    # for coding and agentic work. The body sends 'high' explicitly anyway, so every manifest
    # records the level rather than inheriting a default.
    # ITS FORMAT IS ATEM, a harmony-like envelope: <|start|>role<|message|>...<|eot|>, the
    # recipient in the header (to=self for reasoning, to=<tool> for a call, to=user for prose),
    # calls as <atem:function_calls><atem:invoke name=...><atem:parameter name=...>. llama-server
    # parses it server-side with --jinja (in FROZEN_FLAGS), returning the reasoning in
    # reasoning_content and the calls in tool_calls. The parser is new -- its author called what
    # shipped "the basic minimum to allow tool calling" -- so parse voids are what the pilot is
    # for: the harness files the server's "peg-native" refusal as model_output_unparseable,
    # per arm, exactly as for gpt-oss's harmony.
    # REPLAY: the published template renders a past turn's reasoning_content as its own
    # `to=self` message for EVERY assistant turn that carries one -- no keep-history flag and no
    # last-user-message gate -- so the `field` route is right and the finish nudge cannot
    # shrink SEEN. Read from Meta's published template, NOT yet from the served GGUF.
    # PATH: unsloth publishes this model only as Dynamic quants -- no plain Q4_K_M -- so the
    # study's four-bit file is UD-Q4_K_XL (15.9 GB), keyed like Magistral's. LM Studio may save
    # it under another folder name (it did for Nemotron and the twins); if the batch preflight
    # says the file is missing, fix GGUF_REL below to where it really is.
    # The five steps, as for every model:
    #   1. hash:   python3 tools/hash_quants.py --model muse-glimmer-30b --key UD-Q4_K_XL <gguf>
    #   2. extract the template (gguf_chat_template.py --out templates) and read it
    #   3. desk-render (render_arms.py templates --show muse)
    #   4. prove it on the live server (template_probe.sh muse-q4xl), then the marker test
    #      (tools/probe_reasoning_replay.py --model-key muse-q4xl --max-tokens 4096)
    #   5. smoke it ALONE (SMOKE_ROOT=/tmp/runs/muse-pilot ./run_thinking_batch.sh smoke
    #      muse-q4xl), then register its expected body/format/preamble in verify_smokes.py
    # Registered after step 5 (plan v2.5.20).
    muse-q4xl)     GGUF_REL="Muse-Glimmer-30B-GGUF/Muse-Glimmer-30B-UD-Q4_K_XL.gguf"; ALIAS="muse-glimmer-30b"; QUANT="UD-Q4_K_XL"; CTX=131072; THINK_KIND=always
                   THINK_ON_BODY='{"chat_template_kwargs":{"reasoning_strength":"high"}}' ;;
    *) echo "FATAL: unknown model key '$1' (add it to resolve_model)" >&2; exit 2 ;;
  esac
}

# The EXTRA_BODY for this model with thinking on|off. Prints JSON; fails (to stderr) when
# the model has no documented off-switch.
#
# NOTE on the plain-body default: it is a named variable, NOT an inline "${THINK_ON_BODY:-{...}}"
# default. Bash ends a ${VAR:-word} expansion at the first unescaped '}' inside word, so the
# old spelling silently appended a stray '}' whenever THINK_ON_BODY was set -- which made every
# gpt-oss run die at startup on "--extra-body is not valid JSON". Keep the default out of the
# braces, and keep the validator in apply_arm.
# EXTRA_BODY carries ONLY chat_template_kwargs now: the template switch, which is the
# treatment. Samplers are flags read from decoding-registry.json (plan §4.4.1). top_k
# used to live here, which meant the study's most consequential sampler never appeared
# in the manifest's decoding block at all.
PLAIN_BODY='{}'
think_body() {
  case "$THINK_KIND:$1" in
    # preserve_thinking is sent in ALL THREE arms, and it is not an afterthought.
    # Gemma's and Qwen's templates render a past turn's reasoning only when that turn sits
    # AFTER the last user message (`loop.index0 > ns.last_query_index`). In an agentic loop
    # there is normally one user message -- the task -- so every assistant turn qualifies
    # and SEEN shows the whole run. But the harness appends a `role: user` finish nudge
    # when a model returns a turn with no tool call, and that MOVES the window: from then
    # on, every thought before the nudge disappears from the model's view. Rendered against
    # both templates, turn 1's reasoning is present without a nudge, absent with one, and
    # present again with preserve_thinking -- and the nudge fired in 5 of 15 SEEN runs in
    # the 2026-09-21 smoke set. Without this flag, SEEN silently means "sees its reasoning
    # since the last nudge" in a third of its runs.
    # Sent in OFF and UNSEEN too, where it is a no-op (no reasoning_content is sent, so
    # there is nothing to preserve), so that the thinking arms stay byte-identical in body
    # and the only thing that ever moves across the ladder is enable_thinking and whether
    # the reasoning is sent at all.
    enable_thinking:on)  echo '{"chat_template_kwargs":{"enable_thinking":true,"preserve_thinking":true}}' ;;
    enable_thinking:off) echo '{"chat_template_kwargs":{"enable_thinking":false,"preserve_thinking":true}}' ;;
    # Granite 4.2 does the same two jobs with two different names, and one of them has the
    # OPPOSITE polarity, which is exactly the kind of detail that produces a silent null
    # treatment. enable_thinking is shared. But where Gemma and Qwen take
    # preserve_thinking:TRUE to keep a past turn's reasoning, Granite takes
    # truncate_history_thinking:FALSE -- its template strips prior thinking by default to
    # save context, and this is the documented opt-out. Getting the polarity backwards
    # here would leave SEEN rendering nothing while the manifest happily records that the
    # reasoning was sent, so the kind is kept SEPARATE from enable_thinking rather than
    # folded in with a variable flag name: two explicit lines that can be read, instead of
    # one clever one that can be misread. Sent in all three arms for the same reason
    # preserve_thinking is -- the only things that move across the ladder are
    # enable_thinking and whether the reasoning is replayed at all.
    # UNVERIFIED: documented on the model card, not yet read out of the GGUF served here.
    enable_thinking_granite:on)  echo '{"chat_template_kwargs":{"enable_thinking":true,"truncate_history_thinking":false}}' ;;
    enable_thinking_granite:off) echo '{"chat_template_kwargs":{"enable_thinking":false,"truncate_history_thinking":false}}' ;;
    # Nemotron-3-Nano: the same two names and the same polarity as Granite, read out of the
    # served GGUF (template sha256 b3043677cd5fc67f), whose history gate is Granite's
    # expression character for character. Kept as its OWN kind all the same, so that if the
    # live probe disagrees with the desk render, these two lines change and Granite's do not.
    # Desk-checked and live-probed 2026-09-25 (template_probe.sh nemotron-q4: +150 chars, as
    # on the desk). Nemotron was retired in plan v2.5.1 (§5) -- for its behaviour, not this body.
    enable_thinking_nemotron:on)  echo '{"chat_template_kwargs":{"enable_thinking":true,"truncate_history_thinking":false}}' ;;
    enable_thinking_nemotron:off) echo '{"chat_template_kwargs":{"enable_thinking":false,"truncate_history_thinking":false}}' ;;
    # GLM-4.7-Flash: a THIRD name for the keep-history flag, with Granite's polarity again.
    # Z.ai's published template renders a past turn's reasoning when
    #   ((clear_thinking is defined and not clear_thinking) or loop.index0 > ns.last_user_index)
    # -- a plain OR, so clear_thinking:FALSE shows every past turn's reasoning whatever the
    # nudge does, and leaving it UNSET clears history. Z.ai calls false "Preserved Thinking".
    # Sent in all three arms, as the other flags are. Its own kind, for the usual reason.
    # VERIFIED 2026-09-25: the served template (sha256 d63ad536c3c81880) carries that gate at
    # line 52 of the extracted file, and template_probe.sh glm-q4 passed at +158 chars, the
    # desk render's delta. GLM is the roster's sixth model as of plan v2.5.0.
    enable_thinking_glm:on)  echo '{"chat_template_kwargs":{"enable_thinking":true,"clear_thinking":false}}' ;;
    enable_thinking_glm:off) echo '{"chat_template_kwargs":{"enable_thinking":false,"clear_thinking":false}}' ;;
    thinking_budget:on)  echo "$PLAIN_BODY" ;;                                  # template default: unlimited thinking
    thinking_budget:off) echo '{"chat_template_kwargs":{"thinking_budget":0}}' ;;
    always:on)           echo "${THINK_ON_BODY:-$PLAIN_BODY}" ;;
    # The switch for this kind is the system prompt, not the request body; the body is
    # byte-identical in both arms, which is exactly the property we want on record.
    system_preamble:on)  echo "$PLAIN_BODY" ;;
    system_preamble:off) echo "$PLAIN_BODY" ;;
    always:off)          echo "FATAL: ARM=off is not available for '$MODEL_KEY' — no documented thinking off-switch (run two arms, or prove one with a canary and add it to think_body)" >&2; return 1 ;;
    *) echo "FATAL: unknown THINK_KIND '$THINK_KIND'" >&2; return 1 ;;
  esac
}

# ARM=off|unseen|seen -> REPLAY_REASONING + EXTRA_BODY, derived, never hand-typed.
apply_arm() {
  [ -n "$ARM" ] || return 0
  ARM="$(printf '%s' "$ARM" | tr '[:upper:]' '[:lower:]')"
  if [ -n "${EXTRA_BODY-}" ] || [ -n "${REPLAY_REASONING-}" ] || [ -n "${THINK_PREAMBLE-}" ]; then
    die "ARM=$ARM derives EXTRA_BODY, REPLAY_REASONING and THINK_PREAMBLE — unset those three, or drop ARM"
  fi
  case "$ARM" in
    seen)   REPLAY_REASONING=1;  EXTRA_BODY="$(think_body on)"  || exit 1; THINK_PREAMBLE="${THINK_PREAMBLE_KEY:-none}" ;;
    unseen) REPLAY_REASONING=0;  EXTRA_BODY="$(think_body on)"  || exit 1; THINK_PREAMBLE="${THINK_PREAMBLE_KEY:-none}" ;;
    # OFF: replay is set OFF explicitly rather than left at the harness default. In this
    # arm the model produces no reasoning, so replaying it is a no-op -- provably so: across
    # the 2026-09-20 smokes, Gemma's 84 OFF steps, Qwen's 160 and Magistral's 36 preamble-free
    # responses carried 0 characters of reasoning between them. It is NOT a no-op for a
    # template that emits boilerplate in the reasoning field: Seed-OSS under thinking_budget:0
    # returns a fixed 133-character budget-reflect stub every turn, and replaying THAT made the
    # model fall silent on 55% of its turns (6 empty turns in 11 steps, all three runs dead in
    # 3-4 steps). With replay off the same configuration produced 0 empty turns in 33 steps.
    # So: one rule for every model, no per-model exception -- in the OFF arm there is nothing
    # to replay, and the flag says so.
    off)    REPLAY_REASONING=0;  EXTRA_BODY="$(think_body off)" || exit 1; THINK_PREAMBLE="none" ;;
    *) die "ARM must be off|unseen|seen (got '$ARM')" ;;
  esac
  # For every kind but system_preamble this is "none" in all three arms, so the system
  # prompt is byte-identical across the ladder and the only thing that moves is the
  # template switch. For system_preamble it is the switch itself, and the two THINKING
  # arms still share it — the primary UNSEEN->SEEN contrast never varies the prompt.
  # The body is the treatment. A malformed one is not a typo to shrug at: the agent rejects it
  # and the run dies seconds later with a message nobody reads until six runs are gone. Fail
  # here instead, before the server is ever started.
  printf '%s' "$EXTRA_BODY" | python3 -c 'import json,sys; json.loads(sys.stdin.read())' 2>/dev/null \
    || die "EXTRA_BODY is not valid JSON for arm=$ARM model=$MODEL_KEY: $EXTRA_BODY"
  REPLAY_FORMAT="$REPLAY_FORMAT_KEY"
  # The OFF arm is the model's non-thinking mode, the two thinking arms its thinking mode.
  # For every model but Qwen these resolve to the same numbers, because only Qwen's vendor
  # documents a split; the mapping is written once here rather than per model.
  case "$ARM" in
    off) DECODING_MODE=non_thinking ;;
    *)   DECODING_MODE=thinking ;;
  esac
  # plan v2.5.19: `|| exit 1`, because die() inside a command substitution ends only the
  # subshell -- without it a failed lookup ran on with empty flags (see decoding_flags).
  DECODING_FLAGS="$(decoding_flags "$ALIAS" "$DECODING_MODE")" || exit 1
  export REPLAY_REASONING EXTRA_BODY THINK_PREAMBLE REPLAY_FORMAT DECODING_MODE DECODING_FLAGS
  say "decoding[$DECODING_MODE] $DECODING_FLAGS"
  say "arm=$ARM -> REPLAY_REASONING='${REPLAY_REASONING}' EXTRA_BODY='$EXTRA_BODY' THINK_PREAMBLE='${THINK_PREAMBLE}' REPLAY_FORMAT='${REPLAY_FORMAT}'"
}

# ----------------------------------------------------------------------------
WRAPPER_VERSION="2026-10-03-native-ctx"  # printed at start; bump when this file changes (plan v2.5.32: native windows where they fit)
say()  { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*"; }
# Total GPU memory in use, MiB (global: includes Windows-side processes). 0 if unavailable.
gpu_mem_mib() { nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits 2>/dev/null | head -n 1 | tr -dc '0-9' || echo 0; }
die()  { say "FATAL: $*" >&2; exit 1; }

# Draw a 6-digit id and re-draw until it is unused by EVERY record we have:
#   1. the ledger (blind-ids.txt) — ids from runs long since moved off and deleted;
#   2. the key file — belt-and-braces, in case the ledger is ever lost;
#   3. what is actually on disk under OUTPUT_ROOT, in either layout.
# The winning id is appended to the ledger immediately, before anything is created,
# so an id is burned the moment it is chosen — a crash or Ctrl-C cannot free it.
id_is_used() {
  local id="$1"
  { [ -f "$BLIND_IDS_FILE" ] && grep -qx "$id" "$BLIND_IDS_FILE"; } && return 0
  { [ -f "$BLIND_KEY_FILE" ] && grep -q "\"blind_id\": \"$id\"" "$BLIND_KEY_FILE"; } && return 0
  compgen -G "$OUTPUT_ROOT/*/runs/$id" >/dev/null 2>&1 && return 0
  compgen -G "$OUTPUT_ROOT/*/*/runs/$id" >/dev/null 2>&1 && return 0
  return 1
}
pick_blind_id() {
  local id tries=0
  mkdir -p "$BLIND_STATE_DIR" || return 1
  while :; do
    id="$(shuf -i 100000-999999 -n 1)"
    tries=$((tries + 1))
    if ! id_is_used "$id"; then
      echo "$id" >> "$BLIND_IDS_FILE" || return 1   # reserve it, permanently
      printf '%s' "$id"; return 0
    fi
    [ "$tries" -lt 200 ] || return 1
  done
}

[ $# -ge 3 ] || die "usage: $0 <model-key> <task> <condition> <run-id>   (or BLIND=1 $0 <model-key> <task> <condition> [label])"
MODEL_KEY="$1"; TASK="$2"; CONDITION="$3"; RUN_ID="${4:-}"
# Anything after the four positionals is forwarded verbatim to harness.agent, LAST, so it
# overrides everything the wrapper derived (argparse keeps the final occurrence). This is
# for DIAGNOSTIC runs only -- raising --max-tokens to find out whether a cap or the model
# is the binding constraint, say. A study run must not use it: the flags it would override
# are the frozen settings, every one of them recorded per run, and a run that quietly
# differs from its batch is exactly what the gates exist to catch. It is visible in the
# manifest's command line either way.
EXTRA_AGENT_ARGS=("${@:5}")
[ ${#EXTRA_AGENT_ARGS[@]} -eq 0 ] || \
  say "DIAGNOSTIC: forwarding to the agent, overriding the wrapper: ${EXTRA_AGENT_ARGS[*]}"
# PER-REPLICATE SEED. A run id is <arm digit><replicate>, so 103 is OFF replicate 3 and 203
# is UNSEEN replicate 3 -- which means the replicate number is already in hand and the same
# number identifies the same replicate in every arm. Seeding from it therefore pairs the
# arms: replicate 3 of OFF, UNSEEN and SEEN all draw from seed 3. That is common random
# numbers, and it removes some of the sampling noise from the very contrast the study is
# measuring. Under the old greedy configuration the seed was inert; it is not any more
# (plan §4.4.1). 10# forces base 10, or 08 and 09 would be invalid octal.
#
# plan v2.5.12 -- AND IN THE BLIND LAYOUT. There the id handed in is not yet a run id but the
# batch driver's schedule label, <model>/<task>/<condition>/<arm>/r<NN>; the random blind id
# replaces it only further down. The arithmetic used to be applied to the label, failed
# ("value too great for base"), printed a bash error and left RUN_SEED empty -- so every grid
# run would have gone out with no per-request seed, the server's pinned --seed 0 on every
# request, instead of its replicate's (plan §4.4). The replicate is the label's trailing
# r<NN>, so it is taken from there, and a blind run whose label yields none is refused rather
# than run unseeded. A classic id that is not <arm digit><digits> runs unseeded, as it always
# did, but now says so.
RUN_SEED=""
if [ "$BLIND" = "1" ]; then
  case "$RUN_ID" in
    */r[0-9]*)   _rep="${RUN_ID##*/r}" ;;
    [1-3][0-9]*) _rep="${RUN_ID:1}" ;;
    *)           _rep="" ;;
  esac
  case "$_rep" in
    ''|*[!0-9]*) die "a blind run needs its schedule label, <model>/<task>/<condition>/<arm>/r<NN>, so that it carries its replicate's seed (got '${RUN_ID}')" ;;
  esac
  RUN_SEED="$(( 10#$_rep ))"
elif [ -n "$RUN_ID" ] && [ "${#RUN_ID}" -gt 1 ]; then
  case "${RUN_ID:1}" in
    *[!0-9]*) say "WARNING: run id '$RUN_ID' is not <arm digit><replicate>, so this run has no per-request seed" ;;
    *)        RUN_SEED="$(( 10#${RUN_ID:1} ))" ;;
  esac
fi
say "wrapper $WRAPPER_VERSION"
resolve_model "$MODEL_KEY"
# DIAGNOSTIC ONLY: NO_SWA_FULL=1 serves the model without --swa-full, and
# NO_MODEL_SERVER_FLAGS=1 without its per-model flags, to measure what they change. Such a run
# fails G17, so it can never pass as a study run.
if [ "${NO_SWA_FULL:-0}" = 1 ]; then
  say "DIAGNOSTIC: NO_SWA_FULL=1 drops --swa-full -- not a frozen-spec run"
  _ff=(); for _f in "${FROZEN_FLAGS[@]}"; do [ "$_f" = "--swa-full" ] || _ff+=("$_f"); done
  FROZEN_FLAGS=("${_ff[@]}")
fi
if [ "${NO_MODEL_SERVER_FLAGS:-0}" = 1 ] && [ "${#MODEL_SERVER_FLAGS[@]}" -gt 0 ]; then
  say "DIAGNOSTIC: NO_MODEL_SERVER_FLAGS=1 drops '${MODEL_SERVER_FLAGS[*]}' -- not a frozen-spec run"
  MODEL_SERVER_FLAGS=()
fi
apply_arm

BLIND_LABEL=""
if [ "$BLIND" = "1" ]; then
  BLIND_LABEL="$RUN_ID"                       # free text for the key file only
  RUN_ID="$(pick_blind_id)" || die "could not find an unused blind run id after 200 draws"
  RUN_BASE="$OUTPUT_ROOT/$TASK/runs/$RUN_ID"  # no condition level, random id
else
  [ -n "$RUN_ID" ] || die "run-id is required unless BLIND=1"
  RUN_BASE="$OUTPUT_ROOT/$TASK/$CONDITION/runs/$RUN_ID"
  [ -e "$RUN_BASE" ] && say "WARNING: $RUN_BASE already exists — run.sh will clean and reuse it"
fi
RUN_LOGS="$RUN_BASE/smoke/logs"

# A model key may carry an ABSOLUTE gguf path instead of one relative to MODELS_ROOT_WSL.
# LM Studio files by publisher, this study's roster happens to sit under unsloth/, and a
# model from a different publisher is not worth bending that root for -- nor worth an env
# var that someone will forget on the one run that matters.
case "$GGUF_REL" in
  /*) GGUF_WSL="$GGUF_REL" ;;
  *)  GGUF_WSL="$MODELS_ROOT_WSL/$GGUF_REL" ;;
esac
GGUF_BASENAME="$(basename "$GGUF_REL")"
# ---- engine preflight -------------------------------------------------------------------
# The file being PRESENT is not the same as the file being RUNNABLE, and on 2026-09-23 this
# machine demonstrated the difference: the pinned b10964 ran all 42 smoke runs, the machine
# was shut down, and on the next boot Windows Smart App Control committed from evaluation to
# ENFORCED. From then on the Windows loader refused every unsigned binary in the engine
# folder -- 51 of its 54 are unsigned -- and llama-server.exe exited with 0xC0E90002
# (-1058471934 as a signed int) BEFORE main(), so it printed nothing at all: no stdout, no
# stderr, an empty redirect file, and a health check that simply never went green. From the
# runner's point of view that is indistinguishable from "the model failed to load", and it
# cost three hours to tell apart. A 75-hour grid cannot afford to learn this at hour 40, so
# the engine is asked to identify itself before anything else happens.
engine_preflight() {
  local out rc
  out="$(timeout 30 "$SERVER_EXE_WSL" --version 2>&1)"; rc=$?
  if [ "$rc" -ne 0 ] || [ -z "$out" ]; then
    die "ENGINE PREFLIGHT FAILED — '$SERVER_EXE_WSL --version' exited $rc and printed ${#out} bytes.
     The binary is there; the OS will not run it. Silence plus a non-zero exit means the
     loader refused the image before the program started, so nothing downstream -- not the
     server log, not /health, not a model -- can tell you anything useful.
     Exit -1058471934 (0xC0E90002) is a Windows Bad Image / code-integrity refusal, and the
     usual cause on this machine is Smart App Control, which blocks unsigned binaries and
     supports no per-app exclusion. Check it with:
       reg query \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\CI\\Policy\" /v VerifiedAndReputablePolicyState
       (0 = off, 1 = ENFORCED, 2 = evaluation)
       Get-WinEvent -LogName Microsoft-Windows-CodeIntegrity/Operational -MaxEvents 30
     Note it is NOT in the Application log and NOT a Defender detection, so both of those
     come back empty and look reassuring. Do not 'fix' this by switching engine builds: the
     build number is part of the pin and every smoke run recorded b10964-b29c606e2."
  fi
  say "engine preflight ok — $(printf '%s' "$out" | head -n 1)"
}

[ -f "$SERVER_EXE_WSL" ] || die "llama-server.exe not found at $SERVER_EXE_WSL"
engine_preflight
[ -f "$GGUF_WSL" ]       || die "model file not found: $GGUF_WSL"
[ -f "$AGENT_DIR/run.sh" ] || die "run.sh not found in $AGENT_DIR"
GGUF_WIN="$(wslpath -w "$GGUF_WSL")" || die "wslpath failed for $GGUF_WSL"

# Refuse to start on top of an already-running server on our port: every run must
# know exactly which process served it.
if curl -fsS --max-time 3 "$BASE_URL/health" >/dev/null 2>&1; then
  die "something is already serving on $BASE_URL — stop it first (taskkill.exe /IM llama-server.exe /F)"
fi

SERVER_LOG="$(mktemp /tmp/llama-server-XXXXXX.log)"
SERVER_PID=""
GPU_BASE_MIB=0
SCRATCH_ROOT=""
AGENT_RC=99
STARTED_AT="$(date -Is)"

start_server() {
  GPU_BASE_MIB="$(gpu_mem_mib)"; GPU_BASE_MIB="${GPU_BASE_MIB:-0}"
  say "starting llama-server: $GGUF_BASENAME  (alias=$ALIAS ctx=$CTX port=$PORT; gpu baseline ${GPU_BASE_MIB} MiB)${VERBOSITY_DIAG:+  [DIAGNOSTIC: -lv $SERVER_VERBOSITY, not a frozen-spec run]}"
  {
    echo "=== llama-server launch $(date -Is) ==="
    echo "exe:   $SERVER_EXE_WSL"
    echo "model: $GGUF_WIN"
    # Built up rather than interpolated with a trailing expansion, so the line is
    # byte-identical for every frozen-spec run -- this banner IS the per-run record of the
    # serving spec (gate G17 reads it), and a stray space in it is a diff.
    _args="-m <model> -c $CTX --alias $ALIAS ${FROZEN_FLAGS[*]}"
    [ "${#MODEL_SERVER_FLAGS[@]}" -gt 0 ] && _args="$_args ${MODEL_SERVER_FLAGS[*]}"
    [ "${#SERVER_EXTRA_FLAGS[@]}" -gt 0 ] && _args="$_args ${SERVER_EXTRA_FLAGS[*]}"
    echo "args:  $_args"
    # Stated separately as well as in the arg list, so a run made with raised verbosity is
    # obvious to anyone reading this log rather than something they have to notice.
    if [ -n "$VERBOSITY_DIAG" ]; then
      echo "verbosity: $SERVER_VERBOSITY (DIAGNOSTIC -- the frozen level is 5; not a frozen-spec run)"
    else
      echo "verbosity: 5 (FROZEN since plan v2.5.27 -- each request's rendered prompt and the model's raw output are logged)"
    fi
    echo "======================================="
  } > "$SERVER_LOG"
  "$SERVER_EXE_WSL" -m "$GGUF_WIN" -c "$CTX" --alias "$ALIAS" "${FROZEN_FLAGS[@]}" \
      ${MODEL_SERVER_FLAGS[@]+"${MODEL_SERVER_FLAGS[@]}"} \
      ${SERVER_EXTRA_FLAGS[@]+"${SERVER_EXTRA_FLAGS[@]}"} >> "$SERVER_LOG" 2>&1 &
  SERVER_PID=$!
  say "server launched (wsl pid $SERVER_PID), log: $SERVER_LOG"
}

wait_for_server() {
  say "waiting for $BASE_URL/health (timeout ${SERVER_TIMEOUT_S}s)..."
  local t0=$SECONDS
  while :; do
    if curl -fsS --max-time 3 "$BASE_URL/health" >/dev/null 2>&1; then break; fi
    if ! kill -0 "$SERVER_PID" 2>/dev/null; then
      say "server process exited during startup; last log lines:"; tail -n 30 "$SERVER_LOG"; exit 1
    fi
    if [ $((SECONDS - t0)) -ge "$SERVER_TIMEOUT_S" ]; then
      say "timeout; last log lines:"; tail -n 30 "$SERVER_LOG"; stop_server; exit 1
    fi
    sleep 2
  done
  say "healthy after $((SECONDS - t0))s"

  # Identity gate: the server must report the exact file we intended to serve.
  local props; props="$(curl -fsS --max-time 5 "$BASE_URL/props" 2>/dev/null || true)"
  if ! printf '%s' "$props" | grep -qF "$GGUF_BASENAME"; then
    say "SERVING MISMATCH: /props does not mention $GGUF_BASENAME"
    printf '%s' "$props" | head -c 600; echo
    stop_server; exit 1
  fi
  say "identity confirmed: /props reports $GGUF_BASENAME"

  # GPU gate. A server whose CUDA backend failed to load (missing cudart/cublas DLLs
  # beside the .exe, driver mismatch) still answers /health and /props — on the CPU,
  # 10-30x slower. The check is GPU MEMORY, not the log: llama-server's stderr is
  # block-buffered when redirected to a file, so the boot lines are usually not there
  # yet at this point. nvidia-smi in WSL reports the Windows GPU's total memory use
  # (it cannot list Windows processes, but memory.used is global and correct).
  if [ "${GPU_GATE:-1}" = 1 ] && command -v nvidia-smi >/dev/null 2>&1; then
    local now delta need size_mib
    now="$(gpu_mem_mib)"
    size_mib=$(( $(stat -c %s "$GGUF_WSL" 2>/dev/null || echo 0) / 1048576 ))
    delta=$(( now - GPU_BASE_MIB ))
    need=$(( size_mib / 2 ))                       # weights alone; the KV cache adds more
    [ "$need" -lt 1000 ] && need=1000
    if [ "$delta" -lt "$need" ]; then
      say "GPU GATE: GPU memory rose only ${delta} MiB (expected >= ${need} MiB for a ${size_mib} MiB model)"
      say "  the server is on the CPU. Check: ls \"$(dirname "$SERVER_EXE_WSL")\" | grep -iE 'cudart|cublas'"
      say "  and: $SERVER_EXE_WSL --list-devices   (must list CUDA0)"
      say "  server log so far ($SERVER_LOG):"
      sed -n '6,30p' "$SERVER_LOG" 2>/dev/null
      stop_server; exit 1
    fi
    say "gpu: +${delta} MiB resident (model ${size_mib} MiB) — running on the GPU"
  elif [ "${GPU_GATE:-1}" = 1 ]; then
    say "WARNING: nvidia-smi not found; cannot verify the server is on the GPU"
  fi
}

stop_server() {
  [ -n "$SERVER_PID" ] || return 0
  say "stopping llama-server (pid $SERVER_PID)"
  kill "$SERVER_PID" 2>/dev/null
  local t0=$SECONDS
  while curl -fsS --max-time 2 "$BASE_URL/health" >/dev/null 2>&1; do
    if [ $((SECONDS - t0)) -ge 15 ]; then
      say "still up after 15s — force-killing all llama-server.exe"
      taskkill.exe /IM llama-server.exe /F >/dev/null 2>&1
      break
    fi
    sleep 1
  done
  wait "$SERVER_PID" 2>/dev/null
  SERVER_PID=""
  sleep 1   # let the log file flush
  say "server stopped"
}

cleanup() {
  stop_server
  # scratch only ever holds run.sh's console.log copy + empty dirs; safe to drop
  [ -n "$SCRATCH_ROOT" ] && [ -d "$SCRATCH_ROOT" ] && rm -rf "$SCRATCH_ROOT"
}
trap cleanup INT TERM
trap cleanup EXIT

run_agent() {
  say "running agent: model=local/$ALIAS task=$TASK cond=$CONDITION run=$RUN_ID arm=${ARM:-manual} blind=$BLIND replay=${REPLAY_REASONING:-<default>} guards=${MAX_SAME_CALLS}/${MAX_CYCLE_REPEATS}/${MAX_BLOCKED_CALLS}/${MAX_REPEAT_STEPS}"
  # run.sh takes task/condition/model/run as POSITIONAL args (in that order); everything
  # else it reads from the environment. `local/<alias>` makes run.sh route to LOCAL_BASE_URL
  # and strip the prefix before sending the real id (which the server's --alias advertises).
  local run_output_root="$OUTPUT_ROOT"
  local -a overrides=()
  if [ "$BLIND" = "1" ]; then
    # run.sh always builds <root>/<task>/<condition>/runs/<run>, but it forwards extra
    # args to the harness LAST, and the harness keeps the last occurrence — so we point
    # the harness at the blind paths directly and let run.sh's own tree land in scratch
    # (only its tee'd console.log goes there; we move it over afterwards).
    SCRATCH_ROOT="$(mktemp -d /tmp/blind-scratch-XXXXXX)"
    run_output_root="$SCRATCH_ROOT"
    mkdir -p "$RUN_LOGS" "$RUN_BASE/smoke/screenshot"
    overrides=(--workspace "$RUN_BASE/app/" --run-dir "$RUN_LOGS/" --screenshot-dir "$RUN_BASE/smoke/screenshot")
    say "blind run: outputs -> $RUN_BASE"
  fi
  ( cd "$AGENT_DIR" && \
    OUTPUT_ROOT="$run_output_root" LOCAL_BASE_URL="$LOCAL_BASE_URL" \
    QUANT="$QUANT" QUANT_REGISTRY="$QUANT_REGISTRY" \
    REPLAY_REASONING="${REPLAY_REASONING-}" EXTRA_BODY="${EXTRA_BODY-}" \
    THINK_PREAMBLE="${THINK_PREAMBLE-}" REPLAY_FORMAT="${REPLAY_FORMAT-}" \
    MAX_SAME_CALLS="$MAX_SAME_CALLS" MAX_CYCLE_REPEATS="$MAX_CYCLE_REPEATS" \
    MAX_BLOCKED_CALLS="$MAX_BLOCKED_CALLS" MAX_REPEAT_STEPS="$MAX_REPEAT_STEPS" \
    MAX_TOTAL_TOKENS="$MAX_TOTAL_TOKENS" \
    bash ./run.sh "$TASK" "$CONDITION" "local/$ALIAS" "$RUN_ID" \
      ${DECODING_FLAGS:+$DECODING_FLAGS} \
      ${DECODING_MODE:+--decoding-profile "$DECODING_MODE"} \
      ${DECODING_MODE:+--decoding-registry "$DECODING_REGISTRY"} \
      ${RUN_SEED:+--seed "$RUN_SEED"} \
      ${overrides[@]+"${overrides[@]}"} \
      ${EXTRA_AGENT_ARGS[@]+"${EXTRA_AGENT_ARGS[@]}"} )
  AGENT_RC=$?
  say "agent finished with exit code $AGENT_RC"
  if [ "$BLIND" = "1" ]; then
    local scratch_console="$SCRATCH_ROOT/$TASK/$CONDITION/runs/$RUN_ID/smoke/logs/console.log"
    [ -f "$scratch_console" ] && mv "$scratch_console" "$RUN_LOGS/console.log"
    rm -rf "$SCRATCH_ROOT"; SCRATCH_ROOT=""
  fi
}

# The toolchain the agent worked inside, recorded next to its logs: Node/npm are what its
# npm install / npm run dev actually used (same PATH as this shell), plus the engine build.
write_environment() {
  local dest="$1"
  {
    echo "recorded_at: $(date -Is)"
    echo "node: $(node --version 2>/dev/null || echo unknown)  ($(command -v node 2>/dev/null || echo -))"
    echo "npm: $(npm --version 2>/dev/null || echo unknown)"
    echo "npm_before: $(npm config get before 2>/dev/null || echo unset)   # registry freeze date; 'null'/'unset' = live resolution"
    echo "python3: $(python3 --version 2>/dev/null || echo unknown)"
    echo "playwright: $(python3 -c 'import playwright,sys; print(getattr(playwright,"__version__","?"))' 2>/dev/null || echo unknown); chromium: $(timeout 20 python3 -c 'from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(); print(b.version); b.close()' 2>/dev/null || echo unknown)"
    echo "llama-server: $(timeout 15 "$SERVER_EXE_WSL" --version 2>&1 | head -n 2 | tr '\n' ' ' || echo unknown)"
    echo "gpu: $(nvidia-smi --query-gpu=name,driver_version,memory.total --format=csv,noheader 2>/dev/null || echo unknown)"
    echo "wsl: $(uname -srm 2>/dev/null || echo unknown)"
  } > "$dest/environment.txt" 2>/dev/null
}

archive_server_log() {
  if [ -d "$RUN_LOGS" ]; then
    write_environment "$RUN_LOGS"
    cp "$SERVER_LOG" "$RUN_LOGS/llama-server.log" && say "server log -> $RUN_LOGS/llama-server.log"
  else
    local fb="$OUTPUT_ROOT/server-logs"; mkdir -p "$fb"
    cp "$SERVER_LOG" "$fb/llama-server-$TASK-$CONDITION-$RUN_ID.log"
    say "WARNING: run logs dir not found ($RUN_LOGS); server log kept at $fb/llama-server-$TASK-$CONDITION-$RUN_ID.log"
  fi
  rm -f "$SERVER_LOG"
}

# One JSON line per blind run, appended OUTSIDE the runs tree: the un-blinding key.
# (manifest.json inside the run also carries condition/arm/quant — this is the index.)
write_blind_key() {
  [ "$BLIND" = "1" ] || return 0
  mkdir -p "$(dirname "$BLIND_KEY_FILE")"
  python3 - "$BLIND_KEY_FILE" "$RUN_ID" "$TASK" "$CONDITION" "$MODEL_KEY" "$ALIAS" "$QUANT" \
             "${REPLAY_REASONING-}" "${EXTRA_BODY-}" "$BLIND_LABEL" "$RUN_BASE" "$STARTED_AT" "$AGENT_RC" "${ARM:-}" <<'EOF'
import json, sys, datetime, os
(key, rid, task, cond, mkey, alias, quant, replay, extra, label, base, started, rc, arm) = sys.argv[1:15]
status = None
try:
    status = json.load(open(os.path.join(base, "smoke", "logs", "manifest.json"))).get("status")
except Exception:
    pass
rec = {"blind_id": rid, "task": task, "condition": cond, "arm": arm or None, "model_key": mkey,
       "alias": alias, "quant": quant, "replay_reasoning": replay or "default", "extra_body": extra or None,
       "label": label or None, "run_base": base, "started_at": started,
       "ended_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
       "agent_rc": int(rc), "status": status}
with open(key, "a", encoding="utf-8") as f:
    f.write(json.dumps(rec) + "\n")
EOF
  say "blind key appended -> $BLIND_KEY_FILE"
}

start_server
wait_for_server
run_agent
stop_server
archive_server_log
write_blind_key

say "done: $MODEL_KEY $TASK/$CONDITION run $RUN_ID (agent rc=$AGENT_RC)"
exit "$AGENT_RC"
