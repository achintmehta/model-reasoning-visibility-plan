"""Standalone verification of the interactive browser tools (interactive_support).

Run headless (default):   python3 test_browser_tools.py
Watch it happen:          HARNESS_BROWSER_HEADED=1 python3 test_browser_tools.py
Slower, for demos:        HARNESS_BROWSER_HEADED=1 HARNESS_BROWSER_SLOWMO=700 \
                              python3 test_browser_tools.py

Exercises the Tools browser_* surface exactly the way the agent loop does
(getattr dispatch), against scripted pages served over HTTP. Headed mode needs a
display (WSLg on WSL2); it is for debugging only, never for study runs.

NOTE for headed runs: the crash-recovery check deliberately closes the page
mid-test, so one window disappearing near the end is expected, not a failure.
"""
import queue
import subprocess
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from harness.browser import browser_launch_config
from harness.conditions import CONDITIONS, CONDITION_BRIEFINGS, VISION_CONDITIONS, tools_for
from harness.tools import Tools, SCHEMAS

FAILURES = []
_CFG = browser_launch_config()
print(f"browser: {'HEADED (visible window)' if _CFG['headed'] else 'headless'}"
      f"  slow_mo={_CFG['slow_mo_ms']}ms"
      + (f"  exe={_CFG['executable_path']}" if _CFG["executable_path"] else ""))
if _CFG["headed"]:
    print("  (a window will open; the crash-recovery check closes it near the end "
          "on purpose)")


def check(name, cond, detail=""):
    tag = "ok " if cond else "FAIL"
    print(f"[{tag}] {name}" + (f"  -- {detail}" if detail and not cond else ""))
    if not cond:
        FAILURES.append((name, detail))


# ---------------------------------------------------------------- static checks
for cname, tool_list in CONDITIONS.items():
    for t in tool_list:
        check(f"schema exists: {cname}/{t}", t in SCHEMAS)
        check(f"Tools method exists: {cname}/{t}", callable(getattr(Tools, t, None)))
check("interactive registered", "interactive" in CONDITIONS)
check("interactive_screens registered", "interactive_screens" in CONDITIONS)
check("interactive briefing registered", "interactive" in CONDITION_BRIEFINGS)
check("interactive_screens briefing registered", "interactive_screens" in CONDITION_BRIEFINGS)
check("interactive NOT a vision condition", "interactive" not in VISION_CONDITIONS)
check("interactive_screens IS a vision condition", "interactive_screens" in VISION_CONDITIONS)
check("interactive = execution + browser tools",
      set(tools_for("interactive")) - set(tools_for("execution"))
      == {"browser_navigate", "browser_click", "browser_type", "browser_drag",
          "browser_read", "browser_wait",
          "browser_new_page", "browser_switch_page", "browser_close_page"})
check("interactive_screens = interactive + browser_screenshot",
      set(tools_for("interactive_screens")) - set(tools_for("interactive"))
      == {"browser_screenshot"})
check("briefings are descriptive (no 'you must')",
      all("you must" not in b.lower()
          for c, b in CONDITION_BRIEFINGS.items() if c.startswith("interactive")))

# ---------------------------------------------------------------- test app
APP = """<!doctype html><html><head><title>Test App</title></head><body>
<h1>Widget Board</h1>
<button id="inc">Increment</button> <span id="count">0</span>
<input id="new-item" placeholder="new item name">
<button id="add">Add item</button>
<ul id="list"></ul>
<ul id="empty-list"></ul>
<p class="multi">one</p><p class="multi">two</p>
<button id="prompt-btn">Add via prompt</button>
<button id="inert">Does nothing</button>
<a href="page2.html" id="go2">Second page</a>
<script>
  console.error("boot-time diagnostic error 123");
  document.getElementById('prompt-btn').onclick = () => {
    const v = prompt('Enter card text:');      // native dialog
    if (v) { const li = document.createElement('li'); li.textContent = v;
             document.getElementById('list').appendChild(li); }
  };
  document.getElementById('inert').onclick = () => { /* deliberately nothing */ };
  let n = 0;
  document.getElementById('inc').onclick = () => {
    n += 1; document.getElementById('count').textContent = String(n);
  };
  document.getElementById('add').onclick = () => {
    const v = document.getElementById('new-item').value.trim();
    if (!v) return;
    const li = document.createElement('li'); li.textContent = v;
    document.getElementById('list').appendChild(li);
    document.getElementById('new-item').value = '';
  };
</script></body></html>"""
PAGE2 = "<!doctype html><html><head><title>Page Two</title></head><body><h1>Second</h1></body></html>"

# Drag-and-drop test page covering BOTH web drag mechanisms in one document:
#   * top board  - HTML5 native DnD (draggable=true + dragstart/dragover/drop)
#   * lower board - a mouse-based library imitation with a realistic ACTIVATION
#     CONSTRAINT (needs >8px of travel AND >=3 distinct mousemove events), which is
#     what SortableJS / dnd-kit / react-beautiful-dnd style libraries impose and what
#     a naive single-jump drag fails to satisfy.
DND = """<!doctype html><html><head><title>Drag Test</title>
<style>ul{min-height:80px;width:200px;border:1px solid #999;display:inline-block;
vertical-align:top;margin:8px;padding:8px;list-style:none}
li{background:#eee;padding:8px;margin:4px;cursor:grab}</style></head><body>
<h1>Drag Board</h1>
<h2>HTML5</h2>
<ul id="col-a" class="col"><li id="card1" draggable="true">Card One</li></ul>
<ul id="col-b" class="col"></ul>
<p id="not-droppable">Not a drop zone</p>
<!-- An empty container with no min-height: the canonical kanban defect. It has a
     bounding box but no AREA, so nothing can be dropped on it. The diagnosis must
     blame the geometry, not the (perfectly good) listeners. -->
<ul id="col-collapsed" class="col" style="min-height:0;padding:0;border:0"></ul>
<!-- A drop zone with a SIBLING painted over it. The overlay is not a descendant, so
     dragover reaches the overlay and the requested target sees nothing. This needs the
     opposite fix to a missing handler, and the two used to read identically. -->
<div id="zone-wrap" style="position:relative;width:200px;height:80px">
  <ul id="drop-zone" class="col" style="position:absolute;inset:0;margin:0"></ul>
  <div id="overlay" style="position:absolute;inset:0;background:#ddd">overlay</div>
</div>
<h2>Mouse</h2>
<ul id="mcol-a" class="mcol"><li id="mcard1" class="mcard">Mouse Card</li></ul>
<ul id="mcol-b" class="mcol"></ul>
<script>
// ---- (a) HTML5 native drag and drop
document.querySelectorAll('[draggable=true]').forEach(el => {
  el.addEventListener('dragstart', e => e.dataTransfer.setData('text/plain', el.id));
});
document.querySelectorAll('.col').forEach(col => {
  col.addEventListener('dragover', e => e.preventDefault());
  col.addEventListener('drop', e => {
    e.preventDefault();
    const id = e.dataTransfer.getData('text/plain');
    if (id) col.appendChild(document.getElementById(id));
  });
});
// ---- (b) mouse-based drag with an activation constraint
let dragging = null, sx = 0, sy = 0, moves = 0, active = false;
document.querySelectorAll('.mcard').forEach(el => {
  el.addEventListener('mousedown', e => {
    dragging = el; sx = e.clientX; sy = e.clientY; moves = 0; active = false;
  });
});
document.addEventListener('mousemove', e => {
  if (!dragging) return;
  moves++;
  if (Math.hypot(e.clientX - sx, e.clientY - sy) > 8 && moves >= 3) active = true;
});
document.addEventListener('mouseup', e => {
  if (dragging && active) {
    const el = document.elementFromPoint(e.clientX, e.clientY);
    const col = el && el.closest('.mcol');
    if (col) col.appendChild(dragging);
  }
  dragging = null; active = false;
});
</script></body></html>"""

site = Path(tempfile.mkdtemp(prefix="browser_test_site_"))
(site / "index.html").write_text(APP)
(site / "page2.html").write_text(PAGE2)
(site / "dnd.html").write_text(DND)


def _free_port() -> int:
    """Bind port 0 and read back what the OS handed out, so repeated runs (or a
    harness run in another terminal) never collide on a fixed port."""
    import socket
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


PORT = _free_port()
server = subprocess.Popen([sys.executable, "-m", "http.server", str(PORT),
                           "--directory", str(site)],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)

# --------------------------------------------------------------- SSE test server
# A minimal broadcast server + page for the two-client check below. The page NEVER
# appends the message it just posted: anything that shows up in #feed arrived over
# EventSource. That is what makes the multi-client assertion meaningful.
SSE_PAGE = """<!doctype html><html><head><title>SSE</title></head><body>
<input id="msg"><ul id="feed"></ul>
<script>
new EventSource('/events').onmessage = (e) => {
  const li = document.createElement('li'); li.textContent = e.data;
  document.getElementById('feed').appendChild(li);
};
document.getElementById('msg').addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const v = e.target.value; e.target.value = '';
  fetch('/post', {method: 'POST', body: v});   // no optimistic append, on purpose
});
</script></body></html>"""

_subscribers: list = []
_sub_lock = threading.Lock()


class _SSEHandler(BaseHTTPRequestHandler):
    def log_message(self, *a):        # keep the test output clean
        pass

    def do_GET(self):
        if self.path.startswith("/events"):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            q = queue.Queue()
            with _sub_lock:
                _subscribers.append(q)
            try:
                self.wfile.write(b": connected\n\n")
                self.wfile.flush()
                deadline = time.time() + 90
                while time.time() < deadline:
                    try:
                        msg = q.get(timeout=1.0)
                    except queue.Empty:
                        continue
                    self.wfile.write(f"data: {msg}\n\n".encode())
                    self.wfile.flush()
            except Exception:                     # noqa: BLE001 - client went away
                pass
            finally:
                with _sub_lock:
                    if q in _subscribers:
                        _subscribers.remove(q)
            return
        body = SSE_PAGE.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        text = self.rfile.read(int(self.headers.get("Content-Length") or 0)).decode()
        with _sub_lock:
            for q in list(_subscribers):
                q.put(text)
        self.send_response(204)
        self.send_header("Content-Length", "0")
        self.end_headers()


SSE_PORT = _free_port()
sse_server = ThreadingHTTPServer(("127.0.0.1", SSE_PORT), _SSEHandler)
sse_server.daemon_threads = True
threading.Thread(target=sse_server.serve_forever, daemon=True).start()

ws = Path(tempfile.mkdtemp(prefix="browser_test_ws_"))
tools = Tools(workspace=ws)


def call(name, **args):
    """Dispatch exactly like agent.run_agent does."""
    fn = getattr(tools, name)
    return fn(**args)


try:
    # 1. read before navigate
    r = call("browser_read")
    check("read before navigate says no page", "no page loaded" in r.text, r.text[:120])

    # 2. navigate
    r = call("browser_navigate", url=f"http://localhost:{PORT}/index.html")
    check("navigate reports HTTP 200", "[HTTP 200]" in r.text, r.text[:200])
    check("navigate reports title", "Test App" in r.text, r.text[:200])
    check("navigate includes structure", "PAGE STRUCTURE:" in r.text, r.text[:200])
    check("navigate surfaces console.error",
          "boot-time diagnostic error 123" in r.text, r.text[:400])

    # 3. session persistence: two clicks accumulate state
    call("browser_click", selector="#inc")
    r = call("browser_click", selector="#inc")
    check("state persists across calls (count=2)", '"2"' in r.text or " 2" in r.text,
          r.text[:400])

    # 4. type + click adds a list item
    call("browser_type", selector="#new-item", text="alpha-widget")
    r = call("browser_click", selector="#add")
    check("typed item appears in list", "alpha-widget" in r.text, r.text[:600])

    # 5. text selector click navigates to page 2, then back
    r = call("browser_click", selector="text=Second page")
    check("text selector + navigation works", "Page Two" in r.text or "Second" in r.text,
          r.text[:300])
    r = call("browser_navigate", url=f"http://localhost:{PORT}/index.html")
    check("re-navigate ok (fresh page state expected)", "[HTTP 200]" in r.text)

    # 6. error paths return text, never raise
    r = call("browser_click", selector="#does-not-exist")
    check("bad click selector -> ERROR text", r.text.startswith("ERROR"), r.text[:150])
    check("bad click selector -> hint", "browser_read" in r.text, r.text[:300])
    r = call("browser_type", selector="#inc", text="x")   # button: not fillable
    check("type into non-fillable -> ERROR text", r.text.startswith("ERROR"), r.text[:150])
    r = call("browser_wait", ms=800, selector="#never-appears")
    check("wait for absent element -> ERROR text", r.text.startswith("ERROR"), r.text[:150])
    r = call("browser_wait", ms=300)
    check("plain wait ok", "Waited 300 ms" in r.text, r.text[:150])

    # 6b. DRAG AND DROP — both web mechanisms, asserted on OUTCOME (did the item
    #     actually move?) rather than on which code path ran, since either path is
    #     acceptable as long as the drop lands.
    DND_URL = f"http://localhost:{PORT}/dnd.html"

    call("browser_navigate", url=DND_URL)
    r = call("browser_drag", source="#card1", target="#col-b")
    print(f"       (html5 drag reported: {r.text.splitlines()[0][:90]})")
    check("HTML5 drag moved the card", "Card One" in call(
        "browser_read", selector="#col-b").text, r.text[:300])
    check("HTML5 drag reports the page changed", "did not change" not in r.text.lower(),
          r.text[:200])

    call("browser_navigate", url=DND_URL)          # reset the board
    r = call("browser_drag", source="#mcard1", target="#mcol-b")
    print(f"       (mouse drag reported: {r.text.splitlines()[0][:90]})")
    check("mouse-library drag moved the card (activation constraint satisfied)",
          "Mouse Card" in call("browser_read", selector="#mcol-b").text, r.text[:300])

    # drop onto something with no drop handler -> honest report AND a diagnosis that
    # names the cause (this is the real-run case: a kanban board whose columns had no
    # drop handlers, so cards could never land in an empty column).
    call("browser_navigate", url=DND_URL)
    r = call("browser_drag", source="#card1", target="#not-droppable")
    print(f"       (undroppable reported: {r.text.splitlines()[0][:150]})")
    check("undroppable target -> reports no change", "DID NOT change" in r.text,
          r.text[:250])
    check("undroppable target -> diagnosis names the missing dragover",
          "DIAGNOSIS" in r.text and "dragover" in r.text, r.text[:300])

    # a source that cannot start a drag at all -> a different, specific diagnosis
    call("browser_navigate", url=DND_URL)
    r = call("browser_drag", source="h1", target="#col-b")
    print(f"       (undraggable reported: {r.text.splitlines()[0][:150]})")
    check("undraggable source -> diagnosis mentions no drag started",
          "DIAGNOSIS" in r.text and ("mousedown" in r.text or "dragstart" in r.text
                                     or "nothing moved" in r.text), r.text[:300])

    # GEOMETRY, not listeners. A collapsed empty container has good handlers (it is a
    # .col) and zero area. The old wording blamed the listeners and sent a real model
    # off to rewrite handlers that were already correct.
    call("browser_navigate", url=DND_URL)
    r = call("browser_drag", source="#card1", target="#col-collapsed")
    print(f"       (collapsed target reported: {r.text.splitlines()[0][:170]})")
    check("collapsed target -> the measured size is reported",
          "pixels" in r.text and ("x0" in r.text or "0x" in r.text), r.text[:300])
    check("collapsed target -> does NOT blame the listeners",
          "listening" not in r.text.lower(), r.text[:300])

    # An intercepting child needs the OPPOSITE fix to a missing handler, so the two
    # must not produce the same sentence. Name what actually received the events.
    call("browser_navigate", url=DND_URL)
    r = call("browser_drag", source="#card1", target="#drop-zone")
    print(f"       (covered target reported: {r.text.splitlines()[0][:190]})")
    check("overlaid target -> names the element painted on top",
          "#overlay" in r.text and "on top of it" in r.text, r.text[:400])
    check("overlaid target -> also names the requested target",
          "#drop-zone" in r.text, r.text[:400])
    check("overlaid target -> does NOT claim nothing is listening",
          "nothing at the drop point" not in r.text
          and "listening" not in r.text.lower(), r.text[:400])
    check("overlaid target -> answers fast instead of timing out",
          "Timeout" not in r.text, r.text[:400])

    # A child inside the target is NOT an obstruction - a card list full of cards must
    # still be droppable, or this check would break every working board.
    call("browser_navigate", url=DND_URL)
    r = call("browser_drag", source="#card1", target="#col-a")
    check("a child of the target is not treated as an obstruction",
          "on top of it" not in r.text, r.text[:300])

    # a successful drag must NOT carry a diagnosis
    call("browser_navigate", url=DND_URL)
    r = call("browser_drag", source="#card1", target="#col-b")
    check("successful drag carries no DIAGNOSIS", "DIAGNOSIS" not in r.text,
          r.text[:200])

    # the probe must clean itself up (no listener/global left behind)
    leftover = call("browser_read")
    check("probe left no global behind", "__harnessDragProbe" not in leftover.text)

    # bad selectors are named precisely instead of failing as a silent no-op
    r = call("browser_drag", source="#nope", target="#col-b")
    check("bad source selector -> ERROR naming source",
          r.text.startswith("ERROR") and "source" in r.text, r.text[:150])
    r = call("browser_drag", source="#card1", target="#nope")
    check("bad target selector -> ERROR naming target",
          r.text.startswith("ERROR") and "target" in r.text, r.text[:150])

    call("browser_navigate", url=f"http://localhost:{PORT}/index.html")

    # 6c. FACTUAL-FEEDBACK PASS — each of these situations used to be reported
    #     identically to a situation that meant something completely different.
    call("browser_navigate", url=f"http://localhost:{PORT}/index.html")

    r = call("browser_click", selector="#inert")
    check("click that changes nothing says so",
          "nothing in the page's DOM changed" in r.text, r.text[:200])

    r = call("browser_click", selector="#inc")
    check("click that DOES change carries no such note",
          "nothing in the page's DOM changed" not in r.text, r.text[:200])

    r = call("browser_click", selector="#prompt-btn")
    check("native dialog is reported, not silently dismissed",
          "native browser dialog" in r.text and "Enter card text" in r.text,
          r.text[:300])
    r = call("browser_click", selector="#inc")
    check("dialog note is not repeated after being reported",
          "native browser dialog" not in r.text, r.text[:200])

    r = call("browser_read", selector="#no-such-thing")
    check("read: no match is named as no match", "matched NO elements" in r.text,
          r.text[:200])
    r = call("browser_read", selector="#empty-list")
    check("read: matched-but-empty is distinguished",
          "exists but is empty" in r.text, r.text[:200])
    call("browser_type", selector="#new-item", text="beta-widget")
    call("browser_click", selector="#add")
    r = call("browser_read", selector="#list")
    check("read: non-empty element carries no empty note",
          "beta-widget" in r.text and "exists but is empty" not in r.text,
          r.text[:200])
    r = call("browser_read", selector=".multi")
    check("read: multiple matches reports the count",
          "matched 2 elements" in r.text, r.text[:200])

    # 7. screenshot of the live session
    r = call("browser_screenshot")
    check("browser_screenshot returns image", r.image_b64 is not None and len(r.image_b64) > 1000)
    shots = list(ws.glob("browser_screenshot_*.png"))
    check("browser_screenshot saved to disk", len(shots) == 1,
          f"found {len(shots)}")

    # 8. dead server -> actionable error
    r = call("browser_navigate", url="http://localhost:59999/")
    check("dead server -> ERROR + hint", r.text.startswith("ERROR")
          and "HINT" in r.text, r.text[:250])

    # 9. MULTI-PAGE. The reason this exists: with one page, a capability defined across
    # simultaneous clients ("all connected clients receive updates instantly") is not
    # reachable by any tool, so it cannot be verified even in principle.
    call("browser_navigate", url=f"http://localhost:{PORT}/index.html")
    sess = tools._browser_session
    check("a single-page run reports one page", sess.page_count == 1,
          str(sess.page_count))
    r = call("browser_read")
    check("single-page feedback has NO pages line (unchanged from before)",
          "OPEN PAGES:" not in r.text, r.text[:200])

    r = call("browser_new_page", url=f"http://localhost:{PORT}/index.html")
    check("new_page opens a second page", sess.page_count == 2, str(sess.page_count))
    check("new_page navigates when given a url", "[HTTP 200]" in r.text, r.text[:250])
    check("new_page names the page it opened", "page-2" in r.text, r.text[:250])
    check("pages line appears once >1 page is open", "OPEN PAGES:" in r.text,
          r.text[:300])
    check("pages line marks the active page", "page-2 (active)" in r.text, r.text[:300])

    # State is per page: click on page-2 only, then confirm page-1 never saw it.
    call("browser_click", selector="#inc")
    call("browser_click", selector="#inc")
    r = call("browser_read", selector="#count")
    check("clicks land on the ACTIVE page", "2" in r.text, r.text[:200])

    r = call("browser_switch_page", page="page-1")
    check("switch_page switches", "Switched to page-1" in r.text, r.text[:200])
    check("switch_page marks the new active page", "page-1 (active)" in r.text,
          r.text[:300])
    r = call("browser_read", selector="#count")
    check("the OTHER page kept its own DOM state (still 0, not 2)",
          '"0"' in r.text and '"2"' not in r.text, r.text[:250])

    # Typed state is per page too, and survives switching away and back.
    call("browser_type", selector="#new-item", text="page-one-item")
    call("browser_click", selector="#add")
    call("browser_switch_page", page="page-2")
    r = call("browser_read", selector="#list")
    check("the second page did not receive the first page's item",
          "page-one-item" not in r.text, r.text[:250])
    call("browser_switch_page", page="page-1")
    r = call("browser_read", selector="#list")
    check("switching back finds the earlier page's state intact",
          "page-one-item" in r.text, r.text[:250])

    # Labels: models are inconsistent, so bare ints and 'page 2' must resolve too.
    check("switch accepts a bare number", "page-2 (active)" in
          call("browser_switch_page", page="2").text)
    check("switch accepts 'page 1' with a space", "page-1 (active)" in
          call("browser_switch_page", page="page 1").text)
    r = call("browser_switch_page", page="page-9")
    check("switching to a page that does not exist is an actionable ERROR",
          r.text.startswith("ERROR") and "page-1" in r.text and "page-2" in r.text,
          r.text[:250])

    r = call("browser_close_page", page="page-2")
    check("close_page closes the named page", sess.page_count == 1, str(sess.page_count))
    check("close_page names the new active page", "page-1 is now the active page"
          in r.text, r.text[:250])
    r = call("browser_read")
    check("pages line disappears when only one page is left",
          "OPEN PAGES:" not in r.text, r.text[:200])
    check("closing pages is not counted as instability",
          sess.page_restart_count == 0 and sess.restart_count == 0,
          f"page={sess.page_restart_count} browser={sess.restart_count}")
    check("labels are never reused",
          "page-3" in call("browser_new_page").text)
    call("browser_close_page")            # no argument -> closes the active page
    check("close_page with no argument closes the active one", sess.page_count == 1,
          str(sess.page_count))

    # 9b. page-level crash: the page dies, the browser does not.
    sess._page.close()
    r = call("browser_navigate", url=f"http://localhost:{PORT}/index.html")
    check("dead page -> replaced with a visible NOTE",
          "had closed" in r.text and "[HTTP 200]" in r.text, r.text[:350])
    check("dead page counted as a PAGE restart, not a browser restart",
          sess.page_restart_count == 1 and sess.restart_count == 0,
          f"page={sess.page_restart_count} browser={sess.restart_count}")

    # 9c. browser-level crash: everything is gone, and the note says so.
    sess._browser.close()
    r = call("browser_navigate", url=f"http://localhost:{PORT}/index.html")
    check("dead browser -> fresh session with visible NOTE",
          "fresh browser session" in r.text and "[HTTP 200]" in r.text, r.text[:300])
    check("restart_count incremented", sess.restart_count == 1,
          str(sess.restart_count))
    check("a fresh session starts from one page", sess.page_count == 1,
          str(sess.page_count))

    # 10. THE CASE THIS FEATURE EXISTS FOR: a real two-client SSE check.
    # The app deliberately does NOT append optimistically — a message can only reach
    # the DOM by arriving over the other client's EventSource. Before multi-page there
    # was no sequence of tool calls that could establish this at all.
    call("browser_navigate", url=f"http://localhost:{SSE_PORT}/")
    call("browser_new_page", url=f"http://localhost:{SSE_PORT}/")
    check("two SSE clients open", sess.page_count == 2, str(sess.page_count))
    call("browser_wait", ms=1000)                 # let both EventSources connect

    call("browser_type", selector="#msg", text="hello-from-page-2", press_enter=True)
    r = call("browser_read", selector="#feed")
    check("the posting client sees the message", "hello-from-page-2" in r.text,
          r.text[:250])

    switch_label = [l for l in sess._pages if l != sess._active][0]
    call("browser_switch_page", page=switch_label)
    call("browser_wait", ms=1000)
    r = call("browser_read", selector="#feed")
    check("THE OTHER CLIENT received it over SSE (unverifiable before multi-page)",
          "hello-from-page-2" in r.text, r.text[:300])

    # And the reverse direction, so the check cannot pass by both pages sharing a DOM.
    call("browser_type", selector="#msg", text="reply-from-the-other-one",
         press_enter=True)
    call("browser_switch_page", page=sess._pages and
         [l for l in sess._pages if l != sess._active][0])
    call("browser_wait", ms=1000)
    r = call("browser_read", selector="#feed")
    check("broadcast reaches the first client too",
          "reply-from-the-other-one" in r.text, r.text[:300])

    # 11. output bounded
    check("feedback bounded (<6000 chars)", all(len(x) < 6000 for x in [r.text]))
finally:
    tools.teardown()
    server.terminate()
    sse_server.shutdown()

check("teardown cleared session", tools._browser_session is None)

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILURE(S):")
    for n, d in FAILURES:
        print(f"  - {n}: {d}")
    sys.exit(1)
print("ALL CHECKS PASSED")
