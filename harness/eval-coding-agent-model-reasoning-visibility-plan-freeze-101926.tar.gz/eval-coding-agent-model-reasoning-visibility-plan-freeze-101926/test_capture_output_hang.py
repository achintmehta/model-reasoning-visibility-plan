"""A command whose child leaves the process group can no longer hang the shell tools
(plan 42 v2.5.40).

The smoke of 2026-10-07 hung, twice, on one run_command_and_capture_output call:
    timeout 3 bash -c '(curl -s -N <sse stream> > f &); sleep 1; ...; cat f' 2>&1
GNU `timeout` moves itself and its children to a process group of their own, so the
backgrounded curl survived the tool's group kill with the tool's stderr pipe still open, and
the tool then waited for EOF forever. The tools now kill the command's whole SESSION and
never wait on the pipes unboundedly. `sleep` stands in for the never-ending curl.
"""
import os
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness.tools import Tools  # noqa: E402

FAILS = []


def check(cond, msg):
    print(("ok   " if cond else "FAIL ") + msg)
    if not cond:
        FAILS.append(msg)


def alive(tag):
    out = subprocess.run(["ps", "-eo", "pid,args"], capture_output=True, text=True).stdout
    return [int(l.split()[0]) for l in out.splitlines()
            if tag in l and "ps -eo" not in l and "bash -c" not in l]


def cleanup(tag):
    for pid in alive(tag):
        try:
            os.kill(pid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass


ws = Path(tempfile.mkdtemp())
t = Tools(workspace=ws, test_cmd=None, screenshot_dir=ws)

# 1. the exact shape that hung: a detached child under `timeout`, holding stderr
t0 = time.time()
r = t.run_command_and_capture_output(
    "timeout 3 bash -c '(sleep 4141 > /dev/null &); sleep 1; echo sampled' 2>&1", 2)
took = time.time() - t0
check(took < 15, f"capture_output returns although a child under `timeout` holds its pipe ({took:.1f}s)")
check("timed out after 2s" in r.text, "and reports the time limit")
time.sleep(0.5)
check(not alive("sleep 4141"), "the child that left the process group was killed (session kill)")
cleanup("sleep 4141")

# 2. the same shape through run_command, at a short timeout
t.cmd_timeout = 3
t0 = time.time()
r = t._run("timeout 30 bash -c '(sleep 4242 > /dev/null &); sleep 20'")
took = time.time() - t0
check(took < 15, f"run_command returns at its timeout ({took:.1f}s)")
time.sleep(0.5)
check(not alive("sleep 4242"), "and kills the child outside the group too")
cleanup("sleep 4242")

# 3. ordinary sampling still works and keeps its output
r = t.run_command_and_capture_output("echo one; sleep 30", 2)
check("timed out after 2s" in r.text and "one" in r.text,
      "a stream sampled for 2s still returns what it printed")
r = t.run_command_and_capture_output("echo done; exit 4", 5)
check("[exit 4]" in r.text and "done" in r.text, "a command that exits is reported as before")

# 4. a child that left the SESSION (setsid) cannot hang the call either
t0 = time.time()
r = t.run_command_and_capture_output("setsid sleep 4343 & sleep 10", 2)
check(time.time() - t0 < 15, "a child in its own session cannot hang the call")
cleanup("sleep 4343")

# 5. teardown kills a background command's escaped children
t2 = Tools(workspace=ws, test_cmd=None, screenshot_dir=ws)
t2.run_background_command("timeout 600 bash -c '(sleep 4444 > /dev/null &); sleep 600'")
time.sleep(1.5)
t2.teardown()
time.sleep(0.5)
check(not alive("sleep 4444"), "teardown leaves nothing of a background command running")
cleanup("sleep 4444")

print("\nALL CHECKS PASSED" if not FAILS else f"\n{len(FAILS)} CHECK(S) FAILED")
sys.exit(1 if FAILS else 0)
