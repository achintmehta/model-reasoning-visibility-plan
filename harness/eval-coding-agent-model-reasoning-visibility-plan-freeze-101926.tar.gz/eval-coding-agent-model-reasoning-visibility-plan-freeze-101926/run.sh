#!/usr/bin/env bash
set -euo pipefail

# ============================================================
#  Eval harness runner — single run
#
#  Usage:
#     ./run.sh <task> <condition> <model> <run>
#  e.g.
#     ./run.sh message-board execution openai/gpt-5.5 4
#     ./run.sh calendar-week-view visual_no_shell qwen2.5-vl-72b-instruct 1
#     ./run.sh kanban-labels-brownfield execution anthropic/claude-sonnet-4.6 2
#
#  ONE spec per task: pass the bare task name for every condition.
#  (Per-condition spec variants like -blind / -playwright are retired;
#  condition-specific orientation is injected by the harness as a
#  registered briefing — or omitted entirely, see NO_BRIEFING below.)
#
#  Env overrides:
#     OPENROUTER_API_KEY   required for namespaced models (openai/..., anthropic/...)
#     BRIEFING_MODE        universal (default): one briefing byte-identical in every
#                          condition - the whole prompt is constant; only the tool
#                          schemas differ. per_condition: registered per-condition
#                          descriptions. none: ablation arm (no briefing).
#     INTERACTIVE=1        human-in-the-loop debugging. NEVER for study runs — the run
#                          is flagged as contaminated in its manifest.
#     MAX_TOTAL_TOKENS     per-run token budget (default 3000000)
#     OUTPUT_ROOT          run output tree (default /tmp/runs/final-runs)
#     QUANT                OPTIONAL label for the precision this model is served at
#                          (e.g. Q4_K_M, Q8_0, BF16). Recorded in manifest.json as
#                          `quantization` and nothing else — it does not change the
#                          run, the prompt, or the tools. Exists so a precision ladder
#                          groups in analysis without anyone parsing model ids, which
#                          are an unreliable place to keep this (LM Studio bakes the
#                          quant in as name@q5_k_m, llama-server reports whatever
#                          --alias says, OpenRouter reports nothing). Set it per rung:
#                             QUANT=Q4_K_M ./run.sh kanban-board execution gemma-4-31b 1
#                          Use ONE spelling across a whole ladder; nothing normalizes it.
#     THINK_PREAMBLE       OPTIONAL key of a registered thinking preamble appended to the
#                          system prompt (harness.agent.THINK_PREAMBLES: mistral,
#                          mistral-min, or none). Needed only by models whose thinking is
#                          driven by the system prompt rather than by a chat-template
#                          switch — Magistral. A TREATMENT setting; recorded per run.
#                            THINK_PREAMBLE=mistral ./run.sh ...
#     EXTRA_BODY           OPTIONAL JSON object (or @path) merged into every request, for
#                          fields the OpenAI schema has no slot for: chat_template_kwargs
#                          (thinking on/off for Qwen3/Gemma), and llama.cpp samplers the
#                          schema omits — top_k, min_p, repeat_penalty — which otherwise
#                          fall through to the GGUF's own general.sampling.* metadata
#                          unrecorded. A TREATMENT, recorded verbatim in manifest.json.
#                            EXTRA_BODY='{"top_k":1}' ./run.sh ...
#     REPLAY_REASONING     1 to send the model's reasoning_content back with the assistant
#                          turn that produced it, 0 to discard it. Unset = harness default
#                          (ON since 2026-08-13). This is a TREATMENT, not plumbing: it
#                          changes what the model sees on every subsequent step. Verify
#                          the server accepts it with tools/probe_reasoning_replay.py
#                          before a batch — llama.cpp has a live bug rendering an
#                          assistant message that carries reasoning AND tool calls.
#     QUANT_REGISTRY       OPTIONAL path to quant-registry.json (publisher, method,
#                          imatrix, file path, sha256 per rung). Defaults to
#                          ./quant-registry.json when present, so normally unset. The
#                          matching entry lands in manifest.json as
#                          `quantization_detail`, which is what makes "Q8 behaved
#                          differently from Q5_K_M" separable from "that particular
#                          build behaved differently". Fill it with
#                          tools/hash_quants.py, which reads each GGUF's own header.
# ============================================================

TASK="${1:-message-board}"
CONDITION="${2:-execution}"
MODEL="${3:-openai/gpt-5.5}"
RUN="${4:-1}"

# ---- Conditions (must match harness/conditions.py) ---------
case "$CONDITION" in
  no_verification|static|boot_check|execution|visual|visual_no_shell|delayed_verification|behavioral|interactive|interactive_screens) ;;
  none|self_built|blind)
    echo "Condition '$CONDITION' was retired/renamed (none|blind -> no_verification, self_built -> execution)." >&2
    exit 1 ;;
  *)
    echo "Unknown condition: '$CONDITION'" >&2
    echo "Choices: no_verification static boot_check execution visual visual_no_shell delayed_verification behavioral interactive interactive_screens" >&2
    exit 1 ;;
esac

# ---- Fixed paths / knobs ------------------------------------
OUTPUT_ROOT="${OUTPUT_ROOT:-/tmp/runs/final-runs}"
MAX_STEPS="${MAX_STEPS:-10000}"
MAX_TOTAL_TOKENS="${MAX_TOTAL_TOKENS:-6000000}"
# Stuck-loop guards forwarded to harness.agent. Defaults preserve historical behavior;
# raise MAX_CYCLE_REPEATS / MAX_SAME_CALLS to let a model loop more before the run is
# aborted as stuck_looping (set MAX_CYCLE_REPEATS below 2 to disable period-2 detection).
MAX_SAME_CALLS="${MAX_SAME_CALLS:-3}"
MAX_CYCLE_REPEATS="${MAX_CYCLE_REPEATS:-3}"
MAX_BLOCKED_CALLS="${MAX_BLOCKED_CALLS:-3}"
# No-progress guard (2026-08): abort after N consecutive steps in which every tool call
# merely repeats one already made earlier in the run. Catches loops that rotate among
# near-identical variants, which the two order-based guards above cannot see. Set 0 to
# restore pre-2026-08 behavior.
MAX_REPEAT_STEPS="${MAX_REPEAT_STEPS:-6}"
BRIEFING_MODE="${BRIEFING_MODE:-universal}"
INTERACTIVE="${INTERACTIVE:-0}"
QUANT="${QUANT:-}"
QUANT_REGISTRY="${QUANT_REGISTRY:-}"
# Empty = harness default (replay ON since 2026-08-13). Set to 0 for the off arm.
REPLAY_REASONING="${REPLAY_REASONING:-}"
EXTRA_BODY="${EXTRA_BODY:-}"
THINK_PREAMBLE="${THINK_PREAMBLE:-}"
REPLAY_FORMAT="${REPLAY_FORMAT:-}"
LOCAL_BASE_URL="${LOCAL_BASE_URL:-http://172.18.192.1:1234/v1}"

DECODING_FLAGS=()

# ---- Pre-flight: conflicting node processes / ports ---------
# Detect leftover dev servers from a previous run and clear them before starting, instead
# of running on top of them. Strategy:
#   1. AUTO-KILL: try to terminate the conflicting PIDs ourselves (SIGTERM, then SIGKILL),
#      re-checking after each attempt. These are normally servers our own harness spawned,
#      so we can usually reap them. Up to KILL_ATTEMPTS (default 5) rounds.
#   2. FALL BACK to the human: if they survive all auto-kill rounds (e.g. owned by another
#      user, or unkillable), stop auto-killing and ask the user to terminate them and press
#      Enter, RE-CHECKING each time; we never continue until nothing conflicts.
# All prompt I/O goes to /dev/tty directly, so it works when run.sh is launched from
# run_batch.sh (whose stdout may be piped to tee or redirected to a log). With no terminal
# at all, we poll every 10s so an unattended batch still proceeds once cleared.
KILL_ATTEMPTS="${KILL_ATTEMPTS:-5}"

detect_conflicts() {
  ( pgrep -f "\bnode\b" || true; pgrep -f "\bnpm\b" || true; \
    ss -lptn 'sport = :3000 or sport = :5173 or sport = :5174 or sport = :5175' 2>/dev/null \
      | grep -oP 'pid=\K\d+' || true ) | { grep -v '^$' || true; } | sort -u
}

echo "Checking for existing node processes or bound ports (3000, 5173-5175)..."
kill_round=0
while :; do
  CONFLICTING_PIDS="$(detect_conflicts)"
  [ -z "$CONFLICTING_PIDS" ] && break
  PID_LIST="$(echo "$CONFLICTING_PIDS" | tr '\n' ' ')"

  if [ "$kill_round" -lt "$KILL_ATTEMPTS" ]; then
    kill_round=$(( kill_round + 1 ))
    # SIGTERM for the first two rounds (let servers shut down cleanly), SIGKILL after.
    if [ "$kill_round" -le 2 ]; then sig=TERM; else sig=KILL; fi
    echo "Conflicting pids: ${PID_LIST}-- auto-kill attempt ${kill_round}/${KILL_ATTEMPTS} (SIG${sig})"
    kill -s "$sig" $CONFLICTING_PIDS 2>/dev/null || true
    sleep 2   # give them a moment to exit before the next re-check
    continue
  fi

  # Auto-kill exhausted — hand off to the user, re-checking after each Enter.
  if [ -e /dev/tty ]; then
    {
      echo "WARNING: could not kill these after ${KILL_ATTEMPTS} attempts (need manual action):"
      ps -f -p $PID_LIST 2>/dev/null || true
      printf '%s' "Terminate them, then press Enter to RE-CHECK (will not start until they are gone; Ctrl+C to abort)... "
    } >/dev/tty
    read -r </dev/tty || { echo "(terminal closed; aborting)"; exit 1; }
  else
    echo "WARNING: ${KILL_ATTEMPTS} auto-kill attempts failed and no terminal to prompt; re-checking in 10s..."
    sleep 10
  fi
done
echo "No conflicting node/npm processes — continuing."

# ---- Endpoint from model name -------------------------------
# Routing by model-name shape:
#   local/<model>     -> local LM Studio, prefix stripped (use when the LOCAL model's
#                        own id contains a slash, e.g. local/google/gemma-4-31b)
#   <vendor>/<model>  -> OpenRouter
#   <bare-name>       -> local LM Studio
#
# WHY local/ EXISTS. Inferring "remote" from a slash breaks the moment a LOCAL server
# namespaces its ids — LM Studio lists google/gemma-4-31b, and passing that name routed
# the run to OpenRouter and demanded an API key. The bare suffix still works (the
# harness preflight matches on the final path segment, exactly as LM Studio does), so
# this prefix is only needed when a local id is genuinely ambiguous or has no usable
# short form.
case "$MODEL" in
  local/*)
    BASE_URL="$LOCAL_BASE_URL"
    API_KEY="lm-studio"
    MODEL="${MODEL#local/}"   # strip the routing prefix; send the server its real id
    ;;
  */*)
    BASE_URL="https://openrouter.ai/api/v1"
    API_KEY="${OPENROUTER_API_KEY:?Set OPENROUTER_API_KEY in your shell (the key is no longer embedded in this script)}"
    ;;
  *)
    BASE_URL="$LOCAL_BASE_URL"
    API_KEY="lm-studio"
    ;;
esac

# ---- Per-run directory tree (single tree; condition lives in dir name) ----
RUN_BASE="${OUTPUT_ROOT}/${TASK}/${CONDITION}/runs/${RUN}"
WORKSPACE="${RUN_BASE}/app/"
RUN_DIR="${RUN_BASE}/smoke/logs/"
SCREENSHOT_DIR="${RUN_BASE}/smoke/screenshot"

# ---- Optional flags -----------------------------------------
EXTRA_FLAGS=(--verbose --clean-workspace)
EXTRA_FLAGS+=(--briefing-mode "$BRIEFING_MODE")
if [ "$INTERACTIVE" = "1" ]; then
  echo "WARNING: interactive mode — this run will be flagged human-contaminated."
  EXTRA_FLAGS+=(--interactive)
fi
# Brownfield tasks start from the shipped starter codebase.
if [ "$TASK" = "kanban-labels-brownfield" ]; then
  EXTRA_FLAGS+=(--seed-workspace "tasks/brownfield-starter")
fi
# Optional precision label (see QUANT above). Appended BEFORE the "$@:5" passthrough so
# an explicit --quantization on the command line still wins, per the argparse
# last-occurrence rule the passthrough already relies on.
if [ -n "$QUANT" ]; then
  EXTRA_FLAGS+=(--quantization "$QUANT")
fi
# Only forwarded when set; with it unset the harness looks for ./quant-registry.json
# itself, so the normal case needs no env var.
if [ -n "$QUANT_REGISTRY" ]; then
  EXTRA_FLAGS+=(--quant-registry "$QUANT_REGISTRY")
fi
# Reasoning replay is a TREATMENT. Left unset the harness default applies; set
# REPLAY_REASONING=0 for the off arm. Either way the run records which it was, so a
# batch that accidentally mixes the two is detectable rather than silently pooled.
case "$REPLAY_REASONING" in
  0|off|false|no)  EXTRA_FLAGS+=(--no-replay-reasoning) ;;
  1|on|true|yes)   EXTRA_FLAGS+=(--replay-reasoning) ;;
  "")              ;;   # harness default
  *) echo "REPLAY_REASONING must be 0/1 (or off/on), got '$REPLAY_REASONING'" >&2; exit 1 ;;
esac
# Non-schema request fields (JSON object, or @path). Also a TREATMENT — see the harness's
# --extra-body help. Quote it in the shell: it contains braces and quotes.
if [ -n "$EXTRA_BODY" ]; then
  EXTRA_FLAGS+=(--extra-body "$EXTRA_BODY")
fi
# A registered thinking preamble (harness.agent.THINK_PREAMBLES), for models whose
# reasoning is driven by the SYSTEM PROMPT and not by a chat-template switch: our own
# system prompt displaces the template's reasoning instructions, so those models never
# think and the replayed/discarded arms collapse into one condition. A TREATMENT; the key
# and its hash are recorded per run. Only registry keys are accepted, never free text.
if [ -n "$THINK_PREAMBLE" ]; then
  EXTRA_FLAGS+=(--think-preamble "$THINK_PREAMBLE")
fi
# How a replayed thought is carried back: a separate reasoning_content field, or inline in
# the reply as [THINK]…[/THINK] for a family whose template has no field for it. A
# TREATMENT; recorded per run as replay_format.
if [ -n "$REPLAY_FORMAT" ]; then
  EXTRA_FLAGS+=(--replay-format "$REPLAY_FORMAT")
fi
# Forward any args after the 4 positionals straight to harness.agent, so e.g.
#   ./run.sh <task> <cond> <model> <run> --max-same-calls 10 --max-cycle-repeats 6
# works. These come LAST, so they override the defaults set above (argparse keeps the
# last occurrence). MAX_SAME_CALLS / MAX_CYCLE_REPEATS env vars still work too.
if [ "$#" -gt 4 ]; then
  EXTRA_FLAGS+=("${@:5}")
fi

# ---- Run ----------------------------------------------------
echo "task=${TASK}  condition=${CONDITION}  model=${MODEL}  run=${RUN}"
echo "base_url=${BASE_URL}  briefing_mode=${BRIEFING_MODE}  token_budget=${MAX_TOTAL_TOKENS}"
# Printed only when declared. NOTE: written as a full `if`, not `[ -n "$QUANT" ] && echo`,
# because under `set -e` a false &&-list at statement level aborts the script.
if [ -n "$QUANT" ]; then
  echo "quantization=${QUANT}"
fi
echo "run_base=${RUN_BASE}"
echo

echo "Creating RUN_DIR: ${RUN_DIR}"
mkdir -p "$RUN_DIR"

PYTHONUNBUFFERED=1 python3 -m harness.agent \
  --task-file "tasks/${TASK}" \
  --condition "$CONDITION" \
  --workspace "$WORKSPACE" \
  --run-dir "$RUN_DIR" \
  --model "$MODEL" \
  --api-key "$API_KEY" \
  --max-steps "$MAX_STEPS" \
  --max-total-tokens "$MAX_TOTAL_TOKENS" \
  --max-same-calls "$MAX_SAME_CALLS" \
  --max-cycle-repeats "$MAX_CYCLE_REPEATS" \
  --max-blocked-calls "$MAX_BLOCKED_CALLS" \
  --max-repeat-steps "$MAX_REPEAT_STEPS" \
  --base-url "$BASE_URL" \
  --screenshot-dir "$SCREENSHOT_DIR" \
  ${DECODING_FLAGS[@]+"${DECODING_FLAGS[@]}"} \
  "${EXTRA_FLAGS[@]}" 2>&1 | tee "$RUN_DIR/console.log"
