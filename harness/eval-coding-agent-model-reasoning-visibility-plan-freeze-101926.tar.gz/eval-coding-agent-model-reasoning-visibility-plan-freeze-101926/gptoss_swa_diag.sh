#!/usr/bin/env bash
# gptoss_swa_diag.sh -- plan v2.5.24 diagnostic: gpt-oss-20b's unparseable-output rate with
# --swa-full, on a NEW replicate, with BOTH arms on BOTH tasks (the smoke's schedule gives
# gpt-oss UNSEEN only on message-board and SEEN only on kanban, so it cannot tell arm from task).
#
#   ./gptoss_swa_diag.sh                      # 12 runs: 2 tasks x 3 conditions x 2 arms, replicate 02
#   REP=03 ./gptoss_swa_diag.sh               # another replicate (seed 3)
#   NO_SWA_FULL=1 ROOT=/tmp/runs/gptoss-noswa-diag ./gptoss_swa_diag.sh   # control, without the flag
#   (plan v2.5.26 moved --swa-full into the frozen flags for every model; before that the
#   control was NO_MODEL_SERVER_FLAGS=1)
#
# ONE attempt per run, no retries: the question is the per-attempt rate, and a retry here would
# only add attempts. Re-running the script skips runs that already have a manifest. Check the
# set afterwards with
#   python3 /mnt/d/thinking_research_runs/verify_smokes.py "$ROOT"
# whose "every attempt" table and G14 give the rate per arm, and whose G17 confirms the flag.
# These runs are diagnostics: they never enter the grid or its analysis.
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUNNER="$SCRIPT_DIR/run_one_with_server.sh"
ROOT="${ROOT:-/tmp/runs/gptoss-swa-diag}"
REP="${REP:-02}"
MODEL=gptoss-20b
case "$REP" in [0-9][0-9]) ;; *) echo "REP must be two digits (got '$REP')" >&2; exit 2 ;; esac
[ "$REP" = 01 ] && { echo "REP=01 is the smoke's replicate; use another" >&2; exit 2; }
n=0; ok=0; bad=0
for task in message-board kanban-board; do
  for cond in no_verification execution interactive; do
    for arm in unseen seen; do
      d=2; [ "$arm" = seen ] && d=3
      id="$d$REP"; n=$((n+1))
      man="$ROOT/$MODEL/$task/$cond/runs/$id/smoke/logs/manifest.json"
      if [ -f "$man" ]; then echo "[$n/12] $task/$cond/$arm ($id): already made, skipped"; continue; fi
      echo "[$n/12] $task/$cond/$arm ($id)"
      ARM="$arm" BLIND=0 OUTPUT_ROOT="$ROOT/$MODEL" "$RUNNER" "$MODEL" "$task" "$cond" "$id" </dev/null
      if [ $? -eq 0 ]; then ok=$((ok+1)); else bad=$((bad+1)); echo "  -> runner exited non-zero (kept, not retried)"; fi
    done
  done
done
echo "done: $ok exited 0, $bad non-zero, under $ROOT/$MODEL"
