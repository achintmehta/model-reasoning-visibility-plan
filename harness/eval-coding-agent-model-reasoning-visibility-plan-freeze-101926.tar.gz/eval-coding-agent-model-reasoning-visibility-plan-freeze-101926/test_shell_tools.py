"""Verification of the shell/file tools' factual-feedback behavior.

Run:  python3 test_shell_tools.py

Covers the non-browser half of the 2026-08 factual-feedback pass: situations where
a tool used to report success (or a bare failure) for something that had in fact not
happened, or had happened for a reason the model could not see. Each check pins one
piece of behavior that a real run showed a model burning steps on.

No model, no network, no browser - just Tools against a temp workspace.
"""
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from harness.tools import Tools

FAILURES = []


def check(name, cond, detail=""):
    print(f"[{'ok ' if cond else 'FAIL'}] {name}" + (f"  -- {detail}" if not cond else ""))
    if not cond:
        FAILURES.append(name)


ws = Path(tempfile.mkdtemp(prefix="shell_test_ws_"))
t = Tools(workspace=ws, cmd_timeout=5)

try:
    # --- edit_file no-op detection ------------------------------------------------
    t.write_file(path="a.txt", content="hello world")
    r = t.edit_file(path="a.txt", old_str="hello", new_str="hello")
    check("identical old_str/new_str reports no edit applied",
          "identical" in r.text and "unchanged" in r.text, r.text[:150])
    check("no-op edit does not claim 'edited'", not r.text.startswith("edited"),
          r.text[:150])

    r = t.edit_file(path="a.txt", old_str="hello", new_str="goodbye")
    check("real edit still reports edited", r.text.startswith("edited"), r.text[:150])
    check("real edit actually changed the file",
          (ws / "a.txt").read_text() == "goodbye world")

    # existing guards must be untouched
    check("missing old_str still errors",
          t.edit_file(path="a.txt", old_str="zzz", new_str="x").text.startswith("ERROR"))
    t.write_file(path="dup.txt", content="xx")
    check("ambiguous old_str still errors",
          "matches 2 times" in t.edit_file(path="dup.txt", old_str="x",
                                           new_str="y").text)

    # --- write_file no-op detection ------------------------------------------------
    # Same rule as edit_file's, applied to the tool that was missing it. Pilot runs
    # showed a model rewriting byte-identical content up to six times while the tool
    # answered "wrote N chars" every time — a success message for an operation that
    # moved nothing, and the only thing in the model's context after the write.
    r = t.write_file(path="noop.txt", content="same bytes")
    check("first write of a new file carries no unchanged note",
          "unchanged" not in r.text, r.text[:150])
    r = t.write_file(path="noop.txt", content="same bytes")
    check("rewriting identical bytes reports the file is unchanged",
          "already contained exactly these bytes" in r.text and "unchanged" in r.text,
          r.text[:200])
    check("no-op write still reports the write itself",
          r.text.startswith("wrote 10 chars to noop.txt"), r.text[:200])
    r = t.write_file(path="noop.txt", content="different bytes")
    check("a genuine change carries no unchanged note",
          "unchanged" not in r.text, r.text[:150])
    check("no-op write still leaves correct content on disk",
          (ws / "noop.txt").read_text() == "different bytes")
    # The note is about bytes, not about the call: writing the same content to a
    # DIFFERENT path is a real change and must not be flagged.
    t.write_file(path="other.txt", content="different bytes")
    r = t.write_file(path="yet-another.txt", content="different bytes")
    check("identical content at a new path is not called unchanged",
          "unchanged" not in r.text, r.text[:150])
    # Binary/undecodable existing content must not crash the comparison.
    (ws / "bin.dat").write_bytes(b"\xff\xfe\x00\x01")
    r = t.write_file(path="bin.dat", content="now text")
    check("undecodable existing file does not break write_file",
          r.text.startswith("wrote 8 chars"), r.text[:150])

    # --- stale-process note -------------------------------------------------------
    r = t.write_file(path="b.txt", content="no servers running yet")
    check("no note when nothing is running in the background",
          "still running" not in r.text, r.text[:150])

    t.write_file(path="server.js",
                 content="require('http').createServer((q,s)=>s.end('v1'))"
                         ".listen(8813);")
    start = t.run_background_command(command="node server.js")
    check("background server started for the test", "started with PID" in start.text,
          start.text[:200])
    time.sleep(1.0)

    r = t.write_file(path="server.js",
                     content="require('http').createServer((q,s)=>s.end('v2'))"
                             ".listen(8813);")
    check("write_file names the stale background process",
          "still running" in r.text and "restarted" in r.text, r.text[:300])
    check("stale note includes the PID and command",
          "PID" in r.text and "node server.js" in r.text, r.text[:300])

    r = t.edit_file(path="server.js", old_str="v2", new_str="v3")
    check("edit_file carries the same note", "still running" in r.text, r.text[:300])

    # --- run_command timeout note -------------------------------------------------
    r = t.run_command(command="sleep 30")
    check("timeout is still reported as an error", r.text.startswith("ERROR"),
          r.text[:120])
    check("timeout explains the tool waits for exit",
          "waits for a command to EXIT" in r.text, r.text[:400])
    check("timeout points at the right alternatives",
          "run_background_command" in r.text
          and "run_command_and_capture_output" in r.text, r.text[:400])

    r = t.run_command(command="echo fine")
    check("normal command carries no timeout note",
          "waits for a command to EXIT" not in r.text, r.text[:150])

    # --- background liveness: the report must match reality ------------------------
    # A killed server used to keep answering the liveness probe forever: nothing reaped
    # the child, the zombie held its process group open, and os.killpg(pid, 0) succeeded.
    # run_background_command then refused to restart it, so the model's only remaining
    # move was another `kill -9` - a loop observed to burn ~40 steps of a real run.
    t.write_file(path="srv.js",
                 content="require('http').createServer((q,s)=>s.end('ok')).listen(8823);")
    r = t.run_background_command(command="node srv.js")
    check("background server reports its listening port",
          "Listening on port(s): 8823" in r.text, r.text[:250])
    pid = int(r.text.split("PID ")[1].split(".")[0])

    check("port probe works without iproute2 (returns a list, not None)",
          t._listening_ports_of_group(pid) == [8823],
          repr(t._listening_ports_of_group(pid)))

    r = t.run_background_command(command="node srv.js")
    check("duplicate of a LISTENING server names the port as evidence",
          "already running" in r.text and "8823" in r.text, r.text[:250])
    check("duplicate says plainly that it did not start a second copy",
          "NOT started again" in r.text, r.text[:250])
    check("list_background_commands shows the port",
          "[listening on 8823]" in t.list_background_commands().text,
          t.list_background_commands().text)

    # Kill the whole process group from outside, exactly as a model's `kill -9` would.
    subprocess.run(f"kill -9 -{pid}", shell=True)
    time.sleep(0.8)
    check("externally killed server is pruned from the live list",
          all(p != pid for p, _ in t._live_background()),
          repr(t._live_background()))
    r = t.run_background_command(command="node srv.js")
    check("the same command can be restarted after an external kill",
          "started with PID" in r.text, r.text[:250])
    new_pid = int(r.text.split("PID ")[1].split(".")[0])
    check("the restarted server is really serving",
          subprocess.run("curl -s --max-time 3 localhost:8823", shell=True,
                         capture_output=True, text=True).stdout == "ok")

    r = t.stop_background_command(pid=new_pid)
    check("stop_background_command reports the stop", "Stopped background" in r.text,
          r.text[:150])
    check("stopping reaps the child (no zombie left behind)",
          not Path(f"/proc/{new_pid}").exists()
          or "Z" not in (t._group_proc_states(new_pid) or ["-"]),
          repr(t._group_proc_states(new_pid)))
    check("a stopped server is gone from the live list",
          all(p != new_pid for p, _ in t._live_background()),
          repr(t._live_background()))

    # A process that is alive but serving nothing must be reported as exactly that -
    # never as "already running" with an implied healthy server.
    t.run_background_command(command="sleep 30")
    r = t.run_background_command(command="sleep 30")
    check("duplicate of a non-listening process says so instead of asserting health",
          "not listening on any port" in r.text, r.text[:300])
    check("non-listening duplicate points at the lifecycle tool, not at kill",
          "stop_background_command" in r.text and "kill" not in r.text, r.text[:300])
finally:
    t.teardown()

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILURE(S): " + ", ".join(FAILURES))
    sys.exit(1)
print("ALL CHECKS PASSED")
