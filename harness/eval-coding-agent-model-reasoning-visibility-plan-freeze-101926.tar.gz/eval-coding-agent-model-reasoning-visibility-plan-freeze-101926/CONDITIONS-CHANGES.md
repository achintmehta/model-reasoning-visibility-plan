# Condition restructuring (second harness revision)

(HARNESS-CHANGES.md from the first revision appears to have been moved; this file
documents the condition changes only. conditions.py carries the full rationale inline.)

## Removed
- **`none`** — duplicated `blind` byte-for-byte. Use `blind`.
- **`self_built`** — duplicated `execution` byte-for-byte. Use `execution`.
- `tools_for()` rejects both with a pointer, so a duplicate treatment arm cannot be
  created by accident. Archived manifests with the old names remain valid data;
  `harness_git` distinguishes instrument versions.

## Added
- **`boot_check`** — BASE + one `check_boot()` tool: npm install where needed → boot
  the detected server entry → report listening port or first 50 log lines → always
  kill. The cheapest execution signal. Verified to catch the archived
  `express is not defined` artifact that a full visual run shipped.
- **`visual_no_shell`** — BASE + `start_app()` + `screenshot`. start_app installs
  deps, runs the project's own dev/start script, returns serving URL(s), and restarts
  the app when called again. Decomposes SIGHT from EXECUTION (the visual arm's missing
  control). Member of VISION_CONDITIONS.
- **`delayed_verification`** — phase-dependent tool list (DELAYED_UNLOCK in
  conditions.py): BASE until the first `finish` call, which unlocks the full shell and
  injects one fixed message instead of ending the run; the second finish is terminal.
  Manifest extra records `verification_unlocked_at_step`.

## Recommended assignment
- Core ladder on every spec: blind → static → boot_check → execution → visual.
- visual_no_shell on calendar-week-view + metrics-dashboard.
- delayed_verification on kanban-board + seat-booking.
- behavioral on seat-booking.

## Verification performed
- All conditions' tools have schemas and Tools methods (asserted programmatically).
- Delayed unlock tested with a scripted client: pre-phase offers BASE only, first
  finish unlocks the shell at the recorded step, second finish terminates `finished`.
- `check_boot` tested on a working archived app (reports port 3000 + log head) and on
  the broken archived app (reports exit code 1 + the ReferenceError).
- `start_app` tested on a real app: starts via `npm run dev`, reports URL, restart
  semantics work, teardown kills it.

## Addendum: condition briefings (third revision)

**Problem.** Per-condition spec variants (`*-blind`, `*-playwright`) embedded tool
instructions in the TASK text. This broke the input-identity proof (task_sha differed
across conditions) and, in the playwright variants, MANDATED verification behavior
("you must verify the screenshot... fix and verify again") — prescribing the dependent
variable in exactly the arm meant to measure it.

**Change.**
- `conditions.CONDITION_BRIEFINGS`: one fixed, registered paragraph per condition,
  appended to the system prompt. Rules: descriptive only (what tools exist,
  environmental facts), never prescriptive (no process mandates, no quality bars);
  fixed per condition, never per task or model. `delayed_verification`'s briefing is
  deliberately identical to `blind`'s — the pre-phase model gets no foreknowledge of
  the unlock.
- `agent.py`: base system prompt is now tool-neutral (the run_background_command
  sentence moved into the shell briefings); `build_messages()` appends the briefing;
  the manifest records `base_prompt_sha`, `condition_briefing_sha`, and the combined
  `system_prompt_sha`.
- `verify_inputs.py`: new invariant — task_sha identical across the whole batch,
  base_prompt_sha identical, each condition's briefing hash single-valued AND matching
  the registry in conditions.py; flags human-contaminated runs; reports legacy runs
  (no part-hashes) separately.
- Use ONE tool-silent spec per task from now on. The per-condition spec variants are
  superseded; do not write new ones.

**Verified.** Briefings cover every condition and contain no prescriptive phrases
(asserted); prompt assembly = base + briefing with task byte-identical across
conditions; verify_inputs passes a clean synthetic batch and catches all three
violation classes (task drift, tampered briefing, human contamination); execution and
delayed_verification mock-loop regressions pass.

## Addendum: baseline renamed blind -> no_verification

Reasons: (a) terminology collision with InteractWeb-Bench's unrelated "blind
execution" failure mode (executing without understanding an ambiguous user; ours is
authoring without verification tools); (b) imprecision — static/boot_check/execution
are equally sightless, the baseline uniquely lacks ANY verification; (c) "blind" reads
as "no visual input" in the vision/multimodal literature. The registry maps the legacy
name (tools_for("blind") raises with a pointer); archived manifests keep their
original labels — map via the registry and group by harness_git. run.sh and all
guideline docs updated.

## Addendum: interactive conditions (interactive_support branch, 2026-08)

**Motivation.** The verification-surface study's characteristic residue was apps whose
backends were perfect and whose pages LOOKED perfect but which could not be used —
pixel-perfect pages that ignore every click, a failure class invisible to every tool
in the study except a human's hand. Screenshots gave the agent sight; these
conditions give it touch. Designed as the top rungs for the quantization × agent
behavior study (browser tool calls are the longest, most schema-heavy calls an agent
makes — plausibly the most quantization-sensitive behavior there is; hypothesis H5).

## Added
- **`harness/browser.py`** — BrowserSession: ONE persistent headless-Chromium session
  per run (playwright → browser → page lives across tool calls, closed in
  Tools.teardown()). *[Superseded in part — see "Addendum: multi-page browser
  sessions" below. Still ONE session and ONE browser context per run; what changed is
  that the context may now hold several PAGES (tabs), and the tools act on whichever
  page is active. The chain is playwright → browser → context → page(s).]*
  Feedback per action: what happened, URL + title, new console
  errors / uncaught page errors, and the page structure (ARIA snapshot when the
  installed Playwright supports it, else a deterministic interactive-element summary
  with usable selectors + trimmed page text). All failures return ERROR text, never
  exceptions; every action has a hard timeout; output is bounded (2500-char
  snapshots, 5 errors per report). A dead page/browser transparently restarts on the
  next call WITH a visible NOTE (session loss is observable data; restart count is
  printed at teardown). Optional env `HARNESS_CHROMIUM_PATH` points at a system
  Chromium for hosts without Playwright's managed download (e.g. aarch64 DGX Spark).
- **`interactive`** — BASE + full shell + browser_navigate / browser_click /
  browser_type / browser_read / browser_wait. Text feedback ONLY, so it runs on
  text-only models (NOT in VISION_CONDITIONS). Clean control: execution
  (interactive = execution + touch).
- **`interactive_screens`** — interactive + browser_screenshot, which captures the
  SESSION's current page (state from clicks/typing included), unlike the stateless
  screenshot(url) tool. Vision-capable models only (added to VISION_CONDITIONS).
  Clean controls: interactive (adds sight to touch) and visual (adds touch to sight).
- Briefings: registered per-condition texts extend the shell briefing, descriptive
  only (what the tools do, never whether/how to use them — H2/H5 measure that
  choice). UNIVERSAL_BRIEFING unchanged (its no-tool-names guard now also covers the
  browser tools).

## Verification performed
- All conditions' tools have schemas and Tools methods (programmatic assertion).
- Briefing-registry guard passes; verify_inputs.py needs no change (it loads the
  registry dynamically; gating check reads allowed_tools from the manifest).
- Session persistence: state built by clicks/typed text survives across separate
  tool calls; counter/list state confirmed after click sequences on a scripted app.
- Error paths: bad selector, fillable-element mismatch, dead server (connection
  refused with actionable hint), wait-for-absent-element — all return ERROR text.
- Crash recovery: page closed mid-run → next call starts a fresh session and says so.
- Teardown: browser closed before background processes are killed; no orphans.
- run.sh whitelist extended (interactive | interactive_screens).

### Addendum: browser_drag (drag and drop)

Added because `kanban-board`'s central interaction is dragging cards between
columns: without it an agent in the interactive condition has hands everywhere
except the one place that matters on that spec, which would systematically
understate the condition's value exactly where touch should help most.

`browser_drag(source, target)` handles BOTH web drag mechanisms:
- **HTML5 native** (`draggable="true"` + dragstart/dragover/drop). These listen for
  DRAG events, which synthesized mouse motion does not produce; Playwright's
  `drag_to()` dispatches them properly.
- **Mouse-based libraries** (SortableJS, dnd-kit, react-beautiful-dnd, hand-rolled
  handlers), which listen to mousedown/mousemove/mouseup and usually impose an
  ACTIVATION CONSTRAINT (minimum travel and/or a hold). A single jump from source to
  target fires too few events and does nothing, so the implementation holds after
  mousedown, moves in 12 interpolated steps, settles on the target, pauses, releases.

**Mechanism is DETECTED up front (draggable attribute), not tried-and-fallen-back.**
This was forced by measurement, and the finding is worth recording: Playwright
enables CDP drag interception during `drag_to()`, and that interception SWALLOWS
subsequent synthesized mouse moves. On the harness's own test page a mouse sequence
delivering 14 mousemove events on a clean page delivered only 4 after a `drag_to()`
attempt — far below any activation constraint, so an html5-first fallback silently
did nothing. Ordering is therefore constrained: the mouse path may never follow the
HTML5 path, though the reverse is safe (and is used as a secondary attempt when a
mouse drag leaves the DOM unchanged).

Every drag reports the mechanism used and whether the page actually changed, so a
model dragging something unmovable is told plainly rather than assuming success.
Missing source/target selectors are named explicitly instead of failing as a no-op.

Verification: test_browser_tools.py drives a page containing both an HTML5 board and
a mouse-library imitation with a realistic activation constraint (>8px travel AND >=3
move events); both drops land, an undroppable target reports no change, and both bad-
selector paths return the naming error. Loop-guard tests unaffected.

**Treatment note:** this changes the interactive conditions' tool list and briefing
hashes (interactive b9da2049b32bd8a3, interactive_screens 60b00aeae2f9b4f4;
UNIVERSAL_BRIEFING unchanged at 02f244a9339a0cb6). Landed before any study batch;
never add a tool mid-study.

#### Follow-up: drag failure diagnostics

Prompted by a real run. A model's kanban board attached drag handlers to CARD
elements only and none to the columns, so a card could never be dropped into an
empty column. `browser_drag` correctly reported "the page DID NOT change" and listed
three possible causes; the model could not tell which applied and went off to poke
the API instead, then loop.

`browser_drag` now installs a capture-phase event probe for the duration of the call
(removed before it returns) recording which drag/mouse events the page received and
which reached the drop target. When — and only when — the page did not change, the
report adds one sentence naming the cause, for example:

- `dragstart` never fired -> the source did not begin a drag at all
- target never received `dragover`/`dragenter` -> nothing at the drop point listens
  *[superseded — see "drag diagnostics II" below. This branch no longer infers that
  nothing was listening; it names the element that DID receive the events, because
  an intercepting overlay and a missing handler need opposite fixes.]*
- `dragover` reached the target but no `drop` -> a dragover handler must call
  `preventDefault()` (this is the kanban case above)
- a `drop` reached the target but nothing changed -> the handler ran without moving
- mouse path: no `mousedown`, too few `mousemove`s, missing `mouseup`, or a complete
  sequence with nothing wired up at the drop point

This reports browser facts, the same category as the existing console-error capture.
It never modifies the page and never suggests a code fix — the sentence describes
what the page did or did not receive, and the model draws its own conclusion.
Successful drags carry no diagnosis. Tests cover both failure diagnoses, the absence
of a diagnosis on success, and that the probe leaves no listener or global behind.

## Addendum: factual-feedback pass (2026-08)

Six changes, all the same shape: a tool reported less than the harness already knew,
so a situation that meant one thing was indistinguishable from a situation that meant
something else. Each was chosen from a real run where a model burned steps on the
ambiguity. Ordered by observed cost.

1. **Stale-process note** (`write_file` / `edit_file`). Editing a file does not change
   an already-running process. Observed: a model fixed a validation bug, grepped to
   confirm the old text was gone, kept receiving the old behavior from the server it
   had started BEFORE the edit, concluded there was "caching at the Node.js level",
   and burned ~14 steps before restarting. Both tools now name the background
   processes the harness started earlier and state that a running process does not
   pick up file changes unless it watches files or is restarted.
2. **`edit_file` no-op detection.** An edit whose `old_str` equals its `new_str`
   rewrote the file byte-for-byte and reported "edited", so a model could believe it
   had changed something it had not — which fed directly into (1). Now reported as
   "old_str and new_str are identical, so the file is unchanged."
3. **Native dialog reporting** (browser). Playwright auto-dismisses `alert` /
   `confirm` / `prompt` when unhandled, silently, so a click that opens a prompt looks
   exactly like a click that did nothing. Observed: a model clicked its own "Add Card"
   button, whose handler is `prompt()`, and could not tell why nothing happened. The
   session now records dismissed dialogs (it must still dismiss — an open dialog
   blocks every further browser operation) and reports the type and message once.
4. **`run_command` timeout note.** A bare "timed out after 180s" reads the same for a
   hung command and for one that is long-running by design. Observed: `curl -N` on an
   SSE endpoint burned the full timeout and taught the model nothing. The note that
   `run_command_and_capture_output` already carried is now on this path too.
5. **`browser_read` match disambiguation.** An empty result was three situations
   wearing one face: no match, a match that is empty, or several matches whose first
   is empty. Now reports "matched NO elements", the match count when above one, and
   an explicit note when the element exists but contains no text.
6. **`browser_click` DOM-change note.** Symmetric with `browser_drag`: a click that
   changed nothing now says so. Reported, never enforced — a page may legitimately
   re-render to an identical DOM.

**Scope discipline (the line this pass does not cross).** Every item reports what the
ENVIRONMENT did: which processes are running, what the tool call itself did, what the
browser received. None inspects the artifact's CONTENT. In particular, validating
written files (e.g. "this JSON does not parse") stays out: that is a free syntax
checker in every arm and would destroy the `no_verification` baseline, which is the
study's floor condition. No-op detection and the stale-process note are about the
tool call and the process table, not about whether the code is any good.

Verification: `test_shell_tools.py` (new, no browser needed) covers no-op detection,
the stale-process note appearing only when something is running, and the timeout note
appearing only on timeout, plus regression on the existing `edit_file` guards.
`test_browser_tools.py` covers the click note in both directions, dialog reporting and
non-repetition, and all three `browser_read` cases. Loop-guard tests unaffected;
briefing hashes unchanged (all wording lives in tool results, not briefings).

**Study note:** this is idea 20 (tool ergonomics) appearing empirically. Error-message
precision appears to matter more for weaker models, which predicts an ergonomics ×
precision interaction the quantization study could surface. All six are instrument
changes: fine before a batch, frozen at pre-registration.

## Addendum: background-liveness honesty + truncation status (2026-08)

Four changes, all from run 6 of qwen3.6-27b (127 steps, `stuck_looping`). Same rule as
the pass above: report what the ENVIRONMENT did, never inspect the artifact's content.

### 1. `run_background_command` no longer asserts liveness it cannot back up

**The defect.** Steps 85-88 and 123-126 repeated a three-move cycle: the model killed
its server with `ps aux | grep "node server" | ... | kill -9`, called
`run_background_command` to restart it, and was told `NOTE: this exact command is
already running as PID 13136`. The note was false — the server was dead. Having been
told a healthy server existed while every request to it failed, the model's only
remaining move was another name-based `kill -9`, which re-armed the trap.

**Why the harness believed it.** Liveness was `os.killpg(pid, 0)`, and the tracked
`Popen` object was discarded at start, so nothing ever reaped the child. A killed,
unreaped child becomes a zombie; **a zombie group leader still answers `killpg`**.
Confirmed directly: after `kill -9`, `ps` shows `Zs [sh] <defunct>` and the existence
check keeps returning success indefinitely.

**The fix**, in `harness/tools.py`:

- `_register_bg()` keeps the `Popen` so `_live_background()` can `poll()` it. Polling
  reaps the child, which makes the existing probe truthful by itself.
- `_live_background()` additionally reads `/proc` and treats a process group whose
  members are **all** zombies as dead. Covers the case where the leader is reaped but
  the group lingers.
- `stop_background_command()`, `start_app()`'s restart path and `teardown()` all reap
  what they kill, so the harness stops manufacturing zombies in the first place.
- The duplicate-command note now **carries its evidence**: the listening port when
  there is one, and when there is not, says exactly that and points at
  `stop_background_command` rather than leaving `kill -9` as the only visible option.

### 2. `_listening_ports_of_group` no longer reports "not listening" when it cannot look

Found while testing the above, and worse than the bug it was found under. The helper
shelled out to `ss` and returned `[]` on any failure — missing binary included. Once
the duplicate-command note began reporting that value to the model as fact, a host
without iproute2 would have told the model that every healthy server was not
listening. It now reads `/proc/net/tcp{,6}` plus `/proc/<pid>/fd` directly (no external
dependency), keeps `ss` only as a fallback, and returns `None` for **could not check**
as distinct from `[]` for **checked, nothing listening**. All three call sites word
their output from that distinction.

### 3. New terminal status: `truncated_no_tool_call`

A turn with no tool calls AND `finish_reason == "length"` was being recorded as
`stopped_no_tool_call` — the status documented to mean *the model narrated instead of
calling a tool*. That conflates an infrastructure fault with a verdict about the
model's tool-calling ability, and it did: runs 1-5 of qwen3.6-27b looked like a model
that could not call tools, when LM Studio was JIT-reloading it at `n_ctx=4096` and step
4's prompt left 55 tokens for the reply. The run now stops immediately (nudging would
only lengthen the prompt that overflowed) and records `truncation_detected` in the
manifest with prompt tokens, completion tokens and the requested `max_tokens`. Those
three numbers separate a **server-side context ceiling** (small prompt, tiny completion,
large `max_tokens`) from a model that **exhausted its own per-turn budget**
(`completion_tokens` at `max_tokens`). `RESULTS-SCHEMA.md`'s `run_status` enum updated.

### 4. `reasoning_content` surfaced into `Turn.reasoning`

Provider chain-of-thought (LM Studio `reasoning_content`, OpenRouter `reasoning`, and
the nested-dict form) is captured onto the `Turn`, printed in `--verbose`, and counted
per run as `reasoning_turns` / `reasoning_chars`. A turn that thought at length and
emitted nothing used to print as total silence, indistinguishable from a dead endpoint.

**It is deliberately NOT echoed back in the assistant message.** Replaying reasoning
would change what the model is conditioned on, and would do so *only for reasoning
models* — a second treatment riding along with the one under study.
`test_agent_status.py` pins this with a marker string asserted absent from the next
request.

### Also added: `tasks/agent-canary`

A dependency-free screening spec — write a data file, write a program that digests it,
state the exact line it prints. No network, no install, no server, so a failure is a
property of the model or the serving stack rather than the project environment.
Expected output is `REPORT 10 bebd11ddbd1a <node-version>`; only the version varies by
host, and it cannot be produced without actually executing the program.

Unlike `tasks/browser-smoke`, the canary is written to a **completion criterion** ("the
task is complete when the final summary states the exact line") rather than a process
mandate, so it does not prescribe verification behavior. It is still a screening task,
not a study spec, and should not enter a batch.

### Verification performed

- `test_agent_status.py` (new): 20 checks — truncation classification and its recorded
  token counts; regression that `finish_reason=stop` still takes the nudge-then-stop
  path; reasoning captured from all three provider shapes; reasoning counted; and the
  no-replay guarantee.
- `test_shell_tools.py`: extended to 28 checks — port reported at start, duplicate note
  naming the port, `list_background_commands` showing it, the probe returning a list
  without iproute2 present, prune-after-external-kill, successful restart with `curl`
  confirming the new server actually serves, reaping on stop, and the honest
  non-listening note.
- `test_loop_guards.py` and `test_browser_tools.py`: unchanged, both still pass.
- Briefing hashes unchanged — all wording lives in tool results, not briefings.

All four are instrument changes: fine before a batch, frozen at pre-registration.

## Addendum: multi-page browser sessions (2026-08)

### Why

The interactive conditions held exactly one page. That made an entire class of
acceptance criteria unreachable by any sequence of tool calls: `message-board`'s
"ensure all connected clients receive updates instantly", and anything else defined
across simultaneous clients, sat outside the verification surface rather than inside
it and unmet. The condition could not be failed on that criterion because it could not
be tested on it.

Observed in a real run: the model announced it would "open a second browser tab to
test the SSE real-time functionality", called `browser_navigate` on the same page,
observed the messages that were already there, and reported the two-client behavior as
verified. The stated test never ran. That is a harness limitation producing what looks
like a model defect, and it would have been scored as one.

### What was added

Three tools, taking the interactive set from 6 browser tools to 9:

- `browser_new_page(url?)` — open an additional page and make it active, optionally
  navigating it in the same call.
- `browser_switch_page(page)` — change which open page the other tools act on.
- `browser_close_page(page?)` — close one; defaults to the active page.

Labels are `page-1`, `page-2`, ... assigned monotonically and never reused, so a label
in the transcript always refers to the same page. `_normalize_label` accepts `page-2`,
`page 2`, `2` and `2` as an integer, because models are inconsistent about ids and a
label typo is not the behavior under study.

### The three design decisions worth arguing about

**One context, not one context per page.** Additional pages come from
`context.new_page()`, not `browser.new_page()`. They therefore behave like *tabs*:
shared cookies and local storage, separate DOM, separate JavaScript state, separate
network connections. `browser.new_page()` would have modelled a second *browser*, which
silently breaks any app holding session state client-side. Two tabs are still two SSE
clients from the server's point of view, so nothing is lost for the multi-client case.

**The six existing tools are unchanged.** They act on whichever page is active, so
their schemas, arguments and output are identical to before. The alternative — a `page`
argument on every action — would have put an id in front of every call a weak model
makes, which is a large ergonomic tax to pay on every step for a feature used on a
handful of them.

**The OPEN PAGES line appears only when more than one page is open.** A run that never
calls `browser_new_page` produces feedback byte for byte identical to the pre-change
harness. The condition is a strict superset: single-page behavior is untouched, and
multi-page feedback only appears once the model has opted in.

### Page death is now distinguished from browser death

`restart_count` used to cover both. A closed page inside a live browser now creates a
replacement page in the same context, counts against a separate `page_restart_count`,
and says what actually survived ("its DOM and JavaScript state are gone... cookies and
local storage survived") rather than the blanket "page state from earlier calls is
gone". A dead browser still takes the full restart path and still increments
`restart_count`. Conflating them hid which kind of instability a run hit.

### Treatment surface

Both interactive briefings gained a descriptive sentence about pages, so their hashes
changed:

| briefing | before | after |
|---|---|---|
| `interactive` | `b9da2049b32bd8a3` | `57627552f8cc93da` |
| `interactive_screens` | `60b00aeae2f9b4f4` | `87da654d1de4e767` |
| `UNIVERSAL_BRIEFING` | `02f244a9339a0cb6` | `02f244a9339a0cb6` (unchanged) |

No other condition's briefing or tool list changed. The wording stays descriptive —
it says what the tools do, never that the model should use them.

This widens the interactive arm rather than fixing a defect in it, so runs made before
this change are not comparable to runs made after on any multi-client criterion. It is
pre-freeze work by definition.

### Verification performed

`test_browser_tools.py` grew to 277 checks. Beyond registry and label handling, three
matter:

1. **State isolation** — a click on the active page leaves the other page's counter at
   0, typed items do not cross over, and switching back finds the earlier page intact.
2. **A real two-client SSE check** — the suite now runs its own threaded SSE broadcast
   server whose page deliberately does *not* append optimistically, so anything
   reaching the DOM arrived over `EventSource`. Post on one page, switch, read the
   other: the message is there, and the reverse direction is asserted too so the check
   cannot pass by both pages sharing a DOM. This is the sequence that had no
   expressible form before.
3. **Crash paths** — closing a page yields a replacement plus `page_restart_count == 1`
   with `restart_count == 0`; closing the browser yields the full restart with
   `restart_count == 1`.

`setup_browser_smoke.sh` gained a cross-page beacon driven by the `storage` event,
which fires only in the *other* pages of the context. A single-page run cannot make
that element change, so smoke step 7 tests the tools rather than the model's
willingness to claim it did them. Confirmed by driving it directly: the broadcasting
page reads `nothing received`, the other reads `RECEIVED: beacon-1`.

## Addendum: drag diagnostics II + the tool-call malformation counter (2026-08)

Both prompted by one Gemma 4 run on `kanban-board` (64 steps, `finished`, drag never
once worked, summary claimed "drag-and-drop functionality").

### 1. Drag failures now distinguish three causes that used to read alike

The first diagnostics pass reported which drag EVENTS the page received. That was right
as far as it went, but it inferred causes from absence, and two very common defects came
out wearing the same sentence.

**Geometry.** An empty container with no `min-height` collapses to zero height. It has a
bounding box and no area. The old code checked only `if not sb or not tb` — a zero-height
box is a truthy dict, so the mouse path sailed through and computed a drop point on a
one-pixel line, while the HTML5 path spent 10s in `drag_to` and returned
`Timeout 10000ms exceeded`. Either way the model was told "nothing at the drop point is
listening", which blames handlers that are usually fine. There is now a **pre-flight
geometry check for both mechanisms** reporting the measured size:
`the target element '#col-collapsed' measures 200x0 pixels, so there is no area to drag
to. The element exists and may be wired up correctly; it has no size.`

**Obstruction.** A sibling painted over the drop zone makes Playwright refuse the drag —
again with a bare timeout. `document.elementFromPoint` answers this directly and in a
millisecond: `the target exists but div#overlay is painted on top of it, so the drop point
belongs to that element.` A *descendant* at the centre is explicitly not an obstruction,
or every card list holding cards would fail the check.

**Identity.** The event probe now records a compact descriptor (`tag#id.class`) of the
first element to receive each drag event, plus the requested target's own descriptor and
measured box. Diagnosis branch 2 states what was measured instead of inferring:
`dragstart fired, but the requested target (ul#drop-zone) never received
dragover/dragenter - they reached div#overlay instead.` The mouse path gained the
equivalent: the pointer finished over X rather than the requested target.

Cost: one `elementFromPoint` evaluation and two `bounding_box()` calls per drag. In
exchange, three defects that need three different fixes now produce three different
sentences, and two of them answer immediately instead of after a 10-second timeout.

### 2. Tool-call malformation counter (harness-side, three classes)

The study's headline H1 mechanical measure. Counting only — **nothing here changes what
the model is sent.** Recorded per run in the manifest under `tool_calls`.

| Class | What it is | Where it is caught |
|---|---|---|
| `unparseable_arguments` | arguments were not valid JSON | `RealClient._parse` stashes the raw string under `__raw__`; usually truncation |
| `invalid_arguments` | JSON parsed, shape did not fit the tool's signature | `TypeError` from `fn(**args)`, matched against signature-error wording |
| `unparsed_in_content` | the model emitted a call the SERVER failed to parse, so `tool_calls` came back empty and the attempt is in the assistant text | `looks_like_tool_call_attempt()` |

Class 2 is the one the Gemma run exposed and the one a naive counter misses entirely:

```json
{"press_enter": true, "selector": "div[data-col-id=\"todo\"] input`,text:"}
```

Valid JSON. The selector string swallowed the next key and its value, so `text` never
existed. Emitted twice, identically, at Q4_K_M. Nothing in the JSON layer objects; the
failure surfaces one layer later as `ERROR bad arguments: ... missing 1 required
positional argument`.

Class 3 is what a broken chat template produces — observed with Gemma emitting
`{"action": "run_command", ...}` plus a literal `<tool_call|>` while the server returned
`tool_calls: []`. Uncounted it is indistinguishable from a model that narrated instead of
acting, which is a completely different result and would be scored against the model
rather than the serving stack.

**Two deliberate exclusions, so the metric is not quietly inflated.** A `ValueError` from
inside a tool (a path escape, say) is a refusal, not a malformed call — it lands in
`tool_errors_other`. And a `TypeError` is only counted when its message matches
signature-error wording, so an incidental `TypeError` in a tool body is not absorbed
either. `attempts` counts emitted calls plus class-3 attempts, so the rate has an honest
denominator.

The class-3 detector is deliberately conservative: a delimiter substring is unambiguous,
but a bare JSON object counts only when it names one of **this run's allowed tools**. A
model quoting a `package.json` — which has a `"name"` key — must never register as a
failed tool call, and a test pins that.

### Verification performed

`test_browser_tools.py` 281 → 288: collapsed target reports its measured size and does
not blame listeners; overlaid target names the covering element, names the requested
target, avoids the timeout, and does not say "listening"; a child of the target is not
treated as an obstruction. `test_agent_status.py` 28 → 46: ten class-3 detector cases
including three false-positive checks, one end-to-end run per class, a clean run
reporting a zero rate rather than a missing field, and a refused call proving it is not
counted as malformed. Suite total 374 checks, all passing.

Class boundaries freeze at pre-registration along with everything else; the counting
itself is measurement-side and model-invisible.

---

## Addendum — `write_file` no-op detection (2026-08-13)

**This is a treatment change.** It alters what a model sees after a tool call, in every
condition. Made before pre-registration, deliberately, and frozen from here.

### What changed

`write_file` now compares the incoming content against the file's current bytes and, when
they are identical, appends:

```
NOTE: <path> already contained exactly these bytes, so its contents are unchanged.
```

The write still happens. Skipping it would preserve mtime and quietly change how
file-watching dev servers behave — a real behavioural change hidden behind a message
change.

### Why

`edit_file` has had no-op detection since the identical-`old_str`/`new_str` case was
found; `write_file` never did. That was an inconsistency between two sibling tools rather
than a considered asymmetry, and the justification already written into `edit_file`
applies verbatim: *this reports what the TOOL CALL did, not whether the content is any
good.*

The pilot made the cost visible. In five `stuck_looping` runs the model confabulated a
one-character defect in a file it had just written — `</div` for `</div>`, `</body` for
`</body>`, `PGLite` for `PGlite` — and rewrote the file byte-for-byte up to six times.
The bytes were checked: the files were well-formed and the belief was false. Because
`reasoning_content` is never replayed, nothing the model *thought* survived to the next
step; the persisted context held only the tool call and `wrote 599 chars to
client/index.html`, a success message for an operation that changed nothing. The belief
was not persisting across steps so much as being regenerated each step from the same
stimulus, with nothing in the durable channel to contradict it.

### Why this does not compromise the ladder

It is an **environment fact** — whether bytes on disk moved — not a judgement about the
artifact. It cannot substitute for a syntax check, a boot, or a screenshot, so the
`no_verification` baseline keeps its meaning. `read_file`, `write_file`, `edit_file`,
`list_dir` and `finish` are present in **every** condition, so nothing here shifts the
relative verification surface between arms.

### Blast radius, measured

Across the 14 pilot runs: 98 `write_file` calls, 18 of which rewrote identical bytes.
**All 18 were inside runs that ended `stuck_looping`; zero occurred in runs that
finished.** A run that is working never sees this note. (For contrast, 38 `edit_file`
calls changed nothing and 20 of those were in runs that finished fine — which is why the
parallel change to `edit_file`'s `ERROR: old_str not found` was *not* made: it would
alter the environment of healthy runs.)

### Known risk

`stuck_looping` is a dependent variable, inside the H1 reliability bundle. If this note
rescues models unequally across precision rungs it interacts with the independent
variable, and the pilot must characterise that rather than assume it away. The counter-
argument, which decided it: reporting "wrote 599 chars" for a zero-byte write is not
neutral, it is misinformation, and correcting misinformation is a different act from
adding assistance.

### Verification performed

`test_shell_tools.py` 28 → 36: a new file carries no note; rewriting identical bytes
reports unchanged while still reporting the write; a genuine change carries no note;
identical content written to a *different* path is not flagged; the file still ends with
the right contents; and an existing undecodable/binary file does not break the
comparison. Suite total 434 checks across five files, all passing.

---

## Addendum — reasoning replay (2026-08-13)

**This is a treatment change, and a larger one than the `write_file` note.** It changes
what the model sees on every step after the first. Made before pre-registration,
deliberately, and frozen from here. Default is now **ON**; `--no-replay-reasoning` (or
`REPLAY_REASONING=0`) restores the previous behaviour, and every run records which it was
in `reasoning_replayed`.

### What changed

The assistant message echoed back into the conversation now carries the turn's
`reasoning_content` alongside its `tool_calls`. Previously the model's chain of thought
was read once — counted into `reasoning_turns` / `reasoning_chars` — and then dropped the
moment the tool call was extracted.

### Why

Three reasons, in descending order of confidence.

**The old behaviour was not neutral, it was a third option nobody deploys.** There are
three self-consistent configurations — thinking on with reasoning replayed, thinking off
entirely, and thinking on with reasoning discarded. The harness was in the third: the
model paid completion tokens to reason at every step and that work was destroyed before
the next step could use it. That is defensible as "the scratchpad is per-step", but it is
neither the realistic option nor the minimal one, and it is the hardest of the three to
justify in a methods section.

**The construct is precision-*as-served* — the thing a deployer chooses.** A 2026
deployer running an agentic coding loop has reasoning carried forward. Anthropic requires
thinking blocks to be echoed unmodified during tool use and 400s otherwise; DeepSeek's
thinking mode requires `reasoning_content` to be passed back whenever tool calls are
present. Two of the three major providers have made the round-trip mandatory, so a
harness that discards it is measuring something adjacent to the deployment it represents,
and any future hosted arm would have to implement this regardless.

**The pilot showed the cost concretely.** Five runs looped on a confabulated
one-character defect. The model's reasoning shows it noticing — *"I noticed I keep
writing the same index.html"* — and that noticing was discarded before the next step
could act on it. Whether replay actually breaks such loops is an **open empirical
question the pilot must answer**, not a claim made here.

### Known risks, none of which are settled

**Precision × reasoning interaction — the one that matters.** H1's ladder compares
precision within model, within condition. If replay rescues low rungs more than high ones
— plausible, since the observed loops are exact-token failures and a reasoning scaffold is
exactly what would matter more when token fidelity degrades — the ladder's slope moves,
and slope is the primary estimand. Blocking on model does nothing about this, because it
lives inside the block. **The pilot must characterise it rather than assume it away.**

**Model × condition interaction.** Only reasoning-emitting models are affected. Taking
condition differences within model removes additive model effects exactly, so no single Δ
is biased; what changes is the between-model spread in Δ, which is what a generality
claim rests on. Check `reasoning_replayed_turns` per model before assuming the treatment
applied uniformly — a model emitting no reasoning yields 0 with the flag still true.

**Study-1 comparability.** Study 1 ran without replay. Direct comparison of the two
studies' baselines no longer holds. This cost does not dissolve and belongs in the
threats table.

**Context.** Replay adds a roughly constant **+32%** to every prompt (the prompt at step N
carries reasoning from steps 1…N−1 — linear in run length, not quadratic). Measured on
the 14-run pilot: total prompt spend 4.21M → 5.16M tokens, 1.23×. It moves the
`n_ctx=65,536` overflow point from about 127 steps down to about 100. Scaling the load
logs shows this is a non-issue on a 96 GB card — with flash attention on, even BF16 at
262,144 context lands near 80 GB — **except** in §6.2's iso-memory arm, where KV cache and
weights compete for a deliberately fixed budget and a larger context is a real trade.

### Serving-layer risk, and the probe that exists because of it

Not every server accepts the round-trip. llama.cpp has a live bug where an assistant
message carrying both `reasoning_content` and `tool_calls` fails template rendering
(`Cannot pass both content and thinking in an assistant message with tool calls!` —
ggml-org/llama.cpp#19703, regressed again in #20500), and a template with no slot for
prior reasoning will silently drop it, which is worse: the batch looks fine and the
setting does nothing.

`tools/probe_reasoning_replay.py` answers this in ten seconds without spending a run,
returning ACCEPTED / REJECTED / IGNORED. It distinguishes the silent case by planting a
nonce that appears **only** inside the replayed reasoning and asking the model to echo it,
with a control turn that puts the same text in ordinary `content` so "the reasoning was
dropped" is separable from "this model would not follow the instruction anyway".

`RealClient` also classifies the failure at the point it occurs: a 4xx matching the
template-refusal patterns is reported as *"the server is REFUSING replayed reasoning …
re-run with --no-replay-reasoning"* and is **not** retried, because a message the template
cannot render will fail identically forever. The classifier is deliberately narrow — a
crashed server and a rejected decoding parameter must keep their own handling, and tests
pin both.

**Run the probe before any batch with replay on.** Nothing downstream is meaningful until
it returns ACCEPTED.

### Verification performed

`test_agent_status.py` 67 → 80: replay on puts `reasoning_content` on the assistant turn
beside its `tool_calls` and increments the sent-back counters; replay off leaves the
message clean while still counting reasoning for audit; and six classifier cases covering
both template refusals and the two error classes that must NOT be attributed here. Suite
total 454 checks across five files, all passing.

---

## Addendum — `--extra-body` (2026-08-13)

**Capability, not a change of default.** With the flag unset nothing differs; used, it is
a treatment, and it is recorded verbatim as `extra_body` in every manifest.

### What it does

Merges a JSON object into every chat-completions request, for fields the OpenAI schema
has no slot for. Inline JSON or `@path`. Two real uses:

- **`chat_template_kwargs`** — the only way to toggle thinking on Qwen3 or Gemma through
  llama-server, so the thinking-on/off secondary is impossible without it.
- **llama.cpp sampler fields the schema omits** — `top_k`, `min_p`, `repeat_penalty` —
  plus `cache_prompt: false`, which bears on M1's determinism question because prompt-
  cache reuse changes how many tokens are computed per batch.

### Why it matters beyond convenience

llama.cpp merged **model-embedded sampling parameters** in November 2025: a GGUF may
carry `general.sampling.*`, resolved as explicit request value → file metadata → built-in
default. The unsloth Gemma files carry `top_k = 64`, `top_p = 0.95`, `temp = 1.0`.

The harness sends `temperature` and `top_p` explicitly, so the registry values win. But
`top_k` has no field in the OpenAI schema, so **runs have been using the file's
`top_k = 64` with no way to set or record it.** That is not a live fault — at temperature
0 the sampler is greedy, and taking the argmax over the top 64 candidates selects the same
token as over the full vocabulary. It is, though, an unrecorded part of the serving
configuration, which §11 asks to be pinned. A publisher may override these keys with
`--metadata` at conversion time, so nothing guarantees two builds declare the same values
— and unlike `top_k`, a `penalty_repeat` *does* change greedy output, because it alters
logits before selection. An uncontrolled sampler difference co-varying with the rung would
sit exactly on the precision axis.

### The guard is the feature

An escape hatch that can silently rewrite the treatment is worse than no escape hatch, and
there are two silent failure modes here on opposite sides of one line in `RealClient`:

- **CLOBBERED** — `model`, `messages`, `max_tokens` are written *before* `**extra_body` is
  spread, so a key here overwrites them. Pushing `max_tokens` this way would change
  decoding while bypassing both the registry comparison and the `decoding_overridden`
  field that exists to catch a changed decoding parameter.
- **IGNORED** — `temperature`, `top_p`, `tools`, `tool_choice` are written *after* the
  spread, so a key here does nothing at all while the operator believes otherwise, and the
  manifest agrees with them. Worse than a crash.
- **UNSUPPORTED** — `stream` and `n`: the loop reads `choices[0]` of a non-streamed
  response.

All are refused, with the reason naming which class it is and which flag to use instead.
Validation runs **before the workspace is touched**, so a misconfigured batch stops at run
1 rather than producing 576 runs whose manifests misdescribe them. Every problem in the
object is reported, not just the first.

### Verification performed

`test_agent_status.py` 80 → 99: allowed keys pass; each of the nine refused keys is
refused with the right class; a mixed object reports every problem; a non-object is
refused; and the wire path confirms an allowed key reaches the request body while the
pinned `temperature` and `max_tokens` survive the merge. End-to-end: refusal aborts before
the workspace directory exists, malformed JSON fails with the parser's message, and
`@file` input lands in both the request and `manifest.extra_body`. Suite total 473 checks
across five files, all passing.

## Addendum — client reply timeout 600 s → 3600 s (2026-09-18)

### What changed

`harness/llm.py`: `RealClient(timeout=...)` default raised from 600 to 3600 seconds.
`agent.py` does not pass `timeout`, so the default governs every run. No manifest field
changes; the value is a client-side socket timeout, not a decoding or prompt parameter.

### Why

Responses are requested non-streamed, so `urlopen`'s read blocks for the whole
generation. With `max_tokens` 32768 per reply, a maximal reply takes longer than ten
minutes at local generation speeds (~40–60 tok/s on the study machine ≈ 9–14 min). At
600 s such a reply is cut off, the request is retried (`max_retries` 5, same greedy
output, same outcome), and the run ends as `api_error` — i.e. the longest *thinking*
replies were the ones being killed, which would have biased a thinking-on vs thinking-
off comparison in a way that looks like an infrastructure fault. 3600 s clears the
worst case with margin while still bounding a hung server.

### Verification performed

Constructor default and docstring updated; the smoke runs of the thought-visibility study
report the longest single-step duration per model, which must sit well under the new
limit. No behaviour changes for any reply that completed within 600 s before.

## Addendum — UNIVERSAL_BRIEFING: a sentence added in plan v2.5.6, withdrawn in plan v2.5.9 (2026-09-25)

### What changed

Plan 42 v2.5.6 added one sentence to `UNIVERSAL_BRIEFING`, the "tool-neutral strengthening"
that the GUARD in conditions.py names as the registered remedy for tool neglect:

> If execution tools are provided, they give you a live development environment: the commands
> you run through them execute for real in your workspace, on a machine with Node.js and npm
> installed and the npm registry reachable, so the packages you install and the servers you
> start are real.

Plan v2.5.9 withdraws it. `UNIVERSAL_BRIEFING` is the original text again, and the v2.5.6 text
stays in conditions.py, unused, as `UNIVERSAL_BRIEFING_V256`, so the runs made with it can still
be named and hashed.

### Why

It was added because two models did not use shell tools that were listed for them: gpt-oss-20b
reasoned that it had nowhere to run anything, and Magistral-Small-2509 that the task did not
require running the app. On their re-smoke under it (2026-09-25) both began running commands —
gpt-oss in 2 of its 4 execution and interactive runs, Magistral in 3 of its 6 — but 6 of
gpt-oss's 8 attempts at those four runs failed on harmony parse errors, two runs voiding, and
Magistral finished 3 of its 9 runs. The sentence was withdrawn and Magistral left the grid
(plan 42 §5.1).

### Treatment surface

| briefing | plan v2.5.6 – v2.5.8 | plan v2.5.9 |
|---|---|---|
| `UNIVERSAL_BRIEFING` | `c988f43155c49538` | `02f244a9339a0cb6` (the original) |

No tool list and no per-condition briefing changed. Only the gpt-oss and Magistral re-smoke of
2026-09-25 carries `c988f43155c49538`. It belongs to no certifying set, and verify_inputs.py
reports it as not matching the registry, as it should.

### Follow-up — reinstated in plan v2.5.10 (2026-09-25)

The study lead reinstated the sentence on a second reading of the same re-smoke. Under it both
models began running commands, which is what it was added for, and gpt-oss's two parse-failure
voids fell one in each arm — UNSEEN and SEEN — so they cost runs without tilting the contrast
the study measures, and they came in the two runs where gpt-oss did the work its execution and
interactive conditions exist to measure. Magistral stays out of the grid on its own record.

Both texts are now named constants in conditions.py — `UNIVERSAL_BRIEFING_V1`, the original,
and `UNIVERSAL_BRIEFING_V256` — and the registered briefing is one line choosing between them,
`UNIVERSAL_BRIEFING = UNIVERSAL_BRIEFING_V256`. Whether it stays is decided on a smoke of all
seven grid models made under it (plan 42 §4.1); if it does not, that line names
`UNIVERSAL_BRIEFING_V1` again.

| briefing | plan v2.5.9 | plan v2.5.10 |
|---|---|---|
| `UNIVERSAL_BRIEFING` | `02f244a9339a0cb6` | `c988f43155c49538` |

verify_inputs.py now matches the 2026-09-25 re-smoke again and reports every set made under
the original text as not matching the registry, which is right: none of those sets certifies
the grid.

## Addendum — the file-state history note on `write_file` and `edit_file` (plan v2.5.13, 2026-09-27)

**This is a treatment change.** It alters what a model sees after some `write_file` and
`edit_file` calls, in every condition and every arm. Made before the certifying smoke of the
thought-visibility study (plan 42), and frozen with the rest of the harness from there.

### What changed

Every `write_file` call that wrote — a rewrite of identical bytes included, since the write
still happens — and every `edit_file` call that did not fail — an applied edit, or one whose
`old_str` and `new_str` are identical, which leaves the file as it was — records the exact
bytes it left the file with, by resolved path and sha256. When those bytes have been
recorded for that file before, the result gains one line:

```
NOTE: <y> write or edit calls in this run, this one included, have left <path> with exactly this content; the previous one was <x> calls ago.
```

`y` counts write and edit calls together. `x` counts every tool call the agent loop
dispatched since the previous one, of any kind — refused and malformed calls included,
since each is a result the model sees — so "1 call ago" is the immediately preceding call.
An edit that errored records nothing. Paths are compared after resolution (`./a.js` is
`a.js`), and a change made by a shell command is not recorded: this is the history of what
the file tools left behind. The line comes after the call's own no-op note, if any, and
before the stale-process note. `harness/agent.py` numbers the calls and hands each number to
`Tools` before the call; the manifest gains `file_state_repeats`: `count` (the calls that
got the note), `writes`, `edits`, `reverts` (those that moved the bytes back to an earlier
content; the rest left the file as it was) and `max_times` (the most calls that left one
file with one content; 0 when the note never fired).

### Why

The study lead asked for it for writes, after the September smokes, and approved its
extension to edits. The no-op notes already say that one call changed nothing — `edit_file`'s since the
factual-feedback pass, `write_file`'s since 2026-08-13 — but not how often, and they are
silent when a file is put back to content it held earlier, because then the bytes did move.
In the 93 runs of the September smoke sets, `write_file`'s no-op note fired on 75 of 759
writes and `edit_file`'s on 108 of 406 edits. One run wrote `vite.config.js` with the same
content 28 times; another, which finished, made the same identical-string edit 31 times;
and a GLM-4.7-Flash run added and removed the same `<link>` tag with alternating edits until
the cycle guard ended it — edits that moved the bytes, so neither note fired, and nothing in
any result said the file had held that content before.

### Why this does not compromise the ladder

The same argument as for the no-op note. It is an **environment fact** about the model's own
calls and the file's bytes, not a judgement about the artifact, so it cannot substitute for a
syntax check, a boot or a screenshot, and the `no_verification` baseline keeps its meaning.
`write_file` and `edit_file` are present in every condition, and the text is identical in
every arm. It describes the content a file was left with, not a pattern of calls, so calls
that merely alternate — which can have different outcomes — are not flagged. And it is a
note, not a guard: it ends nothing, and the loop guards and their registered values are
unchanged. The briefings, the tool list and the tool schemas are unchanged; `conditions.py`
is untouched.

### Blast radius, measured

The recorded `write_file` and `edit_file` calls of those 93 runs were replayed through the
applied code — each run's calls in order, numbered as the agent loop numbers them, in an empty
workspace. The note fires **208 times, in 38 runs, 24 of which finished**: 82 times on writes
(77 of them rewrites of identical bytes) and 126 on edits (108 identical-string); 185 of the
208 left the file as it was and 23 moved it back to an earlier content. For 140 of the 208 the
previous one was the immediately preceding call. The most was 32 calls leaving one file with
one content, in a run that finished. The replay reproduces only what the file tools did: 16
edits that applied in the recorded runs failed in it, their files having been made or changed
by shell commands, and 2 writes differ on the no-op note, so these counts are close, not exact.

So, unlike the no-op note's pilot measurement above ("A run that is working never sees this
note"), this note reaches healthy runs, and the no-op note itself no longer fits that
measurement either: in these 93 runs it fired in 21 runs, 13 of which finished. The comment
in `tools.py` that carried the pilot figure is corrected.

Of the 60 runs of the 2026-09-25/26 all-model smoke, whose workspace paths and seeds the
certifying smoke reuses, 23 get the note, first at steps 2 to 54; such a run can replay its
predecessor only up to that call.

### Known risk

As with the no-op note, `stuck_looping` is a dependent variable, and a note that helps a model
out of a loop could help some arms more than others. The text is the same in every arm and
states nothing the transcript does not already imply — every arm keeps all of its earlier
calls in context — but a SEEN model can also see what it reasoned about the file before, and
may act on the count differently. `file_state_repeats` is therefore reported per model × arm
beside every result (plan 42 §10, tenth), and a difference in it between UNSEEN and SEEN is
reported as part of the visibility effect.

### Verification performed

`test_file_history.py` (new, 45 checks): a first write carries no note; an identical rewrite
is counted, its no-op note first; calls of any kind are counted, with singular and plural;
a write back to an earlier content is counted and carries no no-op note; one differing byte
is a new content; the history is per path; an edit flip-flop is counted both ways; writes and
edits share one history; an identical-string edit is counted, its own note first; failed
edits (not found, ambiguous, missing file) record nothing and are never the previous one;
`./src/app.js` and `src/../src/app.js` are `src/app.js`; bytes a shell command put in a file
are not history; the stale-process note stays last; the tallies; without the agent loop's
numbering the note gives the count alone. Through `run_agent` with a scripted client: refused
and malformed calls are counted, calls within one step are counted one by one, and the
manifest carries the tallies as a copy. The other suites unchanged and passing:
`test_agent_status.py` 99, `test_loop_guards.py` 12, `test_quant_registry.py` 39,
`test_retry_record.py` 14, `test_shell_tools.py` 35 — 244 checks across six files. And the
replay above.

## Addendum — the finish nudge after every turn without a tool call (plan v2.5.14, 2026-09-27)

**This is a treatment change.** It alters what a model sees after a turn without a tool call,
in every condition and every arm, and it changes when a run ends. Made before the grid of the
thought-visibility study (plan 42), which certifies it with a smoke of its own.

### What changed

Until now the first turn without a tool call got the finish nudge — a `role: user` message,
"You did not call any tool. If the task is complete, call the finish tool now; otherwise
continue working using the provided tools." — and the second such turn, wherever it fell,
ended the run as `stopped_no_tool_call`. Now every such turn gets the same nudge, and the run
ends only when the reply right after a nudge has no tool call either. A reply cut off at the
length limit still ends the run at once, un-nudged, as `truncated_no_tool_call` or
`runaway_no_tool_call`. The manifest's `finish_nudges` is now a count that can exceed 1, and
`finish_nudge_steps` records the step of every nudge.

### Why

In the 20M certifying smoke (plan 42, 2026-09-27) nine runs were nudged and four of them
finished afterwards. Three ended on a second turn without a tool call, and in all three the
two turns were apart — by 4, 7 and 21 steps — with the model working normally in between. Two
were Qwen3.6-27B runs that went quiet with a single token, the end of the turn, and one of
those did so right after a diff had shown it the one-letter difference that was its bug. A
one-token reply was deciding whole runs. The study lead chose to nudge every time, as the
file tools already report every repeat of a file's content without a limit.

### Why this does not compromise the ladder

The nudge is protocol scaffolding: the same text, in every condition and arm, after the same
event, saying nothing about the task or the artifact. The stop that remains, two in a row, is
what ends a run whose model has stopped responding, so a model that goes quiet for good is
still ended by its silence, not nudged until the token budget ends it and files it as
something else. The briefings, the tool list and the tool schemas are unchanged.

### What it changes in the measures

`stopped_no_tool_call` now means two turns without a tool call in a row, the second in reply
to the nudge. Turns with neither text nor a tool call come almost entirely in UNSEEN — 18 of
the 21 in the last two smoke sets, none in SEEN — so under the old rule they ended UNSEEN
runs; under this one most of those runs carry on, and the difference shows instead in the
count of turns without a tool call and in steps, both reported per model × arm (plan 42 §10).
The zero-nudge sensitivity analysis (plan 42 §10, fourth) keeps its definition: any run with a
nudge is dropped from both arms.

### Verification performed

`test_nudges.py` (new, 18 checks): isolated silences are all nudged and the run finishes, with
the nudge steps recorded and each nudge the last message of the next request; silent, nudge,
silent ends the run at step 2; work, then two in a row, ends it; a reply in prose without a
call counts the same as a silent one; ten separated silences are all nudged; a run that never
goes quiet is never nudged; a truncated reply still ends the run at once, and a runaway after a
nudged silence ends it as a runaway. The existing suites pass unchanged —
`test_agent_status.py` 99, whose one-nudge checks are two-in-a-row cases that end the same way,
`test_file_history.py` 45, `test_loop_guards.py` 12, `test_quant_registry.py` 39,
`test_retry_record.py` 14, `test_shell_tools.py` 35 — 262 checks across seven files.
