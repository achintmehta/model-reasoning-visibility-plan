#!/usr/bin/env bash
# run_thinking_batch.sh — run the study for one or more models, one run at a time,
# through run_one_with_server.sh.
# (Named run_quantization_batch.sh until plan v2.5.13: older plan text, logs, backups and
# one-off patchers use that name.)
#
#   ./run_thinking_batch.sh smoke <model-key> [<model-key> ...]   # smoke runs: 1 per arm per condition
#   ./run_thinking_batch.sh       <model-key> [<model-key> ...]   # the real study grid (blind layout)
#
#   ./run_thinking_batch.sh smoke gemma-q4 qwen-q4
#   ./run_thinking_batch.sh gemma-q4
#
# The first call for a given set writes the ordered schedule to batch-state/ (one line per
# run) and never regenerates it — delete the file deliberately if you want a new one.
# Re-running the same command RESUMES: finished runs are skipped; a run whose runner exited
# non-zero (server/serving/crash) is retried, up to 3 attempts, then marked void. Before each
# run it waits while free disk space under the output root is below MIN_FREE_GB, so you can
# move runs off and delete them mid-batch. Touch batch-state/STOP to stop after the current run.
#
# Order: one model at a time; within each task × condition block the arms rotate
# OFF, UNSEEN, SEEN for every replicate. Smokes: classic layout under SMOKE_ROOT/<model>.
# Real runs: blind layout under STUDY_ROOT/<model>, the cell recorded only in the key file.
#
# Environment: SMOKE_ROOT (/tmp/runs/smokes), STUDY_ROOT (/tmp/runs/study), MIN_FREE_GB (20),
# REPLICATES (16), RETRY_DELAY_S (60); everything the runner reads is inherited untouched.

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUNNER="${RUNNER:-$SCRIPT_DIR/run_one_with_server.sh}"
STATE_DIR="${STATE_DIR:-$SCRIPT_DIR/batch-state}"
SMOKE_ROOT="${SMOKE_ROOT:-/tmp/runs/smokes}"
STUDY_ROOT="${STUDY_ROOT:-/tmp/runs/study}"
MIN_FREE_GB="${MIN_FREE_GB:-20}"
REPLICATES="${REPLICATES:-16}"
RETRY_DELAY_S="${RETRY_DELAY_S:-60}"
KEY_FILE="${BLIND_KEY_FILE:-$SCRIPT_DIR/blind-state/blind-key.jsonl}"
STOP_FILE="$STATE_DIR/STOP"
LOG="$STATE_DIR/batch.log"

# Arms per model (plan §4.2). Add "off" to a two-arm model only after a canary proves it.
# magistral's off rung (retired, plan v2.5.9) was the ABSENCE of its thinking preamble, not a
# template switch (see THINK_KIND=system_preamble in the runner); the 2026-09-20 smokes
# measured 0/36 reasoning steps without it. seed-q4's off rung is thinking_budget:0, which
# suppresses real reasoning but left 55% of steps empty in the first smoke set — keep it
# here only while the replay-off probe stands.
declare -A ARMS=(
  [gemma-q4]="off unseen seen"
  [qwen-q4]="off unseen seen"
  [seed-q4]="off unseen seen"
  # Magistral-Small-2509 LEFT THE GRID in plan v2.5.9 and is NOT listed here, for the reason
  # every retired model is not. On its re-smoke it finished 3 of 9 runs: all three OFF runs
  # stopped at step 2 writing their plan and files as prose, and two SEEN runs died writing
  # their tool calls as text (plan §5, §5.1). It stays in the wrapper's model map and
  # verify_smokes.py's tables so its runs can be re-made and re-verified by name.
  # gpt-oss-20b is BACK in the grid as of plan v2.5.7, after v2.5.6 removed it by mistake (the
  # model meant was Magistral). No off-switch, so two arms. Its re-smoke under the v2.5.6
  # briefing ran commands and voided 2 of its 4 execution and interactive runs on harmony
  # parse failures, one in each arm. That briefing, withdrawn in plan v2.5.9, is back in
  # plan v2.5.10, and the smoke of all seven grid models under it decides whether it stays.
  [gptoss-20b]="unseen seen"
  # GLM-4.7-Flash -- the roster's sixth model as of plan v2.5.0 (2026-09-25): three arms,
  # keep-history flag clear_thinking:false, live probe +158 chars, smoked, and registered in
  # verify_smokes.py's EXPECTED_* tables like the five above.
  [glm-q4]="off unseen seen"
  # Mixture-of-experts twins of qwen-q4 and gemma-q4 -- proposed in plan v2.5.2; probed,
  # smoked and registered in v2.5.4; in the GRID since v2.5.5, as tier 5. Three arms each, on
  # their siblings' switch, bodies and sampling by construction (see the wrapper); the Gemma
  # twin's context window is its own since v2.5.4.
  [qwen-moe-q4]="off unseen seen"
  [gemma-moe-q4]="off unseen seen"
  # Muse Glimmer 30B (Meta) -- wired in plan v2.5.19, piloted, and in the GRID since plan
  # v2.5.20, as tier 6. Two arms, because its reasoning strength has no off level (as gpt-oss's
  # effort has none). Live probe +232 chars, marker test ACCEPTED, six-run pilot clean.
  [muse-q4xl]="unseen seen"
  # EXAONE was the standby until v2.3.13 and is NOT listed here on purpose. Its GGUF is not
  # on this machine, and its template reads skip_think (default true) rather than the
  # preserve_thinking it would inherit from this wrapper, so its SEEN arm would render no
  # past reasoning even if the file existed (plan §5). It stays in the wrapper's model map
  # so it can be named deliberately; it must not ride along in a batch. Leaving it here
  # cost a 60-run smoke nine unsatisfiable runs, discovered at run 43.
  # Granite 4.2-30B was RETIRED in plan v2.4.4 and, since v2.5.5, is NOT listed here either,
  # for the reason EXAONE and Nemotron are not: a retired model must not ride along in a
  # batch. Its SEEN arm finished 0 of 3 under two decoders, every run spending its whole
  # 32,768-token reply allowance in a repetition loop (plan §5, §5.1). It stays in the
  # wrapper's model map and in verify_smokes.py's EXPECTED_* tables, so its runs can be
  # re-made and re-verified by name.
  # Nemotron-3-Nano-30B-A3B was RETIRED in plan v2.5.1 and is NOT listed here, on purpose, for
  # the reason EXAONE is not: a retired model must not ride along in a batch. With thinking
  # OFF it wrote its own JSON agent protocol instead of tool calls in 11 of 15 runs, and none
  # of its finished runs ran what it had built (plan §5). It stays in the wrapper's model map
  # so the probe, smoke and nemotron_off_diag.sh runs behind that decision can be re-made.
)
TASKS=(message-board kanban-board)
CONDITIONS=(no_verification execution interactive)

say() { printf '[%s] %s\n' "$(date '+%m-%d %H:%M:%S')" "$*" | tee -a "$LOG"; }
die() { say "FATAL: $*" >&2; exit 1; }
arm_digit() { case "$1" in off) echo 1;; unseen) echo 2;; seen) echo 3;; esac; }

# ---- arguments -----------------------------------------------------------------------
MODE=real
[ "${1:-}" = smoke ] && { MODE=smoke; shift; }
[ $# -ge 1 ] || die "usage: $0 [smoke] <model-key> [<model-key> ...]   (known: ${!ARMS[*]})"
for m in "$@"; do [ -n "${ARMS[$m]:-}" ] || die "unknown model key '$m' (known: ${!ARMS[*]})"; done
MODELS=("$@")

# MODEL-FILE PREFLIGHT. A missing GGUF is discovered by the runner, which means it is
# discovered at that model's FIRST RUN -- run 43 of 60, hours in -- and then three times
# over, because the retry loop cannot tell a deterministic failure from a flaky one and
# sleeps 60s between attempts. Every model in the batch is resolvable in under a second
# before anything starts, so resolve them. Same reasoning as the engine preflight in the
# runner: the checks that save the most time are the ones that run first.
_pf_plain="$(sed -n '/^PLAIN_BODY=/,/^}/p' "$RUNNER")"
_pf_resolve="$(sed -n '/^resolve_model()/,/^}/p' "$RUNNER")"
_pf_root="$(sed -n 's/^MODELS_ROOT_WSL=.*:-\(.*\)}"$/\1/p' "$RUNNER" | head -1)"
_pf_root="${MODELS_ROOT:-${_pf_root:-/mnt/d/llm_models/LM Studio/unsloth}}"
_pf_missing=""
for m in "${MODELS[@]}"; do
  _pf_rel="$(eval "$_pf_plain"; eval "$_pf_resolve"; resolve_model "$m" >/dev/null 2>&1 \
             && printf '%s' "$GGUF_REL")"
  [ -n "$_pf_rel" ] || { _pf_missing+=$'\n'"  $m: not in the runner's model map"; continue; }
  case "$_pf_rel" in /*) _pf_abs="$_pf_rel" ;; *) _pf_abs="$_pf_root/$_pf_rel" ;; esac
  if [ -f "$_pf_abs" ]; then
    say "model ok: $m -> $_pf_abs"
  else
    _pf_missing+=$'\n'"  $m: $_pf_abs"
  fi
done
[ -z "$_pf_missing" ] || die "model file(s) missing — nothing has been run:$_pf_missing
     Download them, point MODELS_ROOT at the right parent, or drop those keys from the
     command. A batch that starts without them fails at that model's first run, after
     everything before it has already been spent."

# ---- schedule: seq  model  task  condition  arm  classic_id  label ---------------------
gen_schedule() {
  local seq=0 m task cond arm r i d
  for m in "${MODELS[@]}"; do
    if [ "$MODE" = smoke ]; then
      i=0
      for cond in "${CONDITIONS[@]}"; do
        for arm in ${ARMS[$m]}; do
          task="${TASKS[$(( i % ${#TASKS[@]} ))]}"; i=$((i+1)); d="$(arm_digit "$arm")"; seq=$((seq+1))
          printf '%s\t%s\t%s\t%s\t%s\t%s01\tsmoke/%s/%s/%s/%s\n' "$seq" "$m" "$task" "$cond" "$arm" "$d" "$m" "$task" "$cond" "$arm"
        done
      done
    else
      for task in "${TASKS[@]}"; do
        for cond in "${CONDITIONS[@]}"; do
          for r in $(seq 1 "$REPLICATES"); do
            for arm in ${ARMS[$m]}; do
              d="$(arm_digit "$arm")"; seq=$((seq+1))
              printf '%s\t%s\t%s\t%s\t%s\t%s%02d\t%s/%s/%s/%s/r%02d\n' "$seq" "$m" "$task" "$cond" "$arm" "$d" "$r" "$m" "$task" "$cond" "$arm" "$r"
            done
          done
        done
      done
    fi
  done
}

# ---- helpers ---------------------------------------------------------------------------
wait_for_disk() {   # $1 = output root
  mkdir -p "$1"
  while :; do
    local free; free="$(df -BG --output=avail "$1" 2>/dev/null | tail -n 1 | tr -dc '0-9')"
    [ "${free:-0}" -ge "$MIN_FREE_GB" ] && return 0
    say "only ${free:-0} GB free under $1 (need $MIN_FREE_GB) — waiting; move runs off and delete them, re-checking every 5 min"
    sleep 300
  done
}
last_status() { awk -F'\t' -v s="$1" '$1==s {st=$2; at=$3} END {if (st!="") print st "\t" at}' "$2"; }

# The configuration a frozen schedule was generated FROM. A schedule file is deliberately
# never regenerated (that is the point of freezing it), but if the arm map, task list,
# condition list or replicate count changes afterwards, re-running the same command would
# quietly execute the OLD grid. This signature turns that into a hard stop instead.
sched_signature() {
  { printf 'mode=%s\n' "$MODE"
    printf 'replicates=%s\n' "$REPLICATES"
    printf 'tasks=%s\n' "${TASKS[*]}"
    printf 'conditions=%s\n' "${CONDITIONS[*]}"
    for m in "${MODELS[@]}"; do printf 'arms[%s]=%s\n' "$m" "${ARMS[$m]}"; done
    # The runner's own bytes, because the arm map here is only half the configuration:
    # the other half -- which model file, which chat_template_kwargs each arm sends, which
    # preamble -- lives in run_one_with_server.sh. Adding preserve_thinking to Gemma's and
    # Qwen's bodies changed the treatment without touching anything above, and nothing here
    # would have noticed. Post-freeze the runner does not change at all, so this is only
    # ever a real alarm; pre-freeze you are deleting these files anyway.
    printf 'runner=%s\n' "$(sha256sum "$RUNNER" 2>/dev/null | cut -d' ' -f1)"
  } | sha256sum | cut -d' ' -f1
}

# The status this run would be skipped on, before the loop starts. Mirrors the case
# statement in the loop, including "failed 3 times" counting as void.
skip_status() {   # $1 = seq
  local st at
  IFS=$'\t' read -r st at <<< "$(last_status "$1" "$PROG")"
  case "${st:-}" in
    done) echo done ;;
    void) echo void ;;
    failed) [ "${at:-0}" -ge 3 ] && echo void || echo pending ;;
    *) echo pending ;;
  esac
}

# ---- main -------------------------------------------------------------------------------
mkdir -p "$STATE_DIR"
[ -x "$RUNNER" ] || die "runner not found or not executable: $RUNNER"
NAME="$MODE-$(IFS=-; echo "${MODELS[*]}")"
SCHED="$STATE_DIR/schedule-$NAME.tsv"
PROG="$STATE_DIR/progress-$NAME.tsv"
SIG="$STATE_DIR/schedule-$NAME.sig"
sig_now="$(sched_signature)"
if [ ! -f "$SCHED" ]; then
  gen_schedule > "$SCHED"
  printf '%s\n' "$sig_now" > "$SIG"
  say "generated $SCHED — sha256 $(sha256sum "$SCHED" | cut -c1-16)… (freeze this before the first real run)"
elif [ "$(cat "$SIG" 2>/dev/null || echo none)" != "$sig_now" ]; then
  say "FATAL: $SCHED was frozen from a DIFFERENT configuration."
  say "  The arm map, task list, condition list, replicate count or the RUNNER ITSELF has"
  say "  changed since it was written, so running it now would execute the OLD grid — a model"
  say "  that has since gained a third arm would still be run on two, and a change to what an"
  say "  arm SENDS would not show up here at all. Either restore the old configuration,"
  say "  or start this set over:"
  say "      rm -f $SCHED $SIG $PROG"
  say "  (move or delete that set's runs under the output root first)."
  exit 1
fi
touch "$PROG"
TOTAL="$(wc -l < "$SCHED")"; DONE_N=0; VOID_N=0

# What is actually left to do. Without this, a set whose runs are all done or all void
# prints "finished: 0 done, 6 void" in under a second and looks like it ran — which is
# exactly how the first gpt-oss re-smoke silently did nothing after its cause was fixed.
PENDING=0; PRE_DONE=0; PRE_VOID=0
while IFS=$'\t' read -r seq _rest; do
  [ -n "${seq:-}" ] || continue
  case "$(skip_status "$seq")" in
    done) PRE_DONE=$((PRE_DONE+1)) ;;
    void) PRE_VOID=$((PRE_VOID+1)) ;;
    *)    PENDING=$((PENDING+1)) ;;
  esac
done < "$SCHED"
say "$MODE runs for ${MODELS[*]}: $TOTAL scheduled — $PENDING to run, $PRE_DONE already done, $PRE_VOID void; progress in $PROG"
if [ "$PENDING" -eq 0 ]; then
  say "NOTHING TO DO — every scheduled run is already done or void."
  say "  A VOID run is one that failed three times; it is never retried, so fixing whatever"
  say "  broke it does NOT make this command run it again. To redo this set from scratch:"
  say "      rm -f $SCHED $SIG $PROG"
  say "  (move or delete that set's runs under the output root first)."
  exit 0
fi

while IFS=$'\t' read -r seq model task cond arm cid label; do
  [ -n "${seq:-}" ] || continue
  if [ -e "$STOP_FILE" ]; then say "STOP file present — stopping before run $seq"; rm -f "$STOP_FILE"; break; fi
  IFS=$'\t' read -r st at <<< "$(last_status "$seq" "$PROG")"; st="${st:-}"; at="${at:-0}"
  case "$st" in
    done) DONE_N=$((DONE_N+1)); continue ;;
    void) VOID_N=$((VOID_N+1)); continue ;;
    failed) [ "$at" -ge 3 ] && { VOID_N=$((VOID_N+1)); continue; } ;;
  esac
  if [ "$MODE" = smoke ]; then root="$SMOKE_ROOT/$model"; blind=0; args=("$model" "$task" "$cond" "$cid")
  else                         root="$STUDY_ROOT/$model"; blind=1; args=("$model" "$task" "$cond" "$label"); fi
  wait_for_disk "$root"
  while :; do
    at=$((at+1))
    say "run $seq/$TOTAL  $label  (attempt $at)"
    # stdin from /dev/null: this loop's stdin is the schedule file itself.
    ARM="$arm" BLIND="$blind" OUTPUT_ROOT="$root" "$RUNNER" "${args[@]}" </dev/null
    rc=$?
    id="$cid"
    [ "$blind" = 1 ] && id="$(tail -n 1 "$KEY_FILE" 2>/dev/null | grep -F "\"label\": \"$label\"" | grep -o '"blind_id": "[0-9]*"' | grep -o '[0-9]*')"
    if [ "$rc" -eq 0 ]; then
      printf '%s\tdone\t%s\t0\t%s\t%s\n' "$seq" "$at" "${id:-?}" "$(date -Is)" >> "$PROG"; DONE_N=$((DONE_N+1)); break
    fi
    printf '%s\tfailed\t%s\t%s\t%s\t%s\n' "$seq" "$at" "$rc" "${id:-?}" "$(date -Is)" >> "$PROG"
    if [ "$at" -ge 3 ]; then
      printf '%s\tvoid\t%s\t%s\t%s\t%s\n' "$seq" "$at" "$rc" "${id:-?}" "$(date -Is)" >> "$PROG"
      say "run $seq VOID after 3 failed attempts (rc=$rc) — continuing"; VOID_N=$((VOID_N+1)); break
    fi
    # KEEP THE FAILED ATTEMPT (plan v2.5.9). In the classic smoke layout every attempt writes
    # the same run directory, so a retry used to overwrite the failed one -- and with it the
    # server log line recording what the model produced. Move it aside first, out of the
    # runs/ tree the gates read, so that every failure stays countable per arm. (A blind grid
    # run draws a fresh id per attempt, so its failed attempts are kept already.)
    if [ "$blind" = 0 ]; then
      rdir="$root/$task/$cond/runs/$cid"
      if [ -d "$rdir" ]; then
        keep="$root/$task/$cond/failed-attempts/$cid.attempt$at"
        [ -e "$keep" ] && keep="$keep.$(date +%s)"
        mkdir -p "$(dirname "$keep")" && mv "$rdir" "$keep" && say "failed attempt $at kept -> $keep"
      fi
    fi
    say "run $seq failed (rc=$rc); retrying in ${RETRY_DELAY_S}s"; sleep "$RETRY_DELAY_S"
  done
done < "$SCHED"

say "finished: $DONE_N done, $VOID_N void, of $TOTAL ($MODE, ${MODELS[*]})"
