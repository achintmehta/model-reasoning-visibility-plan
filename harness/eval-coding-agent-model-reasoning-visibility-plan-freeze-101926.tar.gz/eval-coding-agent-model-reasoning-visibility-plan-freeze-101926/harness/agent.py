"""
harness/agent.py
================

The heart of the harness: the agent loop, and the command-line entry point for a single
run.

WHAT AN "AGENT LOOP" IS
-----------------------
A language model on its own only maps text to text. To make it *act* — create files, run
code, look at results — you wrap it in a loop that:
    1. sends the conversation so far plus a menu of tools the model may call,
    2. reads the model's reply, which may include tool calls,
    3. executes those tool calls and appends their results to the conversation,
    4. repeats, so the model can see each result and decide what to do next,
    5. stops when the model says it's done, makes no tool call, or hits a budget cap.
run_agent() below is exactly that loop, and it is intentionally small and readable —
because for this study the loop must be fully understood and free of hidden behavior.

WHAT MAKES THIS A RESEARCH INSTRUMENT, NOT JUST AN AGENT
--------------------------------------------------------
- The system prompt is a single fixed constant (SYSTEM_PROMPT), identical for every model
  and every condition. It deliberately says nothing about architecture, error handling,
  styling, or testing — those are the OUTCOMES we measure, so prescribing them would
  defeat the purpose. It also never tells the model to verify its work; whether it CAN is
  determined solely by the tools the condition grants.
- The only thing that varies between conditions is the tool list passed to the model.
- Every request, response, and tool result is logged in full (see runlog.py).
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import time
from pathlib import Path

from .browser import browser_launch_config
from .conditions import (tools_for, VISION_CONDITIONS, DELAYED_UNLOCK,
                         CONDITION_BRIEFINGS, UNIVERSAL_BRIEFING)
from .llm import (RealClient, MockClient, Turn, DECODING_DEFAULTS, validate_samplers,
                  validate_extra_body)
from .runlog import RunLog, sha
from .tools import Tools, SCHEMAS


def _same_value(a, b) -> bool:
    """Numeric-aware equality: 64 and 64.0 are the same sampler value; None is not 0."""
    if a is None or b is None:
        return a is None and b is None
    try:
        return float(a) == float(b)
    except (TypeError, ValueError):
        return a == b


def _decoding_overridden(args, profile) -> dict:
    """{param: {"run": sent, "registry": registered}} for every decoding param that
    differs from what the study registered (plan 42 v2.5.31)."""
    if profile:
        want = {k: profile.get(k) for k in
                ("temperature", "top_p", "top_k", "min_p", "presence_penalty")}
        want["max_tokens"] = DECODING_DEFAULTS["max_tokens"]
        sent = {"temperature": args.temperature, "top_p": args.top_p,
                "top_k": args.top_k, "min_p": args.min_p,
                "presence_penalty": args.presence_penalty,
                "max_tokens": args.max_tokens}
    else:
        want = {k: DECODING_DEFAULTS[k] for k in ("temperature", "top_p", "max_tokens")}
        sent = {"temperature": args.temperature, "top_p": args.top_p,
                "max_tokens": args.max_tokens}
    return {k: {"run": sent[k], "registry": want[k]}
            for k in want if not _same_value(sent[k], want[k])}


def _decode_param(s: str):
    """argparse type for --temperature / --top-p.

    Returns a float, or None when the user passes 'none'/'omit'/'off'. None tells
    RealClient to leave the field out of the request body entirely — needed for models
    that have deprecated the parameter and 400 on any request that sends it.  Omitting
    a decoding param is itself a deviation from the study registry, so the run is
    still stamped decoding_overridden.
    """
    if s.strip().lower() in ("none", "omit", "off", "null"):
        return None
    return float(s)


# =============================================================================
# The single, constant system prompt template.
# -----------------------------------------------------------------------------
# Held identical across EVERY model and condition. Note what it does NOT say: nothing
# about how to structure code, handle errors, style a UI, or write tests, and no
# instruction to verify. Those omissions are intentional — what fills those silences is
# precisely what the study measures, and it must come from the model + its tools, not
# from the prompt.
#
# The ONE piece of context we do inject is the workspace path. Without it, a model
# trying to start a server or run a command guesses paths like /workspace or /tmp and
# fails immediately — that's an environment bug, not a behavior we want to measure.
# Telling the model where it is is infrastructure, not a treatment variable.
#
# SYSTEM_PROMPT_TEMPLATE has {workspace} as the only placeholder; the actual constant
# used for hashing and logging is built in build_messages() with the real path.
# =============================================================================
# The base template is TOOL-NEUTRAL: it must read identically sensibly for every
# condition. Condition-specific tool orientation lives in conditions.CONDITION_BRIEFINGS
# and is appended by build_messages(); the manifest hashes base and briefing separately
# (base_prompt_sha / condition_briefing_sha) so verify_inputs.py can prove the base was
# constant and each briefing matches the registered constant for its condition.
# (An earlier revision named run_background_command here — condition-specific text in
# the constant base; that sentence now lives in the shell-condition briefings.)
SYSTEM_PROMPT_TEMPLATE = (
    "You are a software engineer. Your workspace directory is {workspace}. "
    "Implement the task described by the user by creating files in the workspace "
    "using the provided tools. Work until the task is complete, "
    "then call finish. Use only the tools provided to you."
)


# Model-family thinking preambles.
#
# A few open-weight models expose no thinking switch through the chat template at all:
# their reasoning is driven by the SYSTEM PROMPT that the template injects only when the
# caller supplies none. This harness always supplies its own system prompt, so on those
# models the template's reasoning instructions are displaced and the model never thinks.
# That is measured, not assumed: across the 2026-09-20 smoke set, 36 of 36
# Magistral-Small-2509 responses came back with an empty reasoning_content and no [THINK]
# in the content, in BOTH the replayed and the discarded arm — i.e. the arms were the same
# condition under two names.
#
# --think-preamble appends one of the blocks below to the system prompt. It is a TREATMENT
# setting (on such a model it is what turns thinking on), recorded per run as
# think_preamble_key / think_preamble_sha and folded into system_prompt_sha. Only registry
# KEYS are accepted: arbitrary prompt text must never reach a study run through a command
# line, and adding a preamble is a code change, so it moves harness_git.
THINK_PREAMBLES = {
    # Mistral's documented system prompt for Magistral-Small-2509 and -2507, verbatim from
    # the model card. One caveat worth knowing before you pick it: the Markdown/LaTeX
    # sentence is the only one here that speaks to output FORMAT rather than to thinking,
    # and "answered in Markdown prose instead of calling write_file" is an observed
    # Magistral failure mode (one smoke produced 25,626 characters of it and no tool call).
    # If that sentence costs tool calls, use "mistral-min" and say so in the write-up.
    "mistral": (
        "First draft your thinking process (inner monologue) until you arrive at a "
        "response. Format your response using Markdown, and use LaTeX for any "
        "mathematical equations. Write both your thoughts and the response in the same "
        "language as the input.\n\n"
        "Your thinking process must follow the template below:"
        "[THINK]Your thoughts or/and draft, like working through an exercise on scratch "
        "paper. Be as casual and as long as you want until you are confident to generate "
        "the response. Use the same language as the input.[/THINK]"
        "Here, provide a self-contained response."
    ),
    # The same thinking protocol with the formatting sentence removed — a deliberate
    # deviation from the vendor text, registered here so it is auditable as one rather
    # than improvised at a command line.
    "mistral-min": (
        "First draft your thinking process (inner monologue) until you arrive at a "
        "response.\n\n"
        "Your thinking process must follow the template below:"
        "[THINK]Your thoughts or/and draft, like working through an exercise on scratch "
        "paper. Be as casual and as long as you want until you are confident to generate "
        "the response.[/THINK]"
        "Here, provide a self-contained response."
    ),
}


# HOW a replayed thought is carried back to the model.
#
# "field" is the normal route: set `reasoning_content` on the assistant message and let the
# server and template put it where that model keeps thinking. It works for Gemma, Qwen,
# Seed-OSS and gpt-oss.
#
# "inline-think" exists because it does NOT work for Magistral, and fails in the worst
# possible way. Magistral's template has no branch for a reasoning field at all, and when
# one is sent anyway llama.cpp DELETES the assistant's own prose and adds nothing — so the
# arm meant to show the model MORE of its history shows it strictly LESS. Measured against
# the live server: the SEEN prompt came back 42 characters shorter than UNSEEN, exactly the
# two assistant contents, with neither reasoning string present.
#
# Magistral's reasoning is not a separate field in the first place. It lives inline in the
# reply as [THINK]…[/THINK] — those are the bytes the model emits, and llama.cpp parses
# them apart into reasoning_content on the way in. "inline-think" simply puts them back the
# way the model wrote them, which its template renders correctly (verified: content kept,
# both turns' reasoning present). It is the vendor's own wire format, not an invention, and
# it is recorded per run as `replay_format` so no reader has to guess which route was used.
REPLAY_FORMATS = ("field", "inline-think")


# plan 42 v2.5.37: REASONING LEFT IN THE REPLY TEXT. The server splits a reply into reasoning
# and text at the reasoning block's OPENING tag (or at the start, when the chat template opens
# the block itself). A model that starts thinking without writing the opening tag therefore
# gets its whole thought filed as reply text, closing tag and all:
#     "Now let's set up the backend ... </seed:think>\n\nLet's create the directories:"
# arrives with an empty reasoning field. In the certifying smoke of 2026-10-04 Seed-OSS-36B
# did this on 75 of its 131 UNSEEN steps (2 of 23 OFF, none in SEEN), and the next request's
# rendered prompt carried that thinking word for word -- so the UNSEEN arm, defined by past
# reasoning NOT being shown again, showed it.
#
# The harness does here what the server would have done had the opening tag been written:
# everything up to the LAST closing tag is reasoning, and what follows it is the reply. A
# reply that opens a block and never closes it (cut off mid-thought) is split at the opening
# tag. The rule names tags, not models, and applies to every turn of every arm, before the
# turn is counted, replayed or discarded -- so recovered reasoning is treated exactly as
# reasoning the server split. The server's own message stays untouched in the trace (`raw`);
# the trace's `text` is the reply as kept, and each split is recorded in the trace row and
# counted in the manifest.
#
# plan 42 v2.5.38: Gemma 4's thought channel too. Gemma keeps reasoning in a channel,
# `<|channel>thought ... <channel|>`, and in the smoke of 2026-10-05 a Gemma-4-26B-A4B OFF
# reply began `<|channel>` and ran to the reply cap inside it, filed as reply text. Its channel
# tags are split at like the think tags, and the channel's name ("thought") is dropped with
# the opening tag.
#
# plan 42 v2.5.39: the opening tag counts only WITH its name, `<|channel>thought`, which is
# how a Gemma thought begins. A bare `<|channel>` is not one: in the smoke of 2026-10-06 a
# Gemma-4-26B-A4B reply was a TOOL CALL opened with `<|channel>` instead of `<|tool_call>`
# (`<|channel>call:run_command{...}<tool_call|>`), and splitting there filed the call as
# reasoning, so in OFF and UNSEEN it vanished from the history. A call written as text stays
# in the reply, as it does for every model, and is counted as such. gpt-oss's channels (`<|channel|>`, `<|message|>`) are a different syntax
# and are NOT split here; gate G4 fails on any of them left in the reply text.
REASONING_CLOSERS = ("</seed:think>", "</think>", "[/THINK]", "<channel|>")
REASONING_OPENERS = ("<seed:think>", "<think>", "[THINK]", "<|channel>thought")
_GEMMA_CHANNEL_OPEN = re.compile(r"<\|channel>(?:thought[ \t]*\n?)?")


def split_reasoning_from_text(text):
    """Return (reply, recovered, marker).

    `marker` is the tag the split was made at, or None when the text holds no reasoning tag
    (then `reply` is `text` unchanged and `recovered` is None). `recovered` is the reasoning
    found in the text, tags removed and whitespace trimmed; it may be "" when only a stray
    tag was present."""
    if not text:
        return text, None, None
    end, marker = -1, None
    for m in REASONING_CLOSERS:
        i = text.rfind(m)
        if i >= 0 and i + len(m) > end:
            end, marker = i + len(m), m
    if marker is not None:
        head, reply = text[:end - len(marker)], text[end:]
    else:
        start = -1
        for m in REASONING_OPENERS:
            i = text.find(m)
            if i >= 0 and (start < 0 or i < start):
                start, marker = i, m
        if marker is None:
            return text, None, None
        head, reply = text[start:], text[:start]
    head = _GEMMA_CHANNEL_OPEN.sub("", head)
    for m in REASONING_OPENERS + REASONING_CLOSERS:
        head = head.replace(m, "")
    return reply.strip(), head.strip(), marker


# Fixed, condition-constant message injected when a delayed_verification run unlocks
# its tools on the first finish call. Part of the treatment definition for that
# condition; never sent in any other condition.
DELAYED_UNLOCK_MESSAGE = (
    "Your finish call is acknowledged, but the task is not yet accepted. "
    "Verification tools are now available to you (shell commands and background "
    "process management). Verify that your implementation actually works, fix any "
    "problems you find, and then call finish again."
)


# Substrings that only ever appear when a model is emitting a tool-call delimiter that
# the server's parser failed to recognise. Observed: Gemma 4 emitting a bare
# "<tool_call|>" (note the misplaced pipe) with tool_calls coming back empty.
_TOOL_DELIMITERS = ("<tool_call", "tool_call|>", "<|tool_call", "[TOOL_CALL]",
                    "<function=", "<function_call", "<tool▁call",
                    # Muse Glimmer's ATEM call markup (plan v2.5.19): <atem:function_calls>,
                    # <atem:invoke name=...>, <atem:parameter name=...>. Nothing but a call the
                    # server failed to parse ever leaves it in a reply.
                    "<atem:")

# Keys a model uses to name the tool when it improvises a call as plain JSON.
_TOOL_NAME_KEYS = ("action", "tool", "tool_name", "name", "function", "function_call")


def _tool_params(name: str) -> set:
    """The parameter names of one tool, from the schema actually advertised to the model."""
    fn = (SCHEMAS.get(name) or {}).get("function") or {}
    return set(((fn.get("parameters") or {}).get("properties") or {}))


def _brace_blocks(text: str):
    """Yield every balanced {...} span in `text`, outermost first.

    A regex cannot do this: a real tool call nests its arguments object, and
    `\\{[^{}]*\\}` would only ever match the innermost braces. Quotes and escapes are
    tracked so a brace inside a string literal does not throw the depth off.
    """
    depth = start = 0
    in_str = esc = False
    for i, ch in enumerate(text):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            if depth:
                depth -= 1
                if depth == 0:
                    yield text[start:i + 1]


def looks_like_tool_call_attempt(text: str | None, allowed: list[str]) -> bool:
    """True when assistant TEXT contains a tool call the provider failed to parse.

    This is malformation class 3 (see run_agent): the model tried to call a tool, the
    server returned tool_calls=[], and the attempt landed in `content` as prose. Left
    uncounted it looks identical to a model that simply narrated instead of acting —
    which is a completely different result, and one that would be scored against the
    model rather than against the serving stack.

    Deliberately conservative. A delimiter substring is unambiguous. A bare JSON object
    counts only when it names one of THIS run's allowed tools: a model quoting a
    package.json (which has a "name" key) must never be counted as a failed tool call.
    """
    if not text:
        return False
    if any(d in text for d in _TOOL_DELIMITERS):
        return True
    names = set(allowed)
    for blob in _brace_blocks(text):
        try:
            obj = json.loads(blob)
        except (ValueError, TypeError):
            continue
        if not isinstance(obj, dict):
            continue
        for key in _TOOL_NAME_KEYS:
            val = obj.get(key)
            if isinstance(val, str) and val in names:
                return True
        # A BARE ARGUMENTS OBJECT, with the tool's name nowhere in it. Magistral ends a run
        # with ```json {"summary": "Initialized the Kanban board project..."} — which is
        # finish's argument object and nothing else. The rule above cannot see it, because
        # there is no name key to match, so the model was scored as having narrated instead
        # of acting when it had in fact tried to call finish and failed to serialise it.
        # EXACT key-set equality, not a subset: a package.json has a "name" key and a dozen
        # others, and must never be counted. A blob whose keys are precisely some tool's
        # parameters is a call that lost its envelope.
        for nm in names:
            params = _tool_params(nm)
            if params and set(obj) == params:
                return True
    # THE ENVELOPE COLLAPSED ENTIRELY: "finishsummary:Created all necessary files..." —
    # tool name and parameter name concatenated with no JSON, no delimiter, nothing. Only
    # counted at the very START of the reply, which is what separates it from prose that
    # happens to mention a tool: a model narrating says "I will call finish", it does not
    # open with the identifier.
    head = (text or "").lstrip()
    for nm in sorted(names, key=len, reverse=True):
        if not head.startswith(nm):
            continue
        rest = head[len(nm):].lstrip(" :=\t\"'")
        if any(rest.startswith(p) for p in _tool_params(nm)):
            return True
    return False


# TypeError messages that mean "the arguments did not fit the tool's signature" as
# opposed to a failure inside the tool's own body. Matching on shape keeps the
# malformation count honest instead of absorbing every incidental TypeError.
_SIGNATURE_ERROR_MARKERS = ("unexpected keyword argument", "required positional argument",
                            "required keyword-only argument", "positional arguments but",
                            "takes no arguments", "multiple values for argument")


def build_messages(task: str, workspace: str = "", briefing: str = "",
                   think_preamble: str = "") -> list[dict]:
    """Assemble the initial conversation: system prompt (+ condition briefing) + task.

    The workspace path is infrastructure context (without it models guess /workspace or
    /tmp and burn steps). The briefing is the condition's registered environment
    description from conditions.CONDITION_BRIEFINGS — DESCRIPTIVE text about what tools
    exist, part of the treatment definition, hashed separately in the manifest. The
    TASK text must remain byte-identical across conditions; tool orientation never
    belongs in it.
    """
    system = SYSTEM_PROMPT_TEMPLATE.format(workspace=workspace or "the current directory")
    if briefing:
        system = system + "\n\n" + briefing
    # LAST, always: a registered thinking preamble (see THINK_PREAMBLES). Position is
    # fixed so system_prompt_sha is a function of the parts and nothing else.
    if think_preamble:
        system = system + "\n\n" + think_preamble
    return [
        {"role": "system", "content": system},
        {"role": "user", "content": task},
    ]


def run_agent(client, tools: Tools, condition: str, messages: list[dict],
              log: RunLog, max_steps: int = 40, vision: bool = False,
              verbose: bool = False, max_same_calls: int = 3, max_blocked_calls: int = 3,
              max_cycle_repeats: int = 3, max_repeat_steps: int = 6,
              interactive: bool = False, max_total_tokens: int = 0,
              replay_reasoning: bool = False,
              replay_format: str = "field") -> tuple[str, dict]:
    """Run the agent loop to completion and return the terminal status string.

    Args:
        client:    A RealClient (or MockClient) exposing .chat(messages, schemas) -> Turn.
        tools:     A Tools instance bound to this run's workspace.
        condition: The active condition name; determines which tool schemas are offered.
        messages:  The initial message list from build_messages(); mutated in place as the
                   conversation grows (this list IS the model's memory across turns).
        log:       The RunLog recording every request/response/tool-result.
        max_steps: Hard cap on loop iterations — the budget guard. Prevents a model that
                   never calls finish from looping forever, and is the lever for the
                   budget-normalization concern (a verification loop naturally uses more
                   steps, which must be controlled for in analysis).
        vision:    Whether this condition can receive images; if True, screenshots are
                   injected back to the model as image messages.

    Returns one of:
        "finished"             - the model called the finish tool (intended terminal state)
        "stopped_no_tool_call" - the model replied with no tool call TWICE IN A ROW: a turn
                                 without one, the finish nudge, and no tool call in the
                                 reply to the nudge either (plan v2.5.14; until then the
                                 second such turn anywhere in the run). Often it narrated
                                 code in prose instead of calling write_file — common with
                                 models whose tool-calling isn't properly enabled
        "runaway_no_tool_call" - the reply had no tool call and consumed the ENTIRE
                                 per-reply allowance (completion_tokens == max_tokens).
                                 Nothing cut it off; the model generated to the ceiling
                                 without acting. Usually a degenerate repetition loop
                                 inside one generation, which no loop guard can see
                                 because those count tool calls across steps and this
                                 emits none. truncation_detected carries the repetition
                                 measure so a loop is separable from a legitimately huge
                                 reply.
        "truncated_no_tool_call" - same shape, different cause: the reply had no tool call
                                 because it was CUT OFF at the token limit
                                 (finish_reason=length), not because the model chose to
                                 stop. Kept separate so an infrastructure fault (a server
                                 serving a smaller context than configured) is never
                                 scored as a model incapable of tool calling. The token
                                 counts are in the manifest's truncation_detected field.
        "context_overflow"     - (plan 42 v2.5.28) the conversation outgrew the context
                                 window: the server refused the next request (llama.cpp:
                                 HTTP 400, exceed_context_size_error) before generating.
                                 Set in main(), not here; an OUTCOME, so the process exits
                                 0 and the batch driver never re-runs it. The server's
                                 token counts are in the manifest's context_overflow field.
        "budget_exhausted"     - hit max_steps without finishing
        "stuck_blocked_tool"   - the model called an out-of-condition tool 3+ times in a
                                 row without recovery — common when a task explicitly
                                 requires a tool the condition doesn't grant (e.g. a task
                                 saying "take a screenshot" under --condition none).
                                 Fix: either change the task or use a condition that grants
                                 the required tool.
        "stuck_looping"        - one of the three loop guards fired. WHICH one is recorded
                                 in the manifest's loop_guard_fired field
                                 (same_calls | cycle | no_progress) with the step, so the
                                 three pathologies stay separable in analysis.
    """
    # Resolve the condition to its allowed tool names, then to the JSON schemas we'll send.
    # A tool not in this list is never advertised to the model — this is how the
    # experimental treatment is enforced at the most basic level.
    # DELAYED VERIFICATION: such conditions start with only their "pre" tools (file
    # authoring); the first finish call unlocks the "post" set instead of ending the
    # run. All other conditions resolve their tool list once, here.
    delayed = DELAYED_UNLOCK.get(condition)
    unlocked_at_step = None
    allowed = delayed["pre"] if delayed else tools_for(condition)
    schemas = [SCHEMAS[name] for name in allowed]

    # Stuck detection: track consecutive steps where the model only called blocked tools.
    # If it calls the same unavailable tool N times in a row, it's stuck and can't recover
    # — bail out rather than burning the entire step budget.
    consecutive_blocked = 0

    consecutive_same_calls = 0
    previous_tool_calls_json = None
    # Recent call-batch fingerprints for CYCLE detection. The identical-consecutive-call
    # guard above only catches period-1 loops (A,A,A). Observed in real runs: period-2
    # loops (A,B,A,B,...) — e.g. "pkill+rm" alternating with a re-run, or an apology +
    # `npm run dev` sample alternating with a log read — burn millions of tokens without
    # ever tripping it. We keep a short history and abort when the recent window is a
    # repetition of a 2-batch cycle.
    call_history: list[str] = []

    # NO-PROGRESS guard (third loop guard). The two guards above are ORDER-based: one
    # catches exact consecutive repeats (period 1: A,A,A,A), the other a strict
    # alternation (period 2: A,B,A,B,...). Observed failure that defeats BOTH: a model
    # rotating among a HANDFUL OF NEAR-IDENTICAL VARIANTS of the same failing action —
    # e.g. rewriting package.json with slightly different content each time while never
    # fixing the actual defect. Each variant resets the identical-call counter, and an
    # irregular period (A,A,B,A,A,B / three or more variants) is invisible to the cycle
    # detector. A real run burned 250+ steps this way without tripping either guard.
    #
    # This guard is CONTENT-based instead: a tool call whose (name, arguments) was
    # already made earlier in this run cannot be progress — the model is reproducing a
    # state it has already been in and already seen the result of. A step counts as a
    # "repeat step" only when EVERY call in it is such a revisit; any novel call resets
    # the counter. Legitimate iterative development always emits novel calls (new
    # content, new paths, new commands), so this does not fire on a model that is
    # actually working. Set max_repeat_steps=0 to disable.
    seen_calls: set[str] = set()
    consecutive_repeat_steps = 0

    # Which loop guard (if any) ended this run: same_calls | cycle | no_progress.
    # Recorded in the manifest so the three pathologies stay separable in analysis
    # while the terminal status stays the historical "stuck_looping".
    loop_guard_fired = None

    # The "finish nudge": a model that replies with NO tool call has either finished
    # (and narrated a summary instead of calling finish) or is confused. Originally this
    # immediately ended the run as stopped_no_tool_call, which CONFLATES protocol
    # noncompliance with task failure (several such runs produced fully working apps).
    # So the model is reminded to call finish or carry on. The nudge is condition-
    # independent protocol scaffolding, identical for every model and arm, and every one
    # is recorded in the manifest (finish_nudges, finish_nudge_steps).
    #
    # plan v2.5.14 -- AFTER EVERY SUCH TURN, NOT ONCE PER RUN. The nudge used to be given
    # once, and the second turn without a tool call ended the run wherever it fell. In the
    # 20M certifying smoke that ended three runs whose two such turns were 4, 7 and 21
    # steps apart, each working normally in between; one of them went quiet the second
    # time right after a diff had shown it the one-letter difference that was its bug. A
    # single empty reply -- one token, the end of the turn -- was deciding whole runs. Now every turn without a tool call is nudged,
    # with the same text, and the run ends only when the reply RIGHT AFTER a nudge has no
    # tool call either: the model has stopped responding, not paused. That stop is what
    # keeps a model that has gone quiet for good from being nudged until the token budget
    # ends it and files it as something else.
    finish_nudges = 0
    finish_nudge_steps: list[int] = []

    total_prompt_tokens = 0
    total_completion_tokens = 0
    first_finish_usage = None

    # Set when a turn came back with NO tool calls because it was cut off at the token
    # limit, rather than because the model chose to stop. See the truncated_no_tool_call
    # branch below for why the two must not be conflated.
    truncation_detected = None

    # How many turns carried provider-side reasoning text, and how much. Recorded so a
    # run's manifest shows whether the model was thinking at all — the difference between
    # "emitted nothing" and "thought at length and emitted nothing" is the difference
    # between a dead endpoint and a truncation, and it was previously invisible.
    reasoning_turns = 0
    # plan v2.5.37: turns whose reasoning was found in the reply text and moved to the
    # reasoning field (split_reasoning_from_text), its characters, and the tags split at.
    recovered_turns = 0
    recovered_chars = 0
    recovered_markers: dict[str, int] = {}
    reasoning_chars = 0
    # What was actually sent BACK, which differs from what was produced whenever a turn
    # carried no reasoning. Recorded separately so "replay was on" and "replay had
    # anything to carry" stay distinguishable — a model that emits no reasoning yields
    # replayed_turns == 0 with the flag still true, and that is a fact about the model,
    # not a misconfiguration.
    replayed_turns = 0
    replayed_chars = 0

    # TOOL-CALL MALFORMATION — the H1 mechanical-reliability measure. Three classes,
    # counted separately because they fail at three different layers and only the first
    # was ever visible before:
    #   1. unparseable_arguments — the arguments were not valid JSON (RealClient._parse
    #      stashes the raw string under "__raw__"). Usually truncation.
    #   2. invalid_arguments     — the JSON parsed but did not fit the tool's signature
    #      (observed at Q4: a selector string that swallowed the next key and its value,
    #      leaving `text` missing). Valid JSON, wrong shape.
    #   3. unparsed_in_content   — the model emitted a call the SERVER failed to parse,
    #      so tool_calls came back empty and the attempt sits in the assistant text.
    # Counting only. Nothing here changes what the model is sent.
    tool_call_attempts = 0
    malformed = {"unparseable_arguments": 0, "invalid_arguments": 0,
                 "unparsed_in_content": 0}
    tool_errors_other = 0        # TypeErrors from inside a tool body, not malformation

    # Every call dispatched to a tool result, numbered from 1: refused and malformed calls
    # included, since each is a result the model sees; class-3 attempts not, since they
    # never became a call. Handed to Tools as call_index before each call, so write_file
    # and edit_file can say how many calls ago a file was last left with the content it
    # has now (plan v2.5.13; Tools._file_state_note).
    tool_calls_dispatched = 0

    def capture_first_finish():
        nonlocal first_finish_usage
        if first_finish_usage is None:
            first_finish_usage = {
                "prompt_tokens": total_prompt_tokens,
                "completion_tokens": total_completion_tokens,
                "total_tokens": total_prompt_tokens + total_completion_tokens
            }

    human_turns = 0  # messages a human injected via --interactive (provenance!)

    def get_extra_data() -> dict:
        if first_finish_usage is None:
            capture_first_finish()
        return {
            "tokens_to_first_finish": first_finish_usage,
            "total_tokens_used": {
                "prompt_tokens": total_prompt_tokens,
                "completion_tokens": total_completion_tokens,
                "total_tokens": total_prompt_tokens + total_completion_tokens
            },
            # PROVENANCE: if a human ever typed feedback into this run (interactive
            # mode), the run is no longer an autonomous data point. Record it loudly so
            # analysis can exclude contaminated runs instead of discovering them by
            # reading traces. (Observed in past data: a run where a human reported
            # errors back to the model, which then swapped out the mandated database —
            # indistinguishable from autonomous behavior without this flag.)
            "human_turns": human_turns,
            "finish_nudges": finish_nudges,
            # plan v2.5.14: the step of every nudge. Since then a run can be nudged any
            # number of times, and the steps show whether its silences were isolated or
            # came in a cluster; a run ended by silence ends one step after the last.
            "finish_nudge_steps": list(finish_nudge_steps),
            "verification_unlocked_at_step": unlocked_at_step,
            # Which loop guard ended the run (None when it ended some other way), and
            # at which step. Keeps the three loop pathologies separable in analysis
            # without adding a new terminal status downstream tooling must learn.
            "loop_guard_fired": loop_guard_fired,
            # Populated only when the run ended as truncated_no_tool_call. Carries the
            # token counts that separate a server-side context ceiling (small prompt,
            # tiny completion, large max_tokens) from a model that exhausted its own
            # per-turn budget (completion_tokens at max_tokens).
            "truncation_detected": truncation_detected,
            "reasoning_turns": reasoning_turns,
            "reasoning_chars": reasoning_chars,
            # plan v2.5.37: reasoning the server left in the reply text, moved to the
            # reasoning field by the harness (and included in the two counts above).
            "reasoning_recovered_turns": recovered_turns,
            "reasoning_recovered_chars": recovered_chars,
            "reasoning_recovered_markers": dict(recovered_markers),
            # WHEN replay is on these stop being a pure audit trail and start describing
            # a treatment: the replayed reasoning is part of what the model saw. Kept as
            # separate fields so a run's own manifest says whether that was true of it.
            "reasoning_replayed": replay_reasoning,
            "reasoning_replayed_turns": replayed_turns,
            "reasoning_replayed_chars": replayed_chars,
            # H1's headline mechanical measure. `attempts` counts every tool call the
            # model emitted PLUS every attempt that never became one (class 3), so the
            # rate has an honest denominator.
            "tool_calls": {
                "attempts": tool_call_attempts,
                "malformed": sum(malformed.values()),
                "malformation_rate": (sum(malformed.values()) / tool_call_attempts
                                      if tool_call_attempts else 0.0),
                **malformed,
                "tool_errors_other": tool_errors_other,
            },
            # plan v2.5.13: the calls that got the file-state note -- a write or edit call
            # that left a file with bytes an earlier write or edit call of this run had
            # left it with (Tools._file_state_note). count: those calls; writes / edits:
            # by tool; reverts: those that changed the file, back to an earlier content
            # (the rest left it as it was); max_times: the most calls that left any one
            # file with any one content, 0 when the note never fired.
            "file_state_repeats": (dict(tools.file_state_repeats)
                                   if hasattr(tools, "file_state_repeats") else None),
        }

    def handle_interactive_pause(reason: str) -> bool:
        """Prompts the user. Returns True if the loop should continue, False to exit."""
        capture_first_finish()
        if not interactive:
            return False
        nonlocal human_turns
        try:
            print(f"\n[Agent Paused] {reason}")
            while True:
                user_input = input("User (Ctrl+C to exit): ")
                if user_input.strip():
                    messages.append({"role": "user", "content": user_input})
                    human_turns += 1
                    return True
        except KeyboardInterrupt:
            print("\nExiting interactive mode...")
            return False

    step_count = 0
    while step_count < max_steps or interactive:
        step_count += 1
        # ---- 1. Ask the model what to do next, given the conversation + allowed tools.
        # Name the handoff at the point it actually happens. This deliberately does
        # NOT live in the tool loop: a step can end at the finish tool or the token
        # budget, in which case no request follows and a 'sending' line printed back
        # there would be false. Here it is true by construction -- the next statement
        # is the request. The trailing run of role='tool' messages IS this step's
        # output, since anything else (assistant, user nudge) breaks the run.
        if verbose:
            _pending = []
            for _m in reversed(messages):
                if _m.get("role") != "tool":
                    break
                _pending.append(_m)
            if _pending:
                _chars = sum(len(_m.get("content") or "") for _m in _pending)
                print(f"[agent] sending {len(_pending)} tool response"
                      f"{'' if len(_pending) == 1 else 's'} to the model "
                      f"({_chars:,} chars)", flush=True)
        log.log_request(messages, schemas)
        _t0 = time.time()
        try:
            turn: Turn = client.chat(messages, schemas)
        except Exception as _e:
            # plan 42 v2.5.32: a request refused for outgrowing the context window ends
            # the run HERE, as the outcome context_overflow, so the run's summary (tokens,
            # reasoning, tool calls, guards) is kept like any other ending's. Until v2.5.32
            # the refusal propagated to main(), which recorded the status but lost every
            # figure get_extra_data() carries -- for a run that enters the analysis.
            _ov = getattr(_e, "harness_context_overflow", None)
            if not _ov:
                raise
            _x = get_extra_data()
            _x["context_overflow"] = dict(
                _ov, code=getattr(_e, "code", None),
                body=(getattr(_e, "harness_body", None) or str(_e))[:2000],
                at_step=step_count)
            return "context_overflow", _x
        api_latency = time.time() - _t0
        # plan v2.5.37: reasoning the server left in the reply text is moved to the
        # reasoning field HERE, before anything reads the turn, so it is counted, replayed
        # (SEEN) or discarded (UNSEEN, OFF) exactly as reasoning the server split itself.
        recovered_info = None
        _reply, _recovered, _marker = split_reasoning_from_text(turn.text)
        if _marker is not None:
            _had = bool(turn.reasoning and turn.reasoning.strip())
            recovered_info = {"marker": _marker, "chars": len(_recovered or ""),
                              "reasoning_field_too": _had}
            if _recovered:
                turn.reasoning = (turn.reasoning.rstrip() + "\n\n" + _recovered) if _had \
                    else _recovered
            turn.text = _reply or None
            recovered_turns += 1
            recovered_chars += len(_recovered or "")
            recovered_markers[_marker] = recovered_markers.get(_marker, 0) + 1
        if turn.usage:
            total_prompt_tokens += turn.usage.get("prompt_tokens", 0)
            total_completion_tokens += turn.usage.get("completion_tokens", 0)
        # .strip() guard repeated from RealClient._parse deliberately: reasoning_turns
        # is a recorded study measure, and a whitespace-only reasoning field (some
        # servers send "\n" every turn) must never inflate it regardless of which client
        # built the Turn.
        if turn.reasoning and turn.reasoning.strip():
            reasoning_turns += 1
            reasoning_chars += len(turn.reasoning)
        # Latency is recorded per step so analysis can separate provider/API time from
        # tool-execution time — wall-clock alone proved useless as a signal (identical
        # runs ranged from minutes to hours purely on provider latency).
        log.log_response(turn.raw, turn.text, turn.tool_calls, latency_s=api_latency,
                         reasoning_recovered=recovered_info)

        # ---- Token budget guard. Steps are a poor cost proxy (one step can be 200 or
        # 200k tokens); a runaway run was observed to burn >10M tokens before the step
        # cap mattered. When a total-token budget is set, enforce it here, identically
        # for every condition.
        if max_total_tokens and (total_prompt_tokens + total_completion_tokens) > max_total_tokens:
            return "token_budget_exhausted", get_extra_data()

        if verbose:
            print(f"\n--- Step {step_count} ---")
            if recovered_info:
                print(f"[reasoning] {recovered_info['chars']} chars of reasoning were in the "
                      f"reply text (split at {recovered_info['marker']}); moved to the "
                      f"reasoning field")
            # Show reasoning when the provider returns it separately from content. A turn
            # with reasoning but no content used to print as complete silence, which is
            # indistinguishable from a broken endpoint. Truncated for readability; the
            # full text is in the trace via turn.raw.
            if turn.reasoning and turn.reasoning.strip():
                _r = turn.reasoning.strip()
                print(f"Reasoning ({len(_r)} chars): "
                      f"{_r[:600]}{' ...[truncated]' if len(_r) > 600 else ''}")
            if turn.text:
                print(f"Assistant: {turn.text.strip()}")
            for c in turn.tool_calls:
                print(f"Tool Call: {c.name}({json.dumps(c.arguments)})")

        # ---- 2. Record the assistant's turn back into the running conversation.
        # We must echo tool calls in the exact OpenAI format so that, on the next request,
        # the model sees its own prior calls paired with the tool results we append below.
        assistant_msg = {"role": "assistant", "content": turn.text or ""}
        if turn.tool_calls:
            assistant_msg["tool_calls"] = [
                {"id": c.id or f"call_{i}", "type": "function",
                 "function": {"name": c.name, "arguments": json.dumps(c.arguments)}}
                for i, c in enumerate(turn.tool_calls)
            ]
        # REASONING REPLAY. When on, the model's own chain of thought goes back with the
        # turn that produced it, so its working memory survives to the next step instead
        # of being discarded the moment the tool call is extracted.
        #
        # Why this is not a frill: in the 2026-08 pilot, five runs looped because the
        # model confabulated a one-character defect in a file it had just written. Its
        # reasoning shows it NOTICING the loop — "I noticed I keep writing the same
        # index.html" — and that noticing was thrown away before the next step could act
        # on it. Whether replay actually breaks such loops is an open empirical question
        # the pilot must answer; what is not in question is that discarding reasoning is
        # a choice, and the deployment it claims to represent does not make that choice.
        # Anthropic and DeepSeek now REQUIRE the round-trip during tool use, so any
        # hosted arm would have to do this regardless.
        #
        # Recorded per run as `reasoning_replayed`, and it is a treatment: it changes what
        # the model sees. Frozen at pre-registration like everything else.
        if replay_reasoning and turn.reasoning and turn.reasoning.strip():
            if replay_format == "inline-think":
                # Reassemble the reply the way the model emitted it. Deliberately does NOT
                # also set reasoning_content: sending both is what makes llama.cpp discard
                # the content for this family.
                assistant_msg["content"] = (f"[THINK]{turn.reasoning}[/THINK]"
                                            + (assistant_msg.get("content") or ""))
            else:
                assistant_msg["reasoning_content"] = turn.reasoning
            replayed_turns += 1
            replayed_chars += len(turn.reasoning)
        messages.append(assistant_msg)

        # ---- 3. No tool calls => the model is done (or stuck): nudge it, or end the run
        # if this turn was already the reply to a nudge (plan v2.5.14, see finish_nudges).
        # This is also the failure signature when tool-calling isn't working: the model
        # "answers" in prose with no structured call.
        if not turn.tool_calls:
            # Malformation class 3: the model DID try to call a tool, the provider's
            # parser missed it, and the attempt is sitting in the text. Counted as both
            # an attempt and a malformation so it never reads as "the model narrated
            # instead of acting" — a model verdict for what is a parsing failure.
            if looks_like_tool_call_attempt(turn.text, allowed):
                tool_call_attempts += 1
                malformed["unparsed_in_content"] += 1
            # TRUNCATION IS NOT A DECISION TO STOP. A turn with no tool calls AND
            # finish_reason == "length" was cut off mid-emission; the model never got to
            # say what it wanted. Recording that as stopped_no_tool_call conflates an
            # infrastructure fault with a model-capability verdict — and that exact
            # conflation cost five runs of misattributed blame, where a model looked
            # incapable of tool calling but was in fact being served with a 4096-token
            # context it silently exceeded on step 4. Nudging here would only lengthen
            # the prompt that overflowed, so we stop and report the numbers instead.
            if turn.finish_reason == "length":
                _u = turn.usage or {}
                _ct = _u.get("completion_tokens")
                _mt = getattr(client, "max_tokens", None)
                # TWO OPPOSITE DIAGNOSES WEAR THE SAME finish_reason. If the completion
                # count is far BELOW max_tokens, something upstream cut the reply short --
                # the server's context window is the binding limit and the model is
                # blameless, which is the case this branch was written for. If it lands
                # exactly ON max_tokens, nothing cut anything: the model used every token
                # it was allowed and still produced no tool call. Recording both as
                # "truncated" made the second look like infrastructure, which is the very
                # misattribution this branch exists to prevent, pointed the other way.
                #
                # Granite's SEEN arm, 2026-09-23: three runs, completion exactly 32,768
                # against max_tokens 32,768, prompt only 7-9k of a 131k context, and zero
                # characters of visible output. 88,845 characters of reasoning, 3,531 lines
                # of which 360 were unique -- "Let me do it." 768 times, "Let me read
                # server.js." 440 times. A degenerate repetition loop INSIDE one reply.
                #
                # The repetition numbers are recorded rather than the conclusion: a reply
                # can legitimately fill its allowance (a very large file write), and the
                # ratio is what separates that from a loop. Below 20 lines it is noise and
                # is left null.
                _body = ((turn.reasoning or "") + "\n" + (turn.text or "")).split("\n")
                _lines = [l.strip() for l in _body if l.strip()]
                _counts = {}
                for _l in _lines:
                    _counts[_l] = _counts.get(_l, 0) + 1
                _top = max(_counts.items(), key=lambda kv: kv[1]) if _counts else ("", 0)
                _hit_cap = bool(_ct and _mt and _ct >= _mt)
                truncation_detected = {
                    "step": step_count,
                    "prompt_tokens": _u.get("prompt_tokens"),
                    "completion_tokens": _ct,
                    "max_tokens_requested": _mt,
                    "had_reasoning": bool(turn.reasoning),
                    "text_chars": len(turn.text or ""),
                    # True = the model spent its whole per-reply allowance; nothing
                    # external cut it off. False/None = something upstream did.
                    "hit_reply_cap": _hit_cap,
                    "lines": len(_lines),
                    "unique_lines": len(set(_lines)),
                    "repeat_ratio": (round(1 - len(set(_lines)) / len(_lines), 3)
                                     if len(_lines) >= 20 else None),
                    "most_repeated_line": _top[0][:120],
                    "most_repeated_count": _top[1],
                }
                print(f"[Agent] Response truncated at step {step_count} "
                      f"(finish_reason=length, prompt={_u.get('prompt_tokens')}, "
                      f"completion={_u.get('completion_tokens')}, "
                      f"max_tokens={getattr(client, 'max_tokens', None)}). If the "
                      f"completion count is far below max_tokens, the SERVER's context "
                      f"window is the binding limit, not the model.")
                # The status carries the distinction, because the status is what gets
                # COUNTED. A loop filed as a truncation understates the model's failure in
                # the study's own outcome table, and the loop guards cannot catch it --
                # MAX_SAME_CALLS, MAX_CYCLE_REPEATS and MAX_REPEAT_STEPS all count tool
                # calls ACROSS steps, and this pathology emits none at all, inside one.
                return ("runaway_no_tool_call" if _hit_cap else "truncated_no_tool_call",
                        get_extra_data())
            if handle_interactive_pause("Model stopped emitting tool calls."):
                continue
            # plan v2.5.14: nudge after every turn without a tool call; end the run only
            # when this turn is itself the reply to a nudge -- two in a row.
            if not (finish_nudge_steps and finish_nudge_steps[-1] == step_count - 1):
                finish_nudges += 1
                finish_nudge_steps.append(step_count)
                messages.append({
                    "role": "user",
                    "content": "You did not call any tool. If the task is complete, call "
                               "the finish tool now; otherwise continue working using the "
                               "provided tools.",
                })
                continue
            return "stopped_no_tool_call", get_extra_data()

        # ---- 4. Execute each tool call the model made, in order.

        # Check for exact repeated tool calls (e.g. failing edits over and over)
        current_calls_json = json.dumps(
            [{"name": c.name, "arguments": c.arguments} for c in turn.tool_calls],
            sort_keys=True
        )
        call_history.append(current_calls_json)
        # Keep enough history for the configured cycle window (never below the 8 used
        # historically, so period-1 / other heuristics are unaffected).
        cycle_window = 2 * max_cycle_repeats          # batches = (2-batch cycle) x repeats
        if len(call_history) > max(8, cycle_window):
            call_history.pop(0)
        # Period-2 cycle: the last `cycle_window` batches are `max_cycle_repeats` repetitions
        # of exactly two distinct alternating batches (A,B,A,B,...). Treated the same as a
        # period-1 loop. Configurable via --max-cycle-repeats (default 3 = the original
        # A,B,A,B,A,B window); set it to <2 to disable period-2 cycle detection entirely.
        if max_cycle_repeats >= 2 and len(call_history) >= cycle_window:
            w = call_history[-cycle_window:]
            evens, odds = w[0::2], w[1::2]
            if (all(x == evens[0] for x in evens) and all(x == odds[0] for x in odds)
                    and evens[0] != odds[0]):
                loop_guard_fired = {"guard": "cycle", "step": step_count}
                return "stuck_looping", get_extra_data()

        # NO-PROGRESS guard (see seen_calls above): every call this step was one the
        # model already made earlier in the run. Checked before the identical-call
        # guard's counter so the more specific period-1 label still wins for exact
        # loops (that guard trips first, at max_same_calls).
        if max_repeat_steps:
            novel = False
            for c in turn.tool_calls:
                try:
                    fp = json.dumps({"name": c.name, "arguments": c.arguments},
                                    sort_keys=True)
                except (TypeError, ValueError):
                    fp = f"{c.name}:{c.arguments!r}"
                if fp not in seen_calls:
                    novel = True
                    seen_calls.add(fp)
            if novel:
                consecutive_repeat_steps = 0
            else:
                consecutive_repeat_steps += 1
                if consecutive_repeat_steps >= max_repeat_steps:
                    loop_guard_fired = {"guard": "no_progress", "step": step_count,
                                        "distinct_calls_seen": len(seen_calls)}
                    return "stuck_looping", get_extra_data()

        if current_calls_json == previous_tool_calls_json:
            consecutive_same_calls += 1
            if consecutive_same_calls >= max_same_calls:
                # If the repeated call's arguments failed to parse (the "__raw__"
                # sentinel from RealClient._parse), the loop is caused by truncated /
                # unparseable tool arguments — almost always the response being cut off
                # at max_tokens — NOT by the model genuinely repeating a logically
                # identical action. Relabel so analysis can separate the two failure modes
                # ("raise max_tokens" vs "the model is actually stuck").
                if any(isinstance(c.arguments, dict) and "__raw__" in c.arguments
                       for c in turn.tool_calls):
                    return "truncated_tool_args", get_extra_data()
                loop_guard_fired = {"guard": "same_calls", "step": step_count}
                return "stuck_looping", get_extra_data()
        else:
            consecutive_same_calls = 0
            previous_tool_calls_json = current_calls_json

        pending_images = []  # screenshots to inject as image messages after this batch
        all_blocked = True   # will be set False if any call succeeds or is a known tool
        continue_outer = False  # set by the delayed-verification unlock to skip ahead
        tool_call_attempts += len(turn.tool_calls)
        for i, call in enumerate(turn.tool_calls):
            fn = getattr(tools, call.name, None)
            tool_calls_dispatched += 1
            tools.call_index = tool_calls_dispatched          # plan v2.5.13

            # GATING: refuse any call to a tool not permitted in this condition. Even
            # though we never advertised it, a model might hallucinate a call to it; we
            # must not execute it, or the condition would leak. The refusal is returned as
            # text so the model learns the tool isn't available and can adjust.
            # Wall clock for THIS tool call. Without it the request heartbeat that
            # follows a tool result reads as though the TOOL were hanging -- exactly
            # how it was misread on 2026-09-24, when a 1.3 KB write_file was blamed
            # for an hour that the model spent generating. Timing each call and
            # saying when it finished makes slow-tool and slow-model distinguishable
            # in the log without anyone having to reason about it.
            _tool_t0 = time.monotonic()
            if fn is None or call.name not in allowed:
                result_text, img = f"ERROR: tool '{call.name}' not available", None
                # (all_blocked stays True — this call was blocked)
            else:
                all_blocked = False  # at least one allowed (non-gated) call this step
                if isinstance(call.arguments, dict) and "__raw__" in call.arguments:
                    malformed["unparseable_arguments"] += 1     # class 1
                    # ARGUMENT TRUNCATION: a "__raw__" key means RealClient._parse() could
                    # not JSON-decode this call's arguments — almost always because the
                    # response was cut off at max_tokens mid-arguments (common when a model
                    # tries to emit a very large file in a single write_file call). Calling
                    # the tool would raise an opaque "unexpected keyword argument '__raw__'";
                    # instead return an actionable message so the model can recover by
                    # splitting the write or shortening the content, rather than blindly
                    # re-emitting the same oversized call until the loop guard trips.
                    note = (" The previous response was cut off (finish_reason=length)."
                            if turn.finish_reason == "length" else "")
                    result_text, img = (
                        "ERROR: the arguments for this tool call were not valid JSON and "
                        "were likely truncated by the response token limit." + note +
                        " The 'content' you tried to write is probably too large to emit in "
                        "one call. Write the file in several smaller write_file/edit_file "
                        "calls, or shorten the content, then continue.", None)
                else:
                    try:
                        res = fn(**call.arguments)
                        result_text, img = res.text, res.image_b64
                    except OSError as e:
                        # THE FILESYSTEM SAYING NO IS NOT A HARNESS FAULT. Every path a
                        # tool touches is one the MODEL chose, inside the sandbox, so an
                        # OSError here means the model asked for something the filesystem
                        # will not do -- read_file on a directory (IsADirectoryError),
                        # list_dir on a file (NotADirectoryError), write_file under a path
                        # that is already a file (FileExistsError), a permission or
                        # disk-full error. Until 2026-09-23 every one of these escaped the
                        # tool and killed the run with a traceback: Granite lost a run to
                        # FileExistsError and another to IsADirectoryError ON STEP 1.
                        #
                        # That is the wrong failure mode for a study, not merely for an
                        # agent. The run is destroyed rather than continued, and it is
                        # destroyed BY WHAT THE MODEL CHOSE TO DO, so the losses land
                        # unevenly across the ladder and bias the contrast rather than
                        # just thinning it. A real agent is told "that's a directory" and
                        # tries something else; so is this one now.
                        #
                        # The line this draws is deliberate and narrow: OSError, TypeError
                        # and ValueError are things the model's arguments caused and can
                        # recover from, so they become tool text. Everything else -- an
                        # AttributeError or a KeyError in our own code -- still crashes
                        # the run, loudly, because a harness bug that silently degrades
                        # into a tool message is far worse than one that stops the batch.
                        result_text, img = f"ERROR: {type(e).__name__}: {e}", None
                        tool_errors_other += 1
                    except (TypeError, ValueError) as e:
                        # Wrong/missing arguments or path escapes. Report as text so the model can retry,
                        # rather than crashing the run.
                        result_text, img = f"ERROR bad arguments: {e}", None
                        # Class 2 counts ONLY a signature mismatch — the call's JSON was
                        # valid but its shape was not. A ValueError raised inside a tool
                        # (a path escape, say) is a refusal, not a malformed call, and
                        # counting it would inflate the study's key H1 metric.
                        if isinstance(e, TypeError) and any(
                                m in str(e) for m in _SIGNATURE_ERROR_MARKERS):
                            malformed["invalid_arguments"] += 1
                        else:
                            tool_errors_other += 1

            # Log and append the tool result. The tool_call_id ties this result back to the
            # specific call the model made, which the API requires.
            log.log_tool_result(call.name, result_text, img is not None)

            if verbose:
                summary = result_text[:150].replace('\n', ' ') + ("..." if len(result_text) > 150 else "")
                print(f"Tool Result ({call.name}): {summary}")
                # Completion marker. "tools done for this step" is asserted only on the
                # LAST call of the step -- a step may carry several calls, and claiming
                # the step is finished after the first would be a lie the log tells
                # every time a model batches its calls.
                _n_calls = len(turn.tool_calls)
                _tail = " - tools done for this step" if i + 1 == _n_calls else ""
                print(f"[tool] {call.name} applied in "
                      f"{time.monotonic() - _tool_t0:.2f}s "
                      f"(call {i + 1} of {_n_calls}){_tail}", flush=True)

            messages.append({
                "role": "tool",
                "tool_call_id": call.id or f"call_{i}",
                "content": result_text,
            })

            # Collect any screenshot for injection (see step 5).
            if img and vision:
                pending_images.append(img)

            # ---- finish tool: in a delayed-verification condition the FIRST finish
            # unlocks the verification tools instead of ending the run; the model is
            # told (with a fixed message) to verify and finish again.
            if call.name == "finish" and delayed and unlocked_at_step is None:
                nonlocal_unlock = step_count  # readability; assigned below
                unlocked_at_step = nonlocal_unlock
                allowed = delayed["post"]
                schemas = [SCHEMAS[name] for name in allowed]
                messages.append({"role": "user", "content": DELAYED_UNLOCK_MESSAGE})
                log.log_tool_result("finish",
                                    "[delayed_verification] tools unlocked", False)
                continue_outer = True
                break

            # ---- finish tool => terminal success. Stop immediately.
            if call.name == "finish":
                import sys
                is_first = (first_finish_usage is None)
                extra_data = get_extra_data()

                if is_first:
                    print(f"\n[Agent Finished First Time] Command line arguments:\n{' '.join(sys.argv)}")

                log.update_manifest("finished", extra=extra_data)

                if handle_interactive_pause(f"Agent called finish: {call.arguments.get('summary', '')}"):
                    break  # break out of tool loop to execute pending images and continue outer loop
                return "finished", extra_data

        if continue_outer:
            # Delayed-verification unlock happened this step; the unlock message is
            # already appended. Skip image injection / stuck checks and re-enter the
            # loop so the model sees its new tools immediately.
            continue

        # ---- 5. Inject any screenshots as a separate user-role image message.
        # Most OpenAI-compatible endpoints can't carry an image inside a tool-result slot,
        # so the pattern is: the screenshot tool returns a text ack (already appended
        # above), and the actual image rides here in a user turn. Only happens for vision
        # conditions; text-only models never reach this branch.
        if pending_images:
            content = [{"type": "text", "text": "Screenshot(s) from the tool call:"}]
            for b64 in pending_images:
                content.append({"type": "image_url",
                                "image_url": {"url": f"data:image/png;base64,{b64}"}})
            messages.append({"role": "user", "content": content})

        # ---- 6. Stuck detection.
        # If every tool call this step was blocked, increment the counter. If the model
        # has been blocked for N consecutive steps, it's in an unrecoverable loop — bail
        # out rather than burning the rest of the step budget. This is the common failure
        # when a task explicitly requires a tool the condition doesn't grant (e.g. a task
        # that says "take a screenshot" run under --condition none).
        if all_blocked:
            consecutive_blocked += 1
            if consecutive_blocked >= max_blocked_calls:
                return "stuck_blocked_tool", get_extra_data()
        else:
            consecutive_blocked = 0  # reset on any successful dispatch

    # Fell out of the for-loop without finishing => we hit the step budget.
    return "budget_exhausted", get_extra_data()


_FINGERPRINT_SKIP_DIRS = {"node_modules", ".git", ".agent_logs", "data", "db", "pgdata",
                          "board-data", ".pglite", "dist"}


def workspace_fingerprint(ws: Path) -> dict:
    """Hash the model-authored source tree at end-of-run for tamper/provenance checks.

    Returns {"n_files": N, "sha": <16-hex>} where sha covers sorted (relpath, file-sha)
    pairs of all source files, excluding dependency/data/build dirs. Re-running this on
    an archived run and comparing to the manifest proves whether the artifact analyzed
    later is byte-identical to what the model actually produced.
    """
    import hashlib
    entries = []
    if ws.exists():
        for p in sorted(ws.rglob("*")):
            if not p.is_file():
                continue
            rel = p.relative_to(ws)
            if any(part in _FINGERPRINT_SKIP_DIRS for part in rel.parts):
                continue
            if rel.name.startswith("cmd_out_") or rel.suffix in (".log", ".png"):
                continue
            try:
                h = hashlib.sha256(p.read_bytes()).hexdigest()[:16]
            except OSError:
                continue
            entries.append(f"{rel.as_posix()}:{h}")
    combined = hashlib.sha256("\n".join(entries).encode()).hexdigest()[:16]
    return {"n_files": len(entries), "sha": combined}


def git_hash(path: Path) -> str:
    """Best-effort git identity of the harness, for the manifest's provenance record.

    Returns "none" if the path isn't a git repo or git isn't available — provenance is
    nice-to-have here, so failure shouldn't break a run.

    A COMMIT IS NOT THE CODE THAT RAN. This used to return the commit alone, which meant
    a run made from a working tree with uncommitted edits recorded the hash of code that
    was not executed — and gate G6, which checks that every run in a set shares one
    harness_git, would compare two identical strings and pass. That is a silent falsehood
    in the manifest, and it was live: on 2026-09-23 the write_file FileExistsError fix sat
    uncommitted in the tree while the previous smoke set's manifests all read 6010fa10.
    So a dirty tree now says so, and says WHICH dirt: the suffix carries a hash of the
    diff, so a set of runs made from the same uncommitted state still agrees with itself
    (G6 passes, which is what makes an exploratory smoke usable at all), while a dirty run
    can never match a clean one and two differently-dirty runs can never match each other.
    """
    import hashlib
    try:
        head = subprocess.run(["git", "-C", str(path), "rev-parse", "HEAD"],
                              capture_output=True, text=True).stdout.strip()
        if not head:
            return "none"
        # Tracked modifications (staged or not) are the dirt that matters. UNTRACKED files
        # are deliberately scoped to harness/ only: the repo root accumulates run output --
        # batch-state/progress-*.tsv is rewritten DURING a batch, probe-prompts/ grows on
        # every probe -- so hashing untracked files repo-wide would give consecutive runs
        # in one batch different harness_git values and make G6 fail permanently, for no
        # gain. A new module that changes the instrument lands in harness/, and that is
        # caught. (A new top-level .py the harness imports would not be; noted rather than
        # solved, because the alternative is a gate that cries wolf on every run.)
        diff = subprocess.run(["git", "-C", str(path), "diff", "HEAD"],
                              capture_output=True, text=True).stdout
        untracked = subprocess.run(
            ["git", "-C", str(path), "ls-files", "--others", "--exclude-standard",
             "--", "harness/"], capture_output=True, text=True).stdout
        if diff or untracked:
            mark = hashlib.sha256((diff + "\x00" + untracked).encode()).hexdigest()[:12]
            return f"{head}+dirty.{mark}"
        return head
    except Exception:  # noqa: BLE001
        return "none"


# Default registry locations, tried in order when --quant-registry is not passed. Keeping
# it beside the harness means the common case needs no flag at all.
_QUANT_REGISTRY_DEFAULTS = ("quant-registry.json",
                            str(Path(__file__).resolve().parent.parent / "quant-registry.json"))


def load_quant_detail(registry_path, model: str, quantization):
    """Resolve (model, quantization) to its declared provenance. Never raises.

    Returns None when no registry is in play at all, otherwise a dict carrying a
    `status` field so the manifest distinguishes the failure modes that matter:

        ok            entry found and copied
        no_label      a registry exists but the run declared no --quantization
        no_registry   a label was declared but no registry file was found
        unreadable    the file exists but is not parseable JSON
        model_missing the registry has no section for this model id
        rung_missing  the model is present but has no entry for this label

    Recording WHICH of those happened is the point. A silently absent field would let a
    run with unknown provenance sit in a batch looking identical to one that simply
    predates the registry, and the whole reason this field exists is that "Q8 looped more
    than Q5_K_M" is uninterpretable without knowing whether both rungs came from the same
    publisher's build lineage.

    The registry file's own sha is recorded so the declaration is pinned: editing the
    registry after a batch changes the hash, and the mismatch is visible.
    """
    cands = [registry_path] if registry_path else list(_QUANT_REGISTRY_DEFAULTS)
    found = next((Path(c) for c in cands if c and Path(c).is_file()), None)
    if found is None:
        if not quantization:
            return None          # no registry, no label: field stays null, nothing to say
        return {"status": "no_registry", "quantization": quantization,
                "note": f"no registry at {', '.join(str(c) for c in cands)}"}
    try:
        raw = found.read_text(encoding="utf-8")
        reg = json.loads(raw)
    except Exception as e:  # noqa: BLE001
        return {"status": "unreadable", "registry": str(found), "note": f"{type(e).__name__}: {e}"}

    base = {"status": "ok", "registry": str(found),
            "registry_sha": sha(raw), "model_key": model, "quantization": quantization}
    if not quantization:
        return {**base, "status": "no_label",
                "note": "registry present but the run declared no --quantization"}
    # Tolerate the same namespacing the preflight tolerates: a server may report
    # google/gemma-4-31b while the registry is keyed on gemma-4-31b, or vice versa.
    section = reg.get(model)
    if section is None:
        leaf = model.rsplit("/", 1)[-1]
        hits = [k for k in reg if k.rsplit("/", 1)[-1] == leaf and not k.startswith("_")]
        if len(hits) == 1:
            section, base["model_key"] = reg[hits[0]], hits[0]
    if not isinstance(section, dict):
        return {**base, "status": "model_missing",
                "note": f"registry has no section for model {model!r}; "
                        f"has {sorted(k for k in reg if not k.startswith('_'))}"}
    entry = section.get(quantization)
    if not isinstance(entry, dict):
        return {**base, "status": "rung_missing",
                "note": f"model {base['model_key']!r} has no rung {quantization!r}; "
                        f"has {sorted(section)}"}
    return {**base, **entry}


def check_serving_probe(probe, quant_detail):
    """Compare what the server says it loaded against what the registry claims.

    Returns a note string, or None when there is nothing to compare. This is the only
    place in the harness where a DECLARATION meets a MEASUREMENT, so it is the only place
    that can catch the operator having loaded a different rung than they think — the
    failure that would quietly turn a precision ladder into noise.

    Matching is on basename only: the server reports a Windows path while the registry
    may hold the WSL view of the same file, and the harness has no business trying to
    reconcile those. Basename equality is weak but it is not zero, and a mismatch is
    worth shouting about.
    """
    if not probe or not isinstance(quant_detail, dict):
        return None
    served = probe.get("model_path")
    declared = quant_detail.get("file")
    if not served or not declared:
        return None
    s = str(served).replace("\\", "/").rsplit("/", 1)[-1]
    d = str(declared).replace("\\", "/").rsplit("/", 1)[-1]
    if s == d:
        return f"served file matches the registry entry ({s})"
    return (f"MISMATCH: the server is serving {s!r} but the registry entry for "
            f"{quant_detail.get('quantization')!r} names {d!r}")


def main():
    """CLI entry point for ONE run. (run_matrix.py calls this in a subprocess per cell.)

    Wires together: parse args -> build the model client and tools -> assemble the
    manifest (including the prompt hashes that make the run verifiable) -> run the loop ->
    finalize the logs -> print a one-line summary.
    """
    ap = argparse.ArgumentParser(description="Controlled coding-agent harness")
    # --- what to build and under what treatment ---
    ap.add_argument("--task-file", required=True,
                    help="path to the task prompt (text); its contents become the user "
                         "message and are hashed into the manifest as task_sha")
    ap.add_argument("--condition", required=True,
                    help="none|visual|behavioral|execution|static|self_built")
    ap.add_argument("--workspace", required=True,
                    help="dir the agent writes code into (use a fresh dir per run)")
    ap.add_argument("--run-dir", required=True,
                    help="dir for logs (manifest.json + trace.jsonl)")
    # --- which model server and model ---
    ap.add_argument("--base-url", default="http://localhost:1234/v1",
                    help="LM Studio default; use https://openrouter.ai/api/v1 for OpenRouter")
    ap.add_argument("--api-key", default="lm-studio",
                    help="placeholder for LM Studio; real sk-or-... key for OpenRouter")
    ap.add_argument("--model", required=True,
                    help="model id as the server reports it (check GET /v1/models)")
    # PROVENANCE, NOT TREATMENT. Nothing in the run reads this; it exists so a run can
    # say which rung of a precision ladder it is without anyone parsing a model id.
    # Ids are an unreliable place to keep this: LM Studio bakes the quant in
    # (gemma-4-31b-it@q5_k_m), llama-server reports whatever --alias says, and
    # OpenRouter reports nothing about precision at all.
    # Deliberately free-form and NOT normalized — the label should be verbatim what the
    # served artifact is (Q4_K_M, Q8_0, BF16, UD-Q4_K_XL, FP8). Nothing upper-cases or
    # rewrites it, so use ONE spelling for a whole ladder or the rungs will not group.
    ap.add_argument("--quantization", default=None,
                    help="label for the precision this model is served at, e.g. Q4_K_M / "
                         "Q8_0 / BF16. Recorded in the manifest as `quantization` (null "
                         "when not given). Has no effect on the run. Doubles as the "
                         "lookup key into --quant-registry.")
    ap.add_argument("--quant-registry", default=None,
                    help="path to a JSON registry of quantization rungs, keyed "
                         "model -> quantization label. The matching entry is copied into "
                         "the manifest as `quantization_detail`, along with a hash of the "
                         "registry file itself so the declaration is pinned. Declaring "
                         "publisher/method/file-hash ONCE per rung here beats passing "
                         "them per run: a 30 GB sha256 is not something to recompute "
                         "670 times, and one file under version control is reviewable in "
                         "a way that 670 command lines are not. See tools/hash_quants.py, "
                         "which fills it in by reading each GGUF's own header.")
    # --- decoding params -------------------------------------------------------
    # Defaults come from llm.DECODING_DEFAULTS — the study's single canonical decoding
    # configuration. Overriding any of them is possible for debugging but is stamped
    # into the manifest (decoding_overridden) and flagged by verify_inputs.py, because
    # a decoding difference between runs is a second, unintended treatment.
    ap.add_argument("--temperature", type=_decode_param,
                    default=DECODING_DEFAULTS["temperature"],
                    help="float, or 'none' to omit the field (for models that have "
                         "deprecated temperature and 400 when it is sent)")
    ap.add_argument("--top-p", type=_decode_param, default=DECODING_DEFAULTS["top_p"],
                    help="float, or 'none' to omit the field")
    ap.add_argument("--max-tokens", type=int, default=DECODING_DEFAULTS["max_tokens"],
                    help="cap on tokens per single model response (one turn). The "
                         "default (32768) exists because at 4096 reasoning models "
                         "emitted truncated tool-call arguments and stuck-looped.")

    # The rest of the sampler set. NO MODEL NAMES APPEAR IN THIS FILE: the values come
    # from decoding-registry.json via the run wrapper, which is the single place a
    # decoding decision is written down. 0 is a real value here (top_k 0 = disabled) and
    # is sent; "none" omits the field entirely, which hands it to the engine's default
    # and is almost never what a study run wants.
    ap.add_argument("--top-k", type=_decode_param, default=None,
                    help="top_k; 0 disables it. Omitted from the request when 'none'.")
    ap.add_argument("--min-p", type=_decode_param, default=None,
                    help="min_p; 0 disables it.")
    ap.add_argument("--presence-penalty", type=_decode_param, default=None,
                    help="presence_penalty.")
    ap.add_argument("--decoding-profile", default=None,
                    help="name of the profile these values came from (e.g. 'thinking', "
                         "'non_thinking'). Recorded per run. Its presence is what marks "
                         "a run as configured rather than fallen back to the ad-hoc "
                         "defaults, so a study run must always pass it.")
    ap.add_argument("--decoding-registry", default=None,
                    help="path to the decoding registry the values came from. NOT read "
                         "for values -- only fingerprinted, so the manifest records which "
                         "config produced this run without the harness interpreting it.")

    # --- budget + project-specific test command ---
    ap.add_argument("--max-steps", type=int, default=40,
                    help="hard cap on loop iterations (budget guard)")
    ap.add_argument("--max-total-tokens", type=int, default=0,
                    help="hard cap on total tokens for the whole run (0 = unlimited). "
                         "Steps are a poor cost proxy; set this for cost-bounded, "
                         "cross-condition comparable runs (e.g. 3000000).")
    ap.add_argument("--seed", type=int, default=None,
                    help="sampling seed forwarded to the provider (best-effort; not all "
                         "providers honor it) and recorded in the manifest")
    ap.add_argument("--briefing-mode", default="universal",
                    choices=["universal", "per_condition", "none"],
                    help="universal (default): ONE briefing byte-identical in every "
                         "condition - the whole prompt is constant and only the tool "
                         "schemas differ. per_condition: the registered per-condition "
                         "environment descriptions (stronger orientation, prompt "
                         "varies by condition). none: ablation, no briefing at all.")
    ap.add_argument("--extra-body", default=None, metavar="JSON|@FILE",
                    help="JSON object merged into the request body, for fields the "
                         "OpenAI schema has no slot for. Inline JSON, or @path to a "
                         "file. The two real uses: `chat_template_kwargs` (the only way "
                         "to toggle thinking on Qwen3/Gemma through llama-server) and "
                         "llama.cpp sampler fields the schema omits — `top_k`, `min_p`, "
                         "`repeat_penalty` — which otherwise fall through to the GGUF's "
                         "own general.sampling.* metadata unrecorded. Also useful: "
                         "`cache_prompt: false` for the determinism question. Recorded "
                         "verbatim in the manifest as `extra_body`. Keys the harness "
                         "owns are REFUSED, because they would be either silently "
                         "clobbered or silently ignored depending on which side of one "
                         "line they land. Example: "
                         "--extra-body '{\"top_k\": 1, \"chat_template_kwargs\": "
                         "{\"enable_thinking\": false}}'")
    ap.add_argument("--replay-reasoning", dest="replay_reasoning",
                    action=argparse.BooleanOptionalAction, default=True,
                    help="send the model's own reasoning_content back with the assistant "
                         "turn that produced it, so its chain of thought survives to the "
                         "next step instead of being discarded once the tool call is "
                         "extracted (default: on; --no-replay-reasoning restores the "
                         "pre-2026-08-13 behaviour). This is a TREATMENT — it changes "
                         "what the model sees — and is recorded per run as "
                         "`reasoning_replayed`. Not every server accepts it: llama.cpp "
                         "has a live bug where an assistant message carrying both "
                         "reasoning_content and tool_calls fails template rendering, so "
                         "verify with tools/probe_reasoning_replay.py before a batch.")
    ap.add_argument("--replay-format", default="field", choices=list(REPLAY_FORMATS),
                    help="HOW a replayed thought is carried back (see REPLAY_FORMATS). "
                         "'field' sets reasoning_content and is right for every model whose "
                         "template has a slot for it. 'inline-think' puts the reasoning back "
                         "into the reply text as [THINK]…[/THINK], which is the wire format "
                         "Magistral actually emits — its template has no reasoning field, and "
                         "sending one makes llama.cpp delete the assistant's own prose and "
                         "add nothing, so its SEEN arm would show the model LESS than UNSEEN. "
                         "A TREATMENT setting; recorded per run as replay_format. Only "
                         "meaningful when replay is on.")
    ap.add_argument("--think-preamble", default="none",
                    metavar="KEY",
                    help="append a REGISTERED thinking preamble (harness.agent."
                         "THINK_PREAMBLES) to the system prompt. For models whose "
                         "reasoning is driven by the system prompt rather than by a "
                         "chat-template switch — Magistral is the case that forced this "
                         "— the harness's own system prompt displaces the template's "
                         "reasoning instructions and the model silently never thinks, "
                         "which makes the replayed and discarded arms the same "
                         "condition. This is a TREATMENT setting: it is recorded as "
                         "think_preamble_key / think_preamble_sha and is folded into "
                         "system_prompt_sha, and a batch mixing two values of it is a "
                         "batch with two treatments in it. Only registry keys are "
                         "accepted (currently: %s), or 'none' (default). Free text is "
                         "deliberately NOT accepted — a new preamble is a code change, "
                         "so it moves harness_git." % ", ".join(sorted(THINK_PREAMBLES)))
    ap.add_argument("--no-preflight", action="store_true",
                    help="skip the GET /models check that the server is up and serving "
                         "this exact model id before the run starts")
    ap.add_argument("--no-briefing", action="store_true",
                    help="deprecated alias for --briefing-mode none")
    ap.add_argument("--max-same-calls", type=int, default=3,
                    help="cap on consecutive identical tool calls before aborting (default 3)")
    ap.add_argument("--max-blocked-calls", type=int, default=3,
                    help="cap on consecutive blocked tool calls before aborting (default 3)")
    ap.add_argument("--max-cycle-repeats", type=int, default=3,
                    help="how many repetitions of a 2-call cycle (A,B,A,B,...) trip the "
                         "stuck_looping guard (default 3 = the historical A,B,A,B,A,B "
                         "window). Raise it to give a model more room to break out of an "
                         "apparent loop; set <2 to disable period-2 cycle detection.")
    ap.add_argument("--max-repeat-steps", type=int, default=6,
                    help="no-progress guard: abort as stuck_looping after this many "
                         "CONSECUTIVE steps in which every tool call merely repeats one "
                         "already made earlier in the run. Catches loops that rotate "
                         "among near-identical variants and so evade --max-same-calls "
                         "and --max-cycle-repeats. 0 disables (pre-2026-08 behavior).")
    ap.add_argument("--test-cmd", default="npm test",
                    help="command the run_tests tool executes")
    ap.add_argument("--verbose", action="store_true",
                    help="show what the agent is doing on the screen")
    ap.add_argument("--interactive", action="store_true",
                    help="Pause and prompt the user instead of exiting when the agent finishes")
    ap.add_argument("--clean-workspace", action="store_true",
                    help="delete all files and directories in the workspace directory before starting")
    ap.add_argument("--seed-workspace", default=None,
                    help="directory whose contents are copied into the workspace before "
                         "the run starts (brownfield tasks: the pre-existing codebase the "
                         "model must extend). Recorded in the manifest with a fingerprint "
                         "so the starting state is provable.")
    ap.add_argument("--screenshot-dir", default=None,
                    help="path to save screenshots (default: workspace)")
    args = ap.parse_args()

    import sys
    print(f"\n[Agent Startup] Command line arguments:\n{' '.join(sys.argv)}\n")

    # There is no longer one canonical decoding to deviate FROM: the study's values are
    # per model and per thinking mode, and they live in decoding-registry.json (plan
    # §4.4.1). What matters now is whether this run was configured at all. A run with no
    # --decoding-profile fell back to the ad-hoc defaults in llm.DECODING_DEFAULTS, which
    # for a study run means its configuration was lost somewhere between the registry and
    # here — and a run at the wrong temperature looks exactly like a run at the right one,
    # so it is stamped and gated rather than merely warned about.
    decoding_source = "registry" if args.decoding_profile else "fallback"
    if decoding_source == "fallback":
        print(f"WARNING: no --decoding-profile given, so this run uses the ad-hoc "
              f"fallback {DECODING_DEFAULTS} and is stamped decoding_source=fallback. "
              f"Study runs are configured from decoding-registry.json by the run "
              f"wrapper; do not mix a fallback run into a batch.")
    _dreg_sha = None
    _dreg_profile = None
    if args.decoding_registry:
        try:
            import hashlib as _hl
            _dreg_bytes = Path(args.decoding_registry).read_bytes()
            _dreg_sha = _hl.sha256(_dreg_bytes).hexdigest()[:16]
        except OSError as _e:
            raise SystemExit(f"--decoding-registry unreadable: {_e}")
        # The profile this run was configured from, so decoding_overridden can compare
        # against the values the study registered for THIS model and mode (plan 42
        # v2.5.31). Until then it compared against llm.DECODING_DEFAULTS, the greedy
        # defaults of an earlier study, and so stamped every sampled run as "overridden".
        if args.decoding_profile:
            try:
                _dreg_profile = ((json.loads(_dreg_bytes.decode("utf-8")).get(args.model)
                                  or {}).get(args.decoding_profile))
            except (ValueError, UnicodeDecodeError, AttributeError):
                _dreg_profile = None

    # Declared precision label. Strip surrounding whitespace (it arrives through a shell
    # variable, which picks that up easily) and collapse the empty string to None, so an
    # unset QUANT and QUANT="" record identically rather than as ""-vs-null.
    quantization = (args.quantization or "").strip() or None
    if quantization:
        print(f"[quantization] declared as {quantization!r} "
              f"(recorded in the manifest; no effect on the run)")
    replay_reasoning = args.replay_reasoning
    replay_format = args.replay_format
    if replay_reasoning and replay_format != "field":
        print(f"[reasoning] replay format {replay_format!r} — the thought goes back inside "
              f"the reply text, not in a separate field. Recorded as replay_format.")
    # Resolved HERE, before anything talks to a server, so an unknown key fails on the
    # command line rather than 40 minutes into a batch.
    if args.think_preamble not in ("none", "") and args.think_preamble not in THINK_PREAMBLES:
        raise SystemExit(f"--think-preamble: unknown key {args.think_preamble!r} "
                         f"(registered: {', '.join(sorted(THINK_PREAMBLES))}, or 'none')")
    think_preamble_key = args.think_preamble if args.think_preamble not in ("", "none") else "none"
    think_preamble = THINK_PREAMBLES.get(think_preamble_key, "")
    if think_preamble_key != "none":
        print(f"[thinking] system-prompt preamble {think_preamble_key!r} appended "
              f"({len(think_preamble)} chars) — this is a TREATMENT setting; it is what "
              f"makes a prompt-driven reasoner think at all. Recorded as "
              f"think_preamble_key.")
    print(f"[reasoning] replay {'ON' if replay_reasoning else 'OFF'} — the model's chain "
          f"of thought {'is returned with' if replay_reasoning else 'is discarded after'} "
          f"each assistant turn")
    quant_detail = load_quant_detail(args.quant_registry, args.model, quantization)
    if quant_detail and quant_detail.get("status") == "ok":
        print(f"[quantization] registry: publisher={quant_detail.get('publisher')} "
              f"method={quant_detail.get('method')} "
              f"sha256={str(quant_detail.get('file_sha256'))[:16]}...")
    elif quant_detail:
        print(f"[quantization] registry: {quant_detail.get('status')} — "
              f"{quant_detail.get('note')}")

    task_file = Path(args.task_file).resolve()
    task = task_file.read_text()
    ws = Path(args.workspace).resolve()
    run_dir = Path(args.run_dir).resolve()

    # ---- Extra request-body fields ------------------------------------------------
    # Parsed and validated BEFORE the client exists and long before the workspace is
    # touched: a malformed or dangerous extra body must stop run 1 of a batch, not
    # produce 576 runs whose manifests misdescribe what was sent.
    user_extra_body: dict = {}
    if args.extra_body:
        raw = args.extra_body
        if raw.startswith("@"):
            try:
                raw = Path(raw[1:]).read_text(encoding="utf-8")
            except OSError as e:
                raise SystemExit(f"--extra-body: cannot read {args.extra_body[1:]!r}: {e}")
        try:
            user_extra_body = json.loads(raw)
        except json.JSONDecodeError as e:
            raise SystemExit(f"--extra-body is not valid JSON: {e}")
        problems = validate_extra_body(user_extra_body)
        if problems:
            raise SystemExit("--extra-body refused:\n  - " + "\n  - ".join(problems))
        print(f"WARNING: --extra-body is in force: {json.dumps(user_extra_body, sort_keys=True)}. "
              f"These fields go to the server on EVERY request and are part of this "
              f"run's treatment. Recorded in the manifest as extra_body; do not mix "
              f"runs that differ here into one batch.")

    # Build the model client. Swapping LM Studio <-> OpenRouter is entirely in these args.
    # seed is merged in alongside; it has its own flag and its own manifest field, and is
    # listed second so an operator cannot quietly displace it through the escape hatch.
    extra_body = {**user_extra_body}
    extra_body = extra_body or None
    # Samplers travel their own path, not through extra_body: temperature and top_p are
    # written after the spread and would be silently ignored there, and seed used to ride
    # in extra_body for no better reason than that it fit.
    samplers = {k: v for k, v in (("top_k", args.top_k), ("min_p", args.min_p),
                                  ("presence_penalty", args.presence_penalty),
                                  ("seed", args.seed)) if v is not None}
    _sampler_problems = validate_samplers(samplers)
    if _sampler_problems:
        raise SystemExit("refusing to run:\n  " + "\n  ".join(_sampler_problems))
    client = RealClient(base_url=args.base_url, model=args.model, api_key=args.api_key,
                        temperature=args.temperature, top_p=args.top_p,
                        max_tokens=args.max_tokens, extra_body=extra_body,
                        samplers=samplers)

    # PREFLIGHT, BEFORE ANYTHING IS DESTROYED. One GET /models, so a dead or empty
    # server is caught in a second with an actionable message, rather than after the
    # workspace has been wiped and the run directory created. In an unattended batch the
    # difference is one clear failure versus every remaining run grinding through its
    # retries into a server that nobody is going to restart until morning.
    # It also catches an exact-id mismatch, which has bitten this project before.
    if not args.no_preflight:
        ok_pf, msg_pf = client.preflight()
        print(f"[preflight] {msg_pf}")
        if not ok_pf:
            raise SystemExit(
                f"ABORTED before touching the workspace: {msg_pf}\n"
                f"(pass --no-preflight to run anyway.)")

    # Serving probe: the server's own account of what it loaded. Best-effort, never
    # fatal, and skipped along with the preflight so --no-preflight still means "do not
    # touch the network before the run". A mismatch against the registry is printed
    # loudly but does NOT abort: this is a trial-friendly warning, and turning it into a
    # hard stop is a decision for pre-registration, not for the harness to make quietly.
    serving_probe = None if args.no_preflight else client.props()
    probe_note = check_serving_probe(serving_probe, quant_detail)
    if serving_probe:
        print(f"[serving] {serving_probe.get('model_path') or serving_probe.get('model') or '?'} "
              f"n_ctx={serving_probe.get('n_ctx')} "
              f"template_sha={serving_probe.get('chat_template_sha')}")
    if probe_note:
        print(f"[serving] {probe_note}")

    if args.clean_workspace and ws.exists():
        import shutil
        print(f"Cleaning workspace directory: {ws}")
        for item in ws.iterdir():
            if item.is_dir():
                shutil.rmtree(item)
            else:
                item.unlink()

    # BROWNFIELD SEEDING: copy the starter codebase into the workspace before the run.
    # Done after --clean-workspace so "clean + seed" yields exactly the starter state.
    seed_fp = None
    if args.seed_workspace:
        import shutil
        seed_src = Path(args.seed_workspace).resolve()
        if not seed_src.is_dir():
            raise SystemExit(f"--seed-workspace is not a directory: {seed_src}")
        ws.mkdir(parents=True, exist_ok=True)
        shutil.copytree(seed_src, ws, dirs_exist_ok=True)
        seed_fp = workspace_fingerprint(ws)
        print(f"Seeded workspace from {seed_src} "
              f"({seed_fp['n_files']} files, sha {seed_fp['sha']})")

    # Does this condition produce/consume images? Drives screenshot injection in the loop.
    vision = args.condition in VISION_CONDITIONS

    screenshot_dir = Path(args.screenshot_dir).resolve() if args.screenshot_dir else None
    tools = Tools(workspace=ws, test_cmd=args.test_cmd, screenshot_dir=screenshot_dir)

    # Resolve the prompt parts and hash them SEPARATELY:
    #   base_prompt_sha          - the constant base (must be identical across the batch)
    #   condition_briefing_sha   - the condition's registered briefing (must match the
    #                              CONDITION_BRIEFINGS registry for that condition)
    #   system_prompt_sha        - the combination actually sent
    # verify_inputs.py checks all three plus task_sha across a batch.
    briefing_mode = "none" if args.no_briefing else args.briefing_mode
    briefing = {"universal": UNIVERSAL_BRIEFING,
                "per_condition": CONDITION_BRIEFINGS.get(args.condition, ""),
                "none": ""}[briefing_mode]
    base_prompt = SYSTEM_PROMPT_TEMPLATE.format(workspace=str(ws))
    resolved_system_prompt = (base_prompt
                              + ("\n\n" + briefing if briefing else "")
                              + ("\n\n" + think_preamble if think_preamble else ""))
    # HASHING NOTE: base_prompt_sha covers the TEMPLATE (with the {workspace}
    # placeholder), not the resolved text. The workspace path differs per run by
    # design (it is infrastructure, recorded separately under "workspace"), so a
    # resolved hash would differ across every run and falsely fail the batch
    # input-identity check. system_prompt_sha keeps the fully resolved text for
    # per-run audit.

    manifest = {
        "model": args.model, "base_url": args.base_url, "condition": args.condition,
        # Precision the model was served at, as DECLARED by the operator (--quantization);
        # the harness cannot observe it, so this is an assertion, not a measurement.
        # ALWAYS present, null when undeclared: a stable key means analysis can group by
        # rung without .get() gymnastics, and "declared nothing" stays distinguishable
        # from a run predating this field only by that run having no key at all.
        "quantization": quantization,
        # Whether the model's reasoning went back into the conversation. Recorded at the
        # top level as well as in the run's extra data because it is a TREATMENT setting
        # known before the first request, and a batch mixing the two is a batch with two
        # treatments in it.
        "reasoning_replayed": replay_reasoning,
        # HOW it was replayed. ALWAYS present so analysis can group by it without .get(),
        # and so "replayed in a separate field" and "replayed inline in the reply" stay
        # distinguishable — they are different treatments on models that accept both.
        "replay_format": replay_format,
        # DECLARED provenance for that rung, resolved from the quant registry: publisher,
        # method, imatrix, file path, sha256, size. Carries a `status` field so "no
        # registry", "rung not listed" and "found it" stay distinguishable. Satisfies the
        # D9 requirement that publisher and method are recorded per rung.
        "quantization_detail": quant_detail,
        # MEASURED serving facts, straight from the server (llama-server GET /props):
        # which file it actually has open, the effective context, and a hash of the chat
        # template in force. null when the provider has no such endpoint. `probe_note`
        # is the declaration-vs-measurement comparison, and is the only thing here that
        # can catch a rung being mislabelled at the moment it is run.
        "serving_probe": (dict(serving_probe, probe_note=probe_note)
                          if serving_probe else None),
        "allowed_tools": tools_for(args.condition),
        # EVERY sampler actually sent, in one place. Until v2.4.0 this block named only
        # temperature, top_p and max_tokens while top_k rode in extra_body -- so the
        # single most consequential sampler of the greedy configuration (top_k 1) never
        # appeared in the decoding record at all.
        "decoding": dict({"temperature": args.temperature, "top_p": args.top_p,
                          "max_tokens": args.max_tokens}, **samplers),
        # Which registry profile these values came from, and the fingerprint of the file
        # that supplied them. "fallback" means no profile was given and the ad-hoc
        # defaults were used -- a configuration failure for a study run, not a variant.
        "decoding_profile": args.decoding_profile,
        "decoding_source": decoding_source,
        "decoding_registry_sha": _dreg_sha,
        # Non-schema request fields in force (--extra-body), verbatim. Empty dict = none.
        # These reach the server on every request and are therefore part of the run's
        # treatment, so they are recorded beside `decoding` rather than buried: two runs
        # differing here are two treatments, exactly as with `decoding_overridden`.
        # `seed` is excluded — it has its own flag and its own field above.
        "extra_body": user_extra_body,
        # Which decoding params (if any) deviate from what the study registered. Empty
        # dict = clean. seed is excluded: it is the per-replicate variable. Since plan 42
        # v2.5.31 the samplers are compared with this model's profile in
        # decoding-registry.json (decoding_overridden_basis = "registry"); max_tokens,
        # which the registry does not carry, with the study's per-reply cap. With no
        # profile to compare against, the old comparison with llm.DECODING_DEFAULTS stands
        # (basis "fallback_defaults").
        "decoding_overridden": _decoding_overridden(args, _dreg_profile),
        "decoding_overridden_basis": "registry" if _dreg_profile else "fallback_defaults",
        "max_steps": args.max_steps, "max_total_tokens": args.max_total_tokens,
        # Loop-guard thresholds in force for this run, recorded so analysis can tell apart
        # runs aborted under different stuck-detection settings (and reproduce them).
        "loop_guards": {"max_same_calls": args.max_same_calls,
                        "max_blocked_calls": args.max_blocked_calls,
                        "max_cycle_repeats": args.max_cycle_repeats,
                        "max_repeat_steps": args.max_repeat_steps},
        "vision": vision,
        # Browser launch settings in force (env-driven; see harness/browser.py).
        # Study configuration is headed=false, slow_mo_ms=0. Recorded for EVERY run
        # so a debugging run made with a visible window or slow-motion - whose
        # rendering and timing differ - can never be mistaken for a study run.
        "browser": browser_launch_config(),
        # PROVENANCE: interactive runs accept typed human feedback mid-run and are NOT
        # autonomous data points. Recorded up front (and human_turns counts the actual
        # interventions in the run's extra data) so contaminated runs are excludable
        # mechanically rather than by reading traces.
        "interactive": args.interactive,
        # Which briefing mode produced condition_briefing_sha (see --briefing-mode).
        "briefing_mode": briefing_mode,
        "no_briefing": briefing_mode == "none",   # kept for back-compat with tooling
        # Hash of the harness code itself, so every run records which version of the
        # instrument produced it (tool definitions changed over the study's life).
        "harness_git": git_hash(Path(__file__).resolve().parent.parent),
        "system_prompt_sha": sha(resolved_system_prompt),
        "base_prompt_sha": sha(SYSTEM_PROMPT_TEMPLATE),
        "condition_briefing_sha": sha(briefing),
        # Which registered thinking preamble was appended, and its hash. ALWAYS present
        # ("none" when there is none) so analysis can group by it without .get(), and so
        # "this run had no preamble" stays distinguishable from "this run predates the
        # field". See THINK_PREAMBLES for why a model might need one.
        "think_preamble_key": think_preamble_key,
        "think_preamble_sha": sha(think_preamble),
        "task_sha": sha(task),
        "workspace": str(ws),
        "workspace_git": git_hash(ws),
        # Brownfield provenance: where the pre-seeded code came from and its fingerprint
        # at t=0, so "what the model started from" is as provable as what it produced.
        "seed_workspace": str(Path(args.seed_workspace).resolve()) if args.seed_workspace else None,
        "seed_fingerprint": seed_fp,
    }
    log = RunLog(run_dir, manifest)

    # Build initial messages with the resolved workspace path.
    messages = build_messages(task, workspace=str(ws), briefing=briefing,
                              think_preamble=think_preamble)
    status = "interrupted"
    extra = None
    api_error = None
    overflow = None
    try:
        status, extra = run_agent(client, tools, args.condition, messages, log,
                           max_steps=args.max_steps, vision=vision, verbose=args.verbose,
                           max_same_calls=args.max_same_calls, max_blocked_calls=args.max_blocked_calls,
                           max_cycle_repeats=args.max_cycle_repeats,
                           max_repeat_steps=args.max_repeat_steps,
                           interactive=args.interactive,
                           max_total_tokens=args.max_total_tokens,
                           replay_reasoning=replay_reasoning,
                           replay_format=replay_format)
    except KeyboardInterrupt:
        print("\nRun interrupted by user.")
        status = "interrupted"
        raise
    except Exception as e:
        # A FAILURE OF THE SERVING STACK IS NOT A RESULT ABOUT THE MODEL. Classify API
        # failures under one registered status with the reason recorded, so an
        # unattended batch leaves a machine-readable account of the hole instead of a
        # free-form "crashed: HTTPError" that downstream tooling has to guess at. The
        # study's void rule keys off this status; see the plan's D10.
        import urllib.error as _ue
        overflow = getattr(e, "harness_context_overflow", None)
        if isinstance(e, _ue.HTTPError) and overflow:
            # AN OVERFLOW IS AN OUTCOME (plan 42 v2.5.28, §9): the conversation outgrew the
            # window. Recorded as its own terminal status and NOT re-raised, so the run
            # exits 0 and the batch driver keeps it instead of re-running the slot.
            status = "context_overflow"
            overflow = dict(overflow, code=e.code,
                            body=(getattr(e, "harness_body", None) or str(e))[:2000],
                            at_step=log.step)
        elif isinstance(e, (_ue.HTTPError, _ue.URLError, TimeoutError)):
            status = "api_error"
            api_error = {"exception": type(e).__name__,
                         "code": getattr(e, "code", None),
                         "body": (getattr(e, "harness_body", None) or str(e))[:2000],
                         "server_model_crash": bool(
                             getattr(e, "harness_model_crash", False)),
                         # A void caused by the MODEL's own output rather than by the
                         # server. Recorded separately because its probability depends on
                         # what the model generated, and what it generates is exactly what
                         # the treatment changes -- so these are NOT missing at random and
                         # must be counted per arm rather than pooled (plan §10).
                         "model_output_unparseable": bool(
                             getattr(e, "harness_output_unparseable", False))}
        else:
            status = f"crashed: {type(e).__name__}"
        if status != "context_overflow":
            raise
    finally:
        tools.teardown()
        # WORKSPACE FINGERPRINT: hash every model-authored source file at the moment the
        # run ends. Anything that later mutates the workspace (a post-hoc npm install, a
        # manual fix, a smoke-test side effect) becomes detectable by re-hashing, instead
        # of silently blending into the artifact.
        extra = dict(extra or {})
        extra["workspace_fingerprint"] = workspace_fingerprint(ws)
        # DECODING SELF-HEAL RECORD: params the client dropped at runtime because this
        # model rejected them (see llm.RealClient's heal loop). The provider default
        # applied for those fields, uniformly across this run; verify_inputs.py checks
        # per-model consistency of these drops across the batch.
        extra["decoding_dropped_params"] = sorted(
            getattr(client, "runtime_dropped_params", set()) or [])
        # RETRY RECORD (plan 42 v2.5.8): every retried model call and why. Written here,
        # beside api_error, so a run that dies after exhausting its retries records them
        # too; always present, empty when nothing was retried, so "no retries" can be told
        # apart from "made before retries were recorded".
        _retries = list(getattr(client, "retry_log", []) or [])
        extra["api_retries"] = {
            "count": len(_retries),
            "timeouts": sum(1 for _r in _retries if _r.get("kind") == "timeout"),
            "events": _retries,
        }
        if api_error is not None:
            extra["api_error"] = api_error
        if status == "context_overflow" and overflow is not None:
            # Only reached if the refusal escaped run_agent (it normally returns
            # context_overflow itself, with its summary, since plan 42 v2.5.32).
            extra["context_overflow"] = overflow
        log.finalize(status, extra=extra)

    # One-line summary to stdout so a batch sweep is readable as it runs.
    print(f"[{args.condition}] {args.model} -> {status} in {log.step} steps")


if __name__ == "__main__":
    main()
