"""
harness/conditions.py
=====================

THE INDEPENDENT VARIABLE OF THE ENTIRE STUDY LIVES IN THIS FILE.

The research question is: does the kind of *verification surface* a coding agent has
access to while it works change the quality of what it builds? A "condition" is one
such surface. Everything else in the harness — the model, the prompt, the loop, the
scoring — is held constant; only which entry of CONDITIONS is selected changes from run
to run. So this small file is, quite literally, the experiment's treatment definition.

HOW IT WORKS
------------
Each condition maps to a list of tool names the model is allowed to call. The agent
loop passes only those tools' schemas to the model (see agent.run_agent), and refuses
any call to a tool outside the list.

THE CORE LADDER (run these on every spec)
-----------------------------------------
The five core conditions form a monotone ladder of verification surface, so results
can be plotted as a curve rather than scattered points:

    no_verification   nothing executes, nothing observed   (baseline)
    static       lint + typecheck signals only            (feedback w/o execution)
    boot_check   one-shot install+boot probe              (cheapest execution signal)
    execution    full shell                               (control arm for visual)
    visual       full shell + screenshots                 (execution + sight)

TARGETED CONDITIONS (run on specific specs only)
------------------------------------------------
    visual_no_shell        sight WITHOUT arbitrary execution (harness-managed
                           start_app + screenshot). Run on visually-hard specs
                           (calendar-week-view, metrics-dashboard) — the only cell
                           that attributes an effect to SEEING rather than RUNNING.
    delayed_verification   full shell, but unlocked only AFTER the model first calls
                           finish (forced write-then-debug waterfall). Run on
                           kanban-board / seat-booking — separates iterative-dev value
                           from final-pass-debugging value, and exposes the
                           escape-hatch effect cleanly (architecture is committed
                           before any runtime friction is felt).
    behavioral             run_tests only. One targeted outing on seat-booking, where
                           authoring tests is the natural way to verify concurrency.

INTERACTIVE CONDITIONS (added on the interactive_support branch, 2026-08)
-------------------------------------------------------------------------
    interactive            full shell + a persistent headless-browser session the model
                           can DRIVE (navigate, click, type, read the page structure,
                           wait). Feedback is text (ARIA/DOM structure + console
                           errors), so this condition runs on text-only models. Extends
                           the ladder one rung past execution: the previous study's
                           residue was apps whose pages LOOK right but ignore every
                           click — sight cannot catch that; hands can. Its clean
                           control is EXECUTION (interactive = execution + touch).
    interactive_screens    interactive + browser_screenshot: pixels of the SESSION's
                           current page (state from clicks/typing included), unlike the
                           stateless screenshot(url) tool. Requires a vision-capable
                           model (member of VISION_CONDITIONS). Its clean controls are
                           interactive (adds sight to touch) and visual (adds touch to
                           sight).

REMOVED / RENAMED CONDITIONS (do not reintroduce silently)
----------------------------------------------------------
    none        duplicated the baseline. Use no_verification.
    self_built  duplicated "execution". Use execution.
    blind       renamed to no_verification (terminology collision + imprecision; see
                _RETIRED below). Archived manifests keep their old names; map via the
                registry and group by harness_git.

A DELIBERATE DESIGN SUBTLETY (read before analyzing results)
------------------------------------------------------------
"visual" includes the full shell because screenshotting a running app requires starting
it. So visual = execution + sight, and its clean control is EXECUTION, not the baseline.
"visual_no_shell" exists precisely to decompose that sum from the other side: sight
with only a harness-managed way to start the app. State both comparisons explicitly in
any writeup.
"""

from __future__ import annotations

# -----------------------------------------------------------------------------
# BASE: the tools every condition gets. These let the model author code at all,
# so they are not part of the experimental manipulation — they are constant
# across every condition.
#   read_file / write_file / edit_file / list_dir : file authoring
#   finish                                          : how the model signals it's done
# -----------------------------------------------------------------------------
BASE = ["read_file", "write_file", "edit_file", "list_dir", "finish"]

# Full shell surface, shared by execution / visual / delayed_verification (post-unlock).
_SHELL = ["run_command", "run_background_command", "run_command_and_capture_output",
          "list_background_commands", "stop_background_command"]

# Persistent-browser surface, shared by the interactive conditions. Text feedback
# (page structure + console errors) — deliberately usable by text-only models;
# browser_screenshot (pixels) is granted separately in interactive_screens only.
_BROWSER = ["browser_navigate", "browser_click", "browser_type", "browser_drag",
            "browser_read", "browser_wait",
            # Multi-page (2026-08). Without these the session held exactly one page, so
            # any capability defined across simultaneous clients — "all connected
            # clients receive updates instantly" — sat outside the verification surface
            # entirely. All six tools above still act on whichever page is active, so a
            # run that never opens a second page is unchanged.
            "browser_new_page", "browser_switch_page", "browser_close_page"]

# -----------------------------------------------------------------------------
# CONDITIONS: condition name -> the complete list of tools allowed in that condition.
# Keep these definitions stable; changing them mid-study changes what the experiment
# measures (the manifest's harness_git field records which version produced a run).
# -----------------------------------------------------------------------------
CONDITIONS: dict[str, list[str]] = {
    # --- core ladder -----------------------------------------------------------
    # No verification at all: the model cannot run, test, type-check, or look at
    # anything it produces. (Formerly named "blind"; renamed - see _RETIRED.)
    "no_verification": BASE,

    # Static signals only: type checker and linter. Errors are surfaced but nothing
    # is ever executed and nothing is rendered. The only verification surface with
    # ZERO escape-hatch risk (no runtime friction can tempt a spec deviation).
    "static":     BASE + ["run_typecheck", "run_lint"],

    # The cheapest possible execution signal: a single self-contained probe that
    # installs dependencies, boots the project's server, and reports whether it came
    # up (plus the first lines of its log). No arbitrary commands. Tests whether the
    # bulk of a full shell's value is just "does it even start".
    "boot_check": BASE + ["check_boot"],

    # Full shell: run anything, read stdout/stderr, manage background processes.
    # This is the correct CONTROL for the visual arm (visual = execution + sight).
    "execution":  BASE + _SHELL,

    # Execution PLUS the ability to see the rendered result.
    "visual":     BASE + _SHELL + ["start_server", "screenshot"],

    # --- targeted conditions ---------------------------------------------------
    # Sight WITHOUT arbitrary execution: the harness starts the app (start_app runs
    # the project's own npm script and reports the URL); the model can only look.
    "visual_no_shell": BASE + ["start_app", "screenshot"],

    # Full shell, but only after the model first declares finish. Phase 1 is
    # tool-identical to no_verification; the first finish call unlocks the shell instead of
    # ending the run (see agent.run_agent + DELAYED_UNLOCK below).
    "delayed_verification": BASE + _SHELL,

    # Behavioral verification: can run the test suite and see pass/fail, but cannot
    # see pixels or run arbitrary commands.
    "behavioral": BASE + ["run_tests"],

    # --- interactive conditions (interactive_support branch) -------------------
    # Full shell + a persistent browser the model can drive. Text-only feedback
    # (structure + console errors), so any model can hold this condition. Clean
    # control: execution (interactive = execution + touch).
    "interactive": BASE + _SHELL + _BROWSER,

    # Interactive + pixels of the live session page. Vision-capable models only.
    # Clean controls: interactive (adds sight to touch) and visual (adds touch to
    # sight). Uses browser_screenshot (captures the SESSION page with its state),
    # not the stateless screenshot(url) tool.
    "interactive_screens": BASE + _SHELL + _BROWSER + ["browser_screenshot"],
}

# Conditions whose tool list changes mid-run: phase "pre" until the first finish call,
# then "post" for the remainder. The agent loop consults this; the manifest records
# both phases and the step at which the unlock happened.
DELAYED_UNLOCK: dict[str, dict[str, list[str]]] = {
    "delayed_verification": {"pre": BASE, "post": BASE + _SHELL},
}

# -----------------------------------------------------------------------------
# CONDITION_BRIEFINGS: a fixed paragraph appended to the system prompt per condition.
#
# WHY THIS EXISTS: some models burned their budget calling tools that don't exist or
# misusing the ones that do, so earlier batches embedded per-condition "CRITICAL"
# instructions in the TASK text. That contaminated the experiment twice over: task_sha
# differed across conditions (breaking the provable input-identity claim), and the
# visual variant went further and MANDATED verification behavior — prescribing the
# dependent variable. Briefings fix both: the task spec stays byte-identical and
# tool-silent; the condition-specific orientation lives here, as part of the treatment
# definition, hashed separately into the manifest (condition_briefing_sha) and checked
# by verify_inputs.py against this registry.
#
# RULES FOR BRIEFING TEXT (enforced by review, asserted by tests where possible):
#   * DESCRIPTIVE ONLY: what tools exist, what they do, environmental facts.
#   * NEVER PRESCRIPTIVE: no "you must verify", no "fix and check again", no quality
#     bars, no workflow mandates. Prescribing process changes what the study measures.
#   * Fixed per condition — never varied per task or per model.
#
# NOTE: delayed_verification's briefing intentionally equals no_verification's. The pre-phase
# model must have NO foreknowledge that tools will unlock (foreknowledge would change
# how it writes); the unlock message (agent.DELAYED_UNLOCK_MESSAGE) reveals the tools.
# -----------------------------------------------------------------------------
_NO_VERIFICATION_BRIEFING = (
    "Environment: no execution or verification tools are available for this task. "
    "You cannot run commands, install packages, start servers, run tests, or take "
    "screenshots — you can only read, write, edit, and list files. Dependencies "
    "declared in package.json files are provisioned by the environment after you "
    "finish; do not attempt to install or run anything."
)

_SHELL_BRIEFING = (
    "Environment: you have shell access in the workspace. run_command executes a "
    "one-shot command and returns its output. For long-running processes (e.g. npm "
    "run dev, npm start) use run_background_command, which returns the PID and the "
    "port(s) the process listens on; list_background_commands and "
    "stop_background_command manage those processes. run_command_and_capture_output "
    "runs a command for a fixed duration and returns what it printed."
)

_INTERACTIVE_BRIEFING = _SHELL_BRIEFING + (
    " Additionally, a persistent headless-browser session is available: "
    "browser_navigate opens a URL and the session then keeps its page and JavaScript "
    "state across your subsequent browser calls; browser_read returns the current "
    "page's structure (interactive elements with selectors, page text) and any new "
    "console errors; browser_click clicks an element identified by a CSS or text "
    "selector; browser_type fills text into an input and can press Enter; "
    "browser_drag drags one element onto another; browser_wait waits for time to "
    "pass or for an element to appear. The session can hold more than one page at "
    "once: browser_new_page opens an additional page and makes it active, "
    "browser_switch_page changes which open page the other browser tools act on, and "
    "browser_close_page closes one. Pages behave like tabs of a single browser - they "
    "share cookies and local storage, while each keeps its own DOM, JavaScript state "
    "and network connections."
)

CONDITION_BRIEFINGS: dict[str, str] = {
    "no_verification": _NO_VERIFICATION_BRIEFING,

    "static": (
        "Environment: you can run a type checker (run_typecheck) and a linter "
        "(run_lint) against the workspace. No other commands can be executed and "
        "nothing can be run, served, or rendered. Dependencies declared in "
        "package.json files are provisioned by the environment after you finish."
    ),

    "boot_check": (
        "Environment: you can call check_boot, which installs the dependencies "
        "declared in package.json files, attempts to start the project's server, and "
        "reports whether it began listening on a port (or its startup log). No other "
        "commands can be executed."
    ),

    "execution": _SHELL_BRIEFING,

    "visual": _SHELL_BRIEFING + (
        " Additionally, start_server serves the workspace's static files over HTTP, "
        "and screenshot renders a URL in a headless browser and returns the captured "
        "image to you."
    ),

    "visual_no_shell": (
        "Environment: you cannot run arbitrary commands. start_app installs the "
        "declared dependencies and starts the application using its own npm dev/start "
        "script, returning the URL(s) it serves; calling start_app again restarts the "
        "app (e.g. after you edit files). screenshot renders a URL in a headless "
        "browser and returns the captured image to you."
    ),

    # Identical to no_verification by design — no foreknowledge of the unlock (see NOTE).
    "delayed_verification": _NO_VERIFICATION_BRIEFING,

    "behavioral": (
        "Environment: you can run the project's test suite with run_tests (it "
        "executes the configured test command in the workspace) and see its output. "
        "No other commands can be executed. Dependencies declared in package.json "
        "files are provisioned by the environment."
    ),

    # RULES REMINDER: descriptive only — what the browser tools do, never whether or
    # how to use them (H2/H5 of the quantization study measure exactly that choice).
    "interactive": _INTERACTIVE_BRIEFING,

    "interactive_screens": _INTERACTIVE_BRIEFING + (
        " browser_screenshot captures an image of the browser session's current page "
        "(including any state from earlier browser actions) and returns it to you."
    ),
}

# -----------------------------------------------------------------------------
# UNIVERSAL_BRIEFING: ONE briefing, byte-identical in EVERY condition (the default
# briefing mode for main study batches).
#
# WHY: per-condition briefings orient models well but make the prompt differ across
# conditions. The universal briefing keeps the ENTIRE prompt (base + briefing + task)
# byte-identical across all conditions — the only thing that varies is the tool
# schema list, which IS the treatment. It still solves the two observed failure
# modes of no briefing at all: (1) a visual-condition model never noticing its
# screenshot tool (observed: a visual run with zero screenshot calls — the arm
# silently degraded to execution), and (2) baseline models hallucinating calls to
# tools that don't exist. Because the text is constant, its salience effect is
# uniform: under this mode, differential tool usage is model behavior, not prompt
# artifact.
#
# RULES: condition-agnostic (must read sensibly and truthfully under EVERY tool
# set), descriptive of the environment, and any encouragement to check work must be
# uniform (it is — one sentence, same for everyone).
# -----------------------------------------------------------------------------
# The ORIGINAL text (condition_briefing_sha 02f244a9339a0cb6). Every run before plan 42
# v2.5.6 carries it; it was the registered briefing again in v2.5.9, and no run was made
# under that version.
UNIVERSAL_BRIEFING_V1 = (
    "Environment: the tools listed in this request are the complete set available to "
    "you. Tools not listed do not exist in this environment and cannot be installed "
    "or obtained. Review what is available and use whatever helps you complete and "
    "check your work. If no installation or execution tools are provided, author "
    "every required file completely from first principles; dependencies declared in "
    "package.json files are provisioned by the environment after you finish."
)

# The v2.5.6 text (condition_briefing_sha c988f43155c49538): the original plus ONE
# sentence, the "tool-neutral strengthening" the GUARD below names as the registered remedy
# for tool neglect. It says what execution tools act on, never whether to use them; it is
# conditional, so it reads truthfully under every tool set; and it names no tool. Added in
# v2.5.6, because gpt-oss reasoned that it had no environment to run anything in and
# Magistral that it only had to create the files; withdrawn in v2.5.9 after their re-smoke;
# reinstated in v2.5.10.
UNIVERSAL_BRIEFING_V256 = (
    "Environment: the tools listed in this request are the complete set available to "
    "you. Tools not listed do not exist in this environment and cannot be installed "
    "or obtained. Review what is available and use whatever helps you complete and "
    "check your work. If execution tools are provided, they give you a live "
    "development environment: the commands you run through them execute for real in "
    "your workspace, on a machine with Node.js and npm installed and the npm registry "
    "reachable, so the packages you install and the servers you start are real. If no "
    "installation or execution tools are provided, author every required file "
    "completely from first principles; dependencies declared in package.json files "
    "are provisioned by the environment after you finish."
)

# THE REGISTERED BRIEFING -- plan v2.5.10: the v2.5.6 text, reinstated at the study lead's
# reading of the gpt-oss and Magistral re-smoke. Both models began running commands under
# it, and gpt-oss's two parse-failure voids fell one in each arm, so they cost runs without
# tilting the contrast. It stands or falls on the smoke of all seven grid models made under
# it (plan §4.1); if it falls, this line names UNIVERSAL_BRIEFING_V1 again. One line on
# purpose: the two texts above never change, only which one is registered.
UNIVERSAL_BRIEFING = UNIVERSAL_BRIEFING_V256

# GUARD: the universal briefing must never name a specific tool. A constant sentence
# that singles out one tool ("if screenshot is provided, use it to verify...") is
# inert in most arms and a MANDATE in exactly one - differential prescription smuggled
# into a byte-identical prompt, the same defect as the old per-condition CRITICAL spec
# lines. If a model under-uses a tool despite uniform salience, that is a FINDING
# (tool neglect); the registered remedies are a tool-neutral strengthening of the
# sentence above, or an explicit mandated-briefing arm - never a tool name here.
_TOOL_NAMES = ("screenshot", "check_boot", "start_app", "start_server", "run_command",
               "run_background_command", "run_tests", "run_typecheck", "run_lint",
               "list_background_commands", "stop_background_command",
               "browser_navigate", "browser_click", "browser_type", "browser_drag",
               "browser_read", "browser_wait", "browser_screenshot")
assert not any(t in UNIVERSAL_BRIEFING for t in _TOOL_NAMES), \
    "UNIVERSAL_BRIEFING names a specific tool - this differentially prescribes " \
    "behavior in one arm. See the GUARD comment above it."

# Names retired because they duplicated another condition byte-for-byte. tools_for()
# rejects them with a pointer instead of silently producing a duplicate treatment arm.
_RETIRED = {
    "none": "no_verification",
    "self_built": "execution",
    # Renamed to avoid (a) collision with InteractWeb-Bench's unrelated "blind
    # execution" failure mode, (b) imprecision (static/boot_check/execution are equally
    # sightless - what the baseline lacks is ANY verification), (c) vision-literature
    # ambiguity. Archived manifests with condition="blind" are no_verification runs
    # from the older instrument (see harness_git).
    "blind": "no_verification",
}

# -----------------------------------------------------------------------------
# VISION_CONDITIONS: the subset of conditions that can produce images (screenshots).
# The agent loop consults this to know whether to inject a captured screenshot back to
# the model as an image message. These conditions require a vision-capable model.
# NOTE: plain "interactive" is deliberately NOT here — its feedback is text-only by
# design, so it runs on text-only models.
# -----------------------------------------------------------------------------
VISION_CONDITIONS = {"visual", "visual_no_shell", "interactive_screens"}


def tools_for(condition: str) -> list[str]:
    """Return the list of allowed tool names for a condition.

    Raises a clear ValueError on an unknown or retired condition rather than silently
    returning an empty/default set — a typo in --condition should stop the run
    immediately, not quietly produce a meaningless data point.
    """
    if condition in _RETIRED:
        raise ValueError(
            f"condition '{condition}' was retired or renamed. "
            f"Use '{_RETIRED[condition]}' (see _RETIRED in conditions.py).")
    if condition not in CONDITIONS:
        raise ValueError(f"unknown condition '{condition}'. "
                         f"choices: {', '.join(CONDITIONS)}")
    return CONDITIONS[condition]
