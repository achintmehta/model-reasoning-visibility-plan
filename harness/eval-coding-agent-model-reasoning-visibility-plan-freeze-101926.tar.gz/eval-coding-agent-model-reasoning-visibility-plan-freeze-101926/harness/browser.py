"""
harness/browser.py
==================

The interactive conditions' browser: ONE persistent headless-Chromium session per run,
driven by the model through the browser_* tools (see tools.py and conditions.py).

WHY A PERSISTENT SESSION (unlike screenshot()'s launch-per-call)
----------------------------------------------------------------
The screenshot tool opens a fresh browser, navigates, captures, and closes. That is
fine for LOOKING, but interaction is stateful: a model that clicks "Add task" and then
types into the input that click revealed needs the SAME page, with its JavaScript
state intact, across those two tool calls. So the session (playwright -> browser ->
page) lives for the whole run on the Tools instance and is closed in Tools.teardown().

FEEDBACK DESIGN (registered as decision D7 of the quantization study)
---------------------------------------------------------------------
Tools: browser_navigate / browser_click / browser_type / browser_drag /
browser_read / browser_wait (+ browser_screenshot in interactive_screens).

Every action returns TEXT-FIRST feedback so the interactive condition works with
text-only models:
    1. what happened (one line),
    2. current URL and title,
    3. any console errors / uncaught page errors since the last report,
    4. the page structure: an ARIA (accessibility) snapshot when the installed
       Playwright supports it, else a deterministic fallback listing interactive
       elements (with usable selectors) plus trimmed page text.
browser_screenshot (granted only in the interactive_screens condition) adds pixels on
top of the same session; the image rides back through ToolResult.image_b64 exactly
like the screenshot tool's.

DESIGN RULES (mirroring the rest of tools.py)
---------------------------------------------
- Every failure returns error TEXT, never an exception: one bad selector must not
  kill a run, and the model must always get something it can react to.
- Every action has a hard timeout: a hung page cannot hang the harness.
- Output is bounded (SNAPSHOT_MAX / CONSOLE_MAX) to protect the context window.
- If the page or browser dies mid-run (crash, closed target), the NEXT browser call
  transparently starts a fresh session and SAYS SO in its output, instead of every
  subsequent call failing. The restart is visible to the model and in the trace, so
  session loss is observable data, not silent recovery.

ENVIRONMENT VARIABLES (all optional; defaults are the study configuration)
-------------------------------------------------------------------------
    HARNESS_BROWSER_HEADED=1     Launch a VISIBLE browser window instead of headless,
                                 so a human can watch the agent work. For debugging
                                 and demos only - see the warning below.
    HARNESS_BROWSER_SLOWMO=<ms>  Pause this long between browser operations. Defaults
                                 to 300 ms when headed (otherwise actions flash past
                                 too fast to follow) and 0 when headless.
    HARNESS_CHROMIUM_PATH=<path> Explicit Chromium executable, for hosts where
                                 Playwright's managed download is unavailable (e.g. an
                                 aarch64 box using the system chromium).

STUDY WARNING: headed mode and slow-motion are NOT the study configuration. A visible
window renders differently from headless (real compositing, window size, GPU path) and
slow-motion changes timing, so either could in principle move outcomes. They are
recorded in the manifest under "browser" so such a run is mechanically identifiable,
and the harness prints a loud warning when they are on. Keep both off for any batch,
and keep HARNESS_CHROMIUM_PATH constant within one - which binary renders is part of
the serving substrate.
"""

from __future__ import annotations

import os
import time
from pathlib import Path

# Hard bounds. Navigation gets longer than in-page actions (cold dev servers compile
# on first request); waits are capped so a model cannot spend its budget sleeping.
NAV_TIMEOUT_MS = 15000
ACTION_TIMEOUT_MS = 10000
WAIT_CAP_MS = 15000
SNAPSHOT_MAX = 2500      # chars of page-structure snapshot per feedback block
CONSOLE_MAX = 5          # console/page errors reported per feedback block
_CONSOLE_KEEP = 50       # ring-buffer size for collected errors
# Drag timing. Mouse-based drag libraries commonly require a brief hold before the
# drag activates and several distinct move events before they treat motion as a drag;
# these two constants are what make the fallback path work on SortableJS / dnd-kit /
# react-beautiful-dnd rather than silently doing nothing.
_DRAG_HOLD_MS = 150      # pause after mousedown, and again before mouseup
_DRAG_STEP_MS = 30       # pause between interpolated move events

_HEADED_WARNED = False   # so the study warning prints once per run, not per launch

# Drag diagnostics. Installed on the page for the duration of one browser_drag call,
# then removed. Records which drag/mouse events the page ACTUALLY received, so a
# failed drag can name the defect ("dragstart fired, the target never received
# dragover") instead of listing three possible causes and leaving the model to guess.
# This reports browser facts, exactly like the console-error capture; it never fixes
# anything and never changes what the page does.
# Shared by the probe and the obscured-target check: a compact element identifier.
_DESCRIBE_JS = """
  const describe = (el) => {
    if (!el || !el.tagName) return String(el);
    const id = el.id ? '#' + el.id : '';
    const cn = (typeof el.className === 'string') ? el.className.trim() : '';
    const cls = cn ? '.' + cn.split(/\\s+/)[0] : '';
    return el.tagName.toLowerCase() + id + cls;
  };
"""

# Is something painted on top of the drop point? Playwright's actionability check
# refuses to drag onto an obscured element and reports only "Timeout 10000ms exceeded",
# which is both slow and uninformative. elementFromPoint answers the question directly,
# in a millisecond, and names the culprit.
_OBSCURED_JS = """(sel) => {
""" + _DESCRIBE_JS + """
  const el = (() => { try { return document.querySelector(sel); } catch (e) { return null; } })();
  if (!el || !el.getBoundingClientRect) return null;
  const r = el.getBoundingClientRect();
  if (r.width < 1 || r.height < 1) return null;             // geometry check covers this
  const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
  if (cx < 0 || cy < 0 || cx > innerWidth || cy > innerHeight) return null;  // off-screen
  const top = document.elementFromPoint(cx, cy);
  if (!top || top === el || el.contains(top)) return null;  // a child is fine
  return describe(top);
}"""


_DRAG_PROBE_JS = """(targetSel) => {
  const seen = Object.create(null);
  const tgt = (() => { try { return document.querySelector(targetSel); } catch (e) { return null; } })();
""" + _DESCRIBE_JS + """
  // Measure the target up front: an element with no area cannot receive a drop, and
  // that is a geometry defect, not a missing-listener defect. Reporting "nothing is
  // listening" for a collapsed element sends the model to rewrite working handlers.
  if (tgt && tgt.getBoundingClientRect) {
    const r = tgt.getBoundingClientRect();
    seen['@targetBox'] = Math.round(r.width) + 'x' + Math.round(r.height);
    seen['@targetArea'] = Math.round(r.width) * Math.round(r.height);
  }
  seen['@targetDesc'] = tgt ? describe(tgt) : 'none';
  const mark = (name, e) => {
    seen[name] = (seen[name] || 0) + 1;
    if (!seen[name + '@first']) seen[name + '@first'] = describe(e.target);
    if (tgt && (e.target === tgt || (tgt.contains && tgt.contains(e.target)))) {
      seen[name + '@target'] = (seen[name + '@target'] || 0) + 1;
    }
  };
  const handlers = {};
  ['dragstart','dragover','dragenter','drop','dragend',
   'mousedown','mousemove','mouseup'].forEach(n => {
    handlers[n] = e => mark(n, e);
    document.addEventListener(n, handlers[n], true);   // capture: see it regardless
  });
  window.__harnessDragProbe = { seen, handlers };
  return true;
}"""

_DRAG_PROBE_READ_JS = """() => {
  const p = window.__harnessDragProbe;
  if (!p) return null;
  Object.keys(p.handlers).forEach(n =>
    document.removeEventListener(n, p.handlers[n], true));
  delete window.__harnessDragProbe;
  return p.seen;
}"""


def _drag_diagnosis(seen: dict | None, html5: bool) -> str:
    """Turn the observed-event tally into one plain sentence naming the defect.

    Only called when the drag did not change the page. Deliberately describes what
    the page did or did not receive; it does not tell the model how to fix its code.
    """
    if not seen:
        return ""
    got = lambda k: int(seen.get(k) or 0)  # noqa: E731
    desc = lambda k: seen.get(k) or ""     # noqa: E731

    # GEOMETRY FIRST. A target with no area cannot receive anything, and the previous
    # wording ("nothing at the drop point is listening") blamed the listeners for what
    # is a layout defect - observed sending a model off to rewrite handlers that were
    # already correct. An empty column with no min-height is the canonical case.
    box, area = desc("@targetBox"), seen.get("@targetArea")
    if box and area is not None and int(area) <= 0:
        return (f" DIAGNOSIS: the target element ({desc('@targetDesc')}) measures "
                f"{box} pixels, so there is no area at the drop point to receive the "
                f"drag.")

    if html5:
        if not got("dragstart"):
            return (" DIAGNOSIS: the browser never fired dragstart, so the source "
                    "element did not begin a drag at all.")
        if not got("dragover@target") and not got("dragenter@target"):
            # Say WHAT received the events rather than inferring that nothing listened.
            # "an overlay/child intercepted the drop point" and "no handler is wired up"
            # need opposite fixes, and they used to produce the same sentence.
            hit = desc("dragover@first") or desc("dragenter@first")
            where = (f" they reached {hit} instead" if hit else
                     " no element received them")
            return (f" DIAGNOSIS: dragstart fired, but the requested target "
                    f"({desc('@targetDesc')}) never received dragover/dragenter -"
                    f"{where}.")
        if not got("drop@target"):
            return (" DIAGNOSIS: the target received dragover but no drop event fired "
                    "- a dragover handler must call preventDefault() for a drop to be "
                    "allowed.")
        return (" DIAGNOSIS: a drop event reached the target, but the page did not "
                "change - the drop handler ran without moving anything.")
    if not got("mousedown"):
        return (" DIAGNOSIS: the source element never received mousedown, so no drag "
                "could start.")
    if got("mousemove") < 3:
        return (f" DIAGNOSIS: only {got('mousemove')} mousemove event(s) reached the "
                f"page during the drag.")
    if not got("mouseup"):
        return " DIAGNOSIS: the drag never completed - no mouseup reached the page."
    hit = desc("mouseup@first")
    if hit and not got("mouseup@target"):
        return (f" DIAGNOSIS: the full mousedown/mousemove/mouseup sequence reached the "
                f"page, but the pointer finished over {hit} rather than the requested "
                f"target ({desc('@targetDesc')}).")
    return (" DIAGNOSIS: the page received the full mousedown/mousemove/mouseup "
            "sequence but nothing moved - no drag behavior appears to be wired up at "
            "the drop point.")


def _is_closed(page) -> bool:
    """True when a Playwright page is closed or unreachable. Never raises."""
    try:
        return page.is_closed()
    except Exception:  # noqa: BLE001 - connection gone counts as closed
        return True


def _env_flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


def browser_launch_config() -> dict:
    """Resolve the env-driven browser launch settings.

    Returned verbatim into the run manifest (agent.py) so any run made with a
    visible window or slow-motion is mechanically identifiable afterwards, instead
    of being indistinguishable from a study-configuration run.
    """
    headed = _env_flag("HARNESS_BROWSER_HEADED")
    raw = os.environ.get("HARNESS_BROWSER_SLOWMO", "").strip()
    try:
        slow_mo = int(raw) if raw else (300 if headed else 0)
    except ValueError:
        slow_mo = 300 if headed else 0
    return {"headed": headed, "slow_mo_ms": slow_mo,
            "executable_path": os.environ.get("HARNESS_CHROMIUM_PATH") or None}


def _launch_kwargs() -> dict:
    """Playwright launch options, plus the one-time headed warning."""
    global _HEADED_WARNED
    cfg = browser_launch_config()
    if cfg["headed"] and not _HEADED_WARNED:
        _HEADED_WARNED = True
        print("WARNING: HARNESS_BROWSER_HEADED is set - this run uses a VISIBLE "
              f"browser window with slow_mo={cfg['slow_mo_ms']}ms. Rendering and "
              "timing differ from the headless study configuration; the manifest "
              "records this under \"browser\". Do not mix such runs into a batch.")
    kwargs = {"headless": not cfg["headed"], "slow_mo": cfg["slow_mo_ms"]}
    if cfg["executable_path"]:
        kwargs["executable_path"] = cfg["executable_path"]
    return kwargs


def _launch_hint(e: Exception) -> str:
    """Turn the usual headed-mode launch failures into an actionable sentence."""
    msg = str(e).lower()
    # Playwright words this several ways ("XServer", "X server", "cannot open display").
    if any(s in msg for s in ("xserver", "x server", "display", "xvfb", "headed browser")):
        return (" HINT: a visible browser needs a display. On WSL2 make sure WSLg is "
                "available (echo $DISPLAY should be non-empty); over plain SSH use "
                "X forwarding, or unset HARNESS_BROWSER_HEADED to run headless.")
    return ""


class BrowserSession:
    """One persistent headless-browser session, created lazily on first use.

    Public methods (navigate/click/type_text/read/wait/screenshot) all return plain
    strings (screenshot returns (text, b64)) and NEVER raise: errors come back as
    'ERROR: ...' text for the model to react to.
    """

    def __init__(self, artifacts_dir: Path | None = None):
        self._pw = None
        self._browser = None
        self._context = None
        # MULTI-PAGE. Label -> Page, insertion-ordered, plus which label is active.
        # Every action tool operates on the ACTIVE page, so their schemas are unchanged;
        # a run that never calls browser_new_page behaves exactly as it did when the
        # session held a single page, including its feedback text byte for byte.
        #
        # Why this exists: with one page, a spec whose core capability is multi-client
        # ("all connected clients receive updates instantly") cannot be verified at all
        # — the central behavior is outside the verification surface. Observed: a model
        # announced it would open a second tab to test SSE, called browser_navigate on
        # the same page, and reported success for a test it never ran.
        self._pages: dict[str, "object"] = {}
        self._active: str | None = None
        self._page_seq = 0              # monotonic; labels are never reused
        self.artifacts_dir = artifacts_dir
        self._console: list[str] = []   # collected console/page errors (ring buffer)
        self._console_reported = 0      # how many of those have been shown already
        self._restart_count = 0         # whole-browser restarts over the run
        self._page_restart_count = 0    # active page died and was replaced, browser OK
        self._dialogs: list[str] = []   # native dialogs auto-dismissed since last report
        self._pending_note: str | None = None   # drained into the next feedback block

    # ------------------------------------------------------------------ pages
    @property
    def _page(self):
        """The active page, or None. Read-only: the registry is the source of truth."""
        return self._pages.get(self._active) if self._active else None

    def _drop_active_page(self):
        """Forget the active page (it died or was closed) and fall back to another."""
        if self._active is not None:
            self._pages.pop(self._active, None)
        self._active = next(reversed(self._pages), None) if self._pages else None

    def _prune_closed(self):
        """Drop pages the browser has closed underneath us (e.g. window.close())."""
        for label in [lbl for lbl, pg in self._pages.items() if _is_closed(pg)]:
            self._pages.pop(label, None)
            if self._active == label:
                self._active = None
        if self._active is None and self._pages:
            self._active = next(reversed(self._pages))

    def _label_of(self, page) -> str | None:
        for label, pg in self._pages.items():
            if pg is page:
                return label
        return None

    @staticmethod
    def _normalize_label(value) -> str:
        """Accept 'page-2', 'page 2', '2', or 2 — models are inconsistent about ids."""
        s = str(value).strip().lower().replace(" ", "-")
        if s.startswith("page-"):
            s = s[5:]
        elif s.startswith("page"):
            s = s[4:]
        return f"page-{s.strip('-')}"

    def _pages_line(self) -> str:
        """One line naming every open page. Emitted ONLY when more than one is open, so
        single-page runs produce exactly the feedback they did before this existed."""
        if len(self._pages) < 2:
            return ""
        bits = []
        for label, pg in self._pages.items():
            try:
                url = pg.url
            except Exception:  # noqa: BLE001
                url = "?"
            bits.append(f"{label}{' (active)' if label == self._active else ''} {url}")
        return "OPEN PAGES: " + " | ".join(bits)

    def _register_page(self, page) -> str:
        """Attach listeners to a freshly created page, register it, and make it active."""
        self._page_seq += 1
        label = f"page-{self._page_seq}"
        page.set_default_timeout(ACTION_TIMEOUT_MS)
        page.set_default_navigation_timeout(NAV_TIMEOUT_MS)

        # Collect console errors and uncaught page exceptions as they happen; they are
        # surfaced in the next feedback block (bounded by CONSOLE_MAX per report). The
        # page label is prefixed only while more than one page is open, so single-page
        # console output is unchanged.
        def _tag(text: str) -> str:
            return f"[{label}] {text}" if len(self._pages) > 1 else text

        def _on_console(msg):
            try:
                if msg.type == "error":
                    self._push_console(_tag(f"console.error: {msg.text}"))
            except Exception:  # noqa: BLE001 - never let a listener kill the run
                pass

        def _on_pageerror(err):
            try:
                self._push_console(_tag(f"uncaught page error: {err}"))
            except Exception:  # noqa: BLE001
                pass

        # NATIVE DIALOGS (alert / confirm / prompt). Playwright auto-dismisses these
        # when no handler is registered, and SILENTLY - so a click that opens a
        # prompt() looks to the model exactly like a click that did nothing. Observed:
        # an agent clicked its own "Add Card" button, whose handler is prompt(), saw no
        # change, and could not tell why. We must still dismiss (an open dialog blocks
        # every subsequent browser operation), but we now RECORD it and say so.
        def _on_dialog(dialog):
            try:
                self._dialogs.append(_tag(f"{dialog.type}: {dialog.message!r}"))
            except Exception:  # noqa: BLE001
                self._dialogs.append("dialog")
            try:
                dialog.dismiss()
            except Exception:  # noqa: BLE001
                pass

        page.on("console", _on_console)
        page.on("pageerror", _on_pageerror)
        page.on("dialog", _on_dialog)
        self._pages[label] = page
        self._active = label
        return label

    # ------------------------------------------------------------------ lifecycle
    def _ensure_page(self):
        """Return (page, restarted). Starts Playwright/Chromium lazily; if a previous
        page/browser died, starts a fresh one and reports restarted=True."""
        # Same host-validation bypass as tools.screenshot() (WSL / unsupported Ubuntu).
        os.environ.setdefault("PLAYWRIGHT_SKIP_VALIDATE_HOST_REQUIREMENTS", "1")
        os.environ.setdefault("PLAYWRIGHT_HOST_PLATFORM_OVERRIDE", "ubuntu22.04-x64")
        # Imported lazily: the harness has zero hard Playwright dependency unless an
        # interactive/visual run actually needs it.
        from playwright.sync_api import sync_playwright

        self._prune_closed()
        if self._page is not None:
            try:
                if not self._page.is_closed():
                    return self._page, False
            except Exception:  # noqa: BLE001 - connection to browser gone
                pass

        # The browser is alive but has no usable page — the model closed them all, or
        # the active one died while others survived. That is NOT a session restart, and
        # calling it one would tell the model its earlier state is gone when it isn't.
        if self._browser is not None and self._context is not None:
            try:
                if self._pages:                      # a sibling page is still open
                    self._active = next(reversed(self._pages))
                    self._page_restart_count += 1
                    self._pending_note = (
                        f"NOTE: the page you were acting on had closed; "
                        f"{self._active} is now the active page.")
                    return self._pages[self._active], False
                page = self._context.new_page()
                label = self._register_page(page)
                self._page_restart_count += 1
                self._pending_note = (
                    f"NOTE: the page you were acting on had closed, so a blank one "
                    f"({label}) was created for this call — its DOM and JavaScript "
                    f"state are gone. The browser itself is still the same one, so "
                    f"cookies and local storage survived. Navigate it before acting "
                    f"on it.")
                return page, False
            except Exception:  # noqa: BLE001 - browser really is gone; fall through
                pass

        restarted = self._browser is not None or bool(self._pages)
        # Tear down whatever half-dead state remains before starting over.
        for closer in (lambda: self._browser.close(), lambda: self._pw.stop()):
            try:
                if restarted:
                    closer()
            except Exception:  # noqa: BLE001
                pass
        if restarted:
            self._pw = None
            self._browser = None
            self._context = None
        self._pages.clear()
        self._active = None

        if self._pw is None:
            self._pw = sync_playwright().start()
        try:
            self._browser = self._pw.chromium.launch(**_launch_kwargs())
        except Exception as e:  # noqa: BLE001 - add the display hint, then re-raise
            raise RuntimeError(f"{e}{_launch_hint(e)}") from e
        # ONE context shared by every page, so additional pages behave like additional
        # TABS of the same browser: same cookies, same localStorage, same origin state.
        # browser.new_page() would give each page its own context, which models a second
        # *browser* rather than a second tab and would silently break any app that keeps
        # session state client-side.
        self._context = self._browser.new_context(viewport={"width": 1280,
                                                            "height": 800})
        self._register_page(self._context.new_page())
        if restarted:
            self._restart_count += 1
        return self._page, restarted

    # ------------------------------------------------------------------ page tools
    def new_page(self, url: str | None = None) -> str:
        """Open an additional page (tab) in the same browser and make it active."""
        try:
            self._ensure_page()                       # guarantees browser + context
        except Exception as e:  # noqa: BLE001
            return f"ERROR: could not start the browser: {e}"
        try:
            label = self._register_page(self._context.new_page())
        except Exception as e:  # noqa: BLE001
            self._handle_dead_session(e)
            return f"ERROR: could not open a new page: {e}"
        if url:
            nav = self.navigate(url)
            if nav.startswith("ERROR"):
                return nav
            return f"Opened {label} and " + nav[0].lower() + nav[1:]
        return self._feedback(
            f"Opened {label} (blank) and made it the active page. Pages share cookies "
            f"and local storage, like tabs of one browser.")

    def switch_page(self, page: str) -> str:
        """Make an already-open page the active one."""
        try:
            self._ensure_page()
        except Exception as e:  # noqa: BLE001
            return f"ERROR: could not start the browser: {e}"
        self._prune_closed()
        label = self._normalize_label(page)
        if label not in self._pages:
            return (f"ERROR: there is no open page called {label!r}. Currently open: "
                    f"{', '.join(self._pages) or 'none'}. Use browser_new_page to open "
                    f"another one.")
        if label == self._active:
            return self._feedback(f"{label} was already the active page.")
        self._active = label
        return self._feedback(f"Switched to {label}.")

    def close_page(self, page: str | None = None) -> str:
        """Close a page. Defaults to the active one."""
        try:
            self._ensure_page()
        except Exception as e:  # noqa: BLE001
            return f"ERROR: could not start the browser: {e}"
        self._prune_closed()
        label = self._normalize_label(page) if page else self._active
        if label not in self._pages:
            return (f"ERROR: there is no open page called {label!r}. Currently open: "
                    f"{', '.join(self._pages) or 'none'}.")
        try:
            self._pages[label].close()
        except Exception:  # noqa: BLE001 - already gone is fine; we drop it either way
            pass
        self._pages.pop(label, None)
        if self._active == label:
            self._active = next(reversed(self._pages), None) if self._pages else None
        if self._active is None:
            return (f"Closed {label}. No browser page is open now; the next browser "
                    f"call will open a blank one.")
        return self._feedback(f"Closed {label}. {self._active} is now the active page.")

    def _push_console(self, line: str):
        self._console.append(line)
        if len(self._console) > _CONSOLE_KEEP:
            # Drop oldest; keep the reported-pointer consistent.
            drop = len(self._console) - _CONSOLE_KEEP
            self._console = self._console[drop:]
            self._console_reported = max(0, self._console_reported - drop)

    def close(self):
        """Close the browser session. Called from Tools.teardown(); never raises."""
        for closer in (lambda: self._context.close(),
                       lambda: self._browser.close(),
                       lambda: self._pw.stop()):
            try:
                closer()
            except Exception:  # noqa: BLE001
                pass
        self._pw = None
        self._browser = None
        self._context = None
        self._pages.clear()
        self._active = None

    @property
    def page_restart_count(self) -> int:
        """Times the ACTIVE page died and had to be replaced while the browser lived.

        Kept separate from restart_count: a dead page loses DOM and JS state, a dead
        browser loses everything including cookies. Conflating them would hide which
        kind of instability a run actually hit.
        """
        return self._page_restart_count

    @property
    def page_count(self) -> int:
        """How many pages are open right now (1 for every single-page run)."""
        return len(self._pages)

    @property
    def pages_opened(self) -> int:
        """How many pages this session ever opened — the multi-client uptake measure."""
        return self._page_seq

    @property
    def restart_count(self) -> int:
        """How many times the session had to be restarted mid-run (0 = never died)."""
        return self._restart_count

    # ------------------------------------------------------------------ feedback
    def _new_console_errors(self) -> list[str]:
        fresh = self._console[self._console_reported:]
        self._console_reported = len(self._console)
        return fresh[-CONSOLE_MAX:]

    def _drain_dialogs(self) -> str:
        """Report (and clear) native dialogs auto-dismissed since the last report."""
        if not self._dialogs:
            return ""
        items = "; ".join(self._dialogs[:CONSOLE_MAX])
        self._dialogs = []
        return ("\nNOTE: the page opened a native browser dialog (" + items +
                "). It was dismissed automatically - an open dialog blocks every "
                "further browser operation. Native alert/confirm/prompt dialogs "
                "cannot be filled in or accepted through these tools.")

    def _snapshot(self) -> str:
        """The page-structure text fed back to the model.

        Preferred: Playwright's ARIA snapshot (a YAML-ish accessibility tree - compact,
        stable, and it names roles and accessible text the model can click by).
        Fallback (older Playwright): a deterministic summary of interactive elements
        with usable selectors, plus trimmed page text.
        """
        try:
            snap = self._page.locator("body").aria_snapshot(timeout=ACTION_TIMEOUT_MS)
            if snap and snap.strip():
                return snap
        except Exception:  # noqa: BLE001 - fall through to the manual snapshot
            pass
        try:
            return self._fallback_snapshot()
        except Exception as e:  # noqa: BLE001
            return f"(page structure unavailable: {e})"

    def _fallback_snapshot(self) -> str:
        """Interactive-element summary + trimmed text, computed in the page."""
        js = """
        () => {
          const pick = (el) => {
            const t = (el.innerText || el.value || el.placeholder || '').trim()
                        .replace(/\\s+/g, ' ').slice(0, 60);
            let sel = el.tagName.toLowerCase();
            if (el.id) sel = '#' + el.id;
            else if (el.name) sel += `[name="${el.name}"]`;
            else if (el.className && typeof el.className === 'string')
              sel += '.' + el.className.trim().split(/\\s+/).slice(0, 2).join('.');
            return `${el.tagName.toLowerCase()}  selector: ${sel}` +
                   (t ? `  text: "${t}"` : '');
          };
          const els = Array.from(document.querySelectorAll(
            'a, button, input, select, textarea, [role=button], [onclick]')).slice(0, 40);
          const text = (document.body.innerText || '').replace(/\\n{3,}/g, '\\n\\n')
                         .slice(0, 800);
          return 'INTERACTIVE ELEMENTS (' + els.length + ' shown):\\n' +
                 els.map(pick).join('\\n') + '\\n\\nPAGE TEXT (start):\\n' + text;
        }
        """
        return self._page.evaluate(js)

    def _feedback(self, action_line: str, restarted: bool = False,
                  include_snapshot: bool = True) -> str:
        parts = [action_line]
        if restarted:
            parts.append("NOTE: the previous browser session had ended; a fresh browser "
                         "session was started for this call (page state from earlier "
                         "calls is gone).")
        if self._pending_note:
            parts.append(self._pending_note)
            self._pending_note = None
        try:
            parts.append(f"URL: {self._page.url}  TITLE: {self._page.title()}")
        except Exception:  # noqa: BLE001
            pass
        pages = self._pages_line()
        if pages:
            parts.append(pages)
        errs = self._new_console_errors()
        if errs:
            parts.append("CONSOLE ERRORS (new since last report):\n" + "\n".join(errs))
        dialogs = self._drain_dialogs()
        if dialogs:
            parts.append(dialogs.lstrip("\n"))
        if include_snapshot:
            snap = self._snapshot()
            if len(snap) > SNAPSHOT_MAX:
                snap = snap[:SNAPSHOT_MAX] + f"\n...[structure truncated at {SNAPSHOT_MAX} chars]"
            parts.append("PAGE STRUCTURE:\n" + snap)
        return "\n".join(parts)

    def _handle_dead_session(self, e: Exception):
        """If the exception means the page/browser is gone, drop it so the next call
        restarts cleanly."""
        msg = str(e).lower()
        if any(s in msg for s in ("has been closed", "target closed", "browser closed",
                                  "connection closed", "not connected")):
            self._drop_active_page()

    # ------------------------------------------------------------------ actions
    def navigate(self, url: str) -> str:
        try:
            page, restarted = self._ensure_page()
        except Exception as e:  # noqa: BLE001
            return (f"ERROR: could not start the browser: {e} "
                    f"(is Playwright + Chromium installed on this host?)")
        try:
            resp = page.goto(url, wait_until="load", timeout=NAV_TIMEOUT_MS)
            try:  # settle SPAs briefly; never fail the call over this
                page.wait_for_load_state("networkidle", timeout=3000)
            except Exception:  # noqa: BLE001
                pass
            status = resp.status if resp is not None else "?"
            return self._feedback(f"Navigated to {url} [HTTP {status}]", restarted)
        except Exception as e:  # noqa: BLE001
            self._handle_dead_session(e)
            hint = ""
            if "err_connection_refused" in str(e).lower():
                hint = (" HINT: nothing is listening at that address. Start your server "
                        "first (e.g. with run_background_command) and check which port "
                        "it reports.")
            return f"ERROR: navigation to {url} failed: {e}{hint}"

    def click(self, selector: str) -> str:
        try:
            page, restarted = self._ensure_page()
        except Exception as e:  # noqa: BLE001
            return f"ERROR: could not start the browser: {e}"
        try:
            before = page.content()
            page.click(selector, timeout=ACTION_TIMEOUT_MS)
            try:
                page.wait_for_load_state("load", timeout=3000)
            except Exception:  # noqa: BLE001
                pass
            page.wait_for_timeout(300)   # let click handlers render their effects
            # DOM-CHANGE REPORT, symmetric with browser_drag: a click that changed
            # nothing otherwise reads identically to one that worked. Reported, never
            # enforced - a page may legitimately re-render to an identical DOM (and a
            # dialog, reported separately below, is a common reason nothing changed).
            try:
                changed = page.content() != before
            except Exception:  # noqa: BLE001
                changed = True
            note = ("" if changed else
                    " NOTE: nothing in the page's DOM changed as a result of this "
                    "click.")
            return self._feedback(f"Clicked {selector!r}.{note}", restarted)
        except Exception as e:  # noqa: BLE001
            self._handle_dead_session(e)
            return (f"ERROR: could not click {selector!r}: {e} "
                    f"HINT: call browser_read to see the current page's elements and "
                    f"usable selectors; text selectors like text=Add task also work.")

    def type_text(self, selector: str, text: str, press_enter: bool = False) -> str:
        try:
            page, restarted = self._ensure_page()
        except Exception as e:  # noqa: BLE001
            return f"ERROR: could not start the browser: {e}"
        try:
            page.fill(selector, text, timeout=ACTION_TIMEOUT_MS)
            if press_enter:
                page.press(selector, "Enter", timeout=ACTION_TIMEOUT_MS)
                try:
                    page.wait_for_load_state("load", timeout=3000)
                except Exception:  # noqa: BLE001
                    pass
            page.wait_for_timeout(200)
            action = (f"Typed {text!r} into {selector!r}"
                      + (" and pressed Enter." if press_enter else "."))
            return self._feedback(action, restarted)
        except Exception as e:  # noqa: BLE001
            self._handle_dead_session(e)
            return (f"ERROR: could not type into {selector!r}: {e} "
                    f"HINT: the selector must match an <input>, <textarea>, or other "
                    f"fillable element; call browser_read to see what is on the page.")

    def read(self, selector: str | None = None) -> str:
        try:
            page, restarted = self._ensure_page()
        except Exception as e:  # noqa: BLE001
            return f"ERROR: could not start the browser: {e}"
        try:
            if page.url in ("about:blank", ""):
                return ("The browser session has no page loaded yet. Call "
                        "browser_navigate(url) first.")
            if selector:
                # MATCH DISAMBIGUATION: an empty result used to be three different
                # situations wearing the same face - the selector matched nothing, it
                # matched an element that happens to be empty, or it matched several
                # and the first one is empty. Observed: a model read '.card-list', got
                # nothing back, and could not tell which. Report the count.
                loc_all = page.locator(selector)
                try:
                    n = loc_all.count()
                except Exception:  # noqa: BLE001
                    n = -1
                if n == 0:
                    return (f"Selector {selector!r} matched NO elements on the current "
                            f"page. Call browser_read with no selector to see what is "
                            f"there." + self._drain_dialogs())
                loc = loc_all.first
                try:
                    snap = loc.aria_snapshot(timeout=ACTION_TIMEOUT_MS)
                except Exception:  # noqa: BLE001
                    snap = loc.inner_text(timeout=ACTION_TIMEOUT_MS)
                if len(snap) > SNAPSHOT_MAX:
                    snap = snap[:SNAPSHOT_MAX] + "\n...[truncated]"
                head = (f"Content of {selector!r}"
                        + (f" (matched {n} elements; showing the first)" if n > 1
                           else "") + ":")
                # An element that exists but holds nothing renders as a bare role
                # (an empty <ul> aria-snapshots to just "- list"), which reads like a
                # truncated result rather than an empty container. Check the element's
                # own text instead of the snapshot's emptiness.
                try:
                    inner = loc.inner_text(timeout=ACTION_TIMEOUT_MS)
                except Exception:  # noqa: BLE001 - hidden/detached: skip the note
                    inner = None
                if not snap.strip():
                    snap = "(no content)"
                if inner is not None and not inner.strip():
                    snap += ("\n(NOTE: this element contains no text - it exists but "
                             "is empty)")
                errs = self._new_console_errors()
                err_block = ("\nCONSOLE ERRORS (new since last report):\n"
                             + "\n".join(errs)) if errs else ""
                return f"{head}\n{snap}{err_block}{self._drain_dialogs()}"
            return self._feedback("Read the current page.", restarted)
        except Exception as e:  # noqa: BLE001
            self._handle_dead_session(e)
            return f"ERROR: could not read the page: {e}"

    def wait(self, ms: int | None = None, selector: str | None = None) -> str:
        try:
            page, restarted = self._ensure_page()
        except Exception as e:  # noqa: BLE001
            return f"ERROR: could not start the browser: {e}"
        timeout = min(int(ms), WAIT_CAP_MS) if ms else (
            WAIT_CAP_MS if selector else 1000)
        try:
            if selector:
                page.wait_for_selector(selector, timeout=timeout)
                return self._feedback(
                    f"Element {selector!r} appeared (waited up to {timeout} ms).",
                    restarted)
            page.wait_for_timeout(timeout)
            return self._feedback(f"Waited {timeout} ms.", restarted)
        except Exception as e:  # noqa: BLE001
            self._handle_dead_session(e)
            return (f"ERROR: wait failed: {e} "
                    f"(waits are capped at {WAIT_CAP_MS} ms; the element may simply "
                    f"not exist - call browser_read to inspect the page).")

    def drag(self, source: str, target: str) -> str:
        """Drag the element matched by `source` onto the element matched by `target`.

        WHY THIS IS NOT ONE LINE OF PLAYWRIGHT
        --------------------------------------
        "Drag and drop" on the web is two unrelated mechanisms, and a tool that
        implements only one silently fails on half the apps an agent will build:

          (a) HTML5 native DnD - elements with draggable="true" plus dragstart /
              dragover / drop handlers. These listen for DRAG events, which are NOT
              produced by synthesized mouse movement; the browser must dispatch real
              drag events. Playwright's locator.drag_to() does exactly that, so it is
              tried FIRST.
          (b) Mouse-based drag libraries (SortableJS, dnd-kit, react-beautiful-dnd,
              hand-rolled mousemove handlers) - these listen for mousedown / mousemove
              / mouseup and frequently impose an ACTIVATION CONSTRAINT: a minimum drag
              distance or a brief hold before the drag is recognised. A single jump
              from source to target fires too few events and does nothing at all.
              The fallback below holds after mousedown, moves in several interpolated
              steps (so movement is observed as movement), settles over the target,
              pauses again, then releases.

        Strategy: DETECT FIRST, then act. The source (or an ancestor) carrying
        draggable="true" is the defining marker of mechanism (a); anything else is
        treated as (b).

        Detection rather than try-(a)-then-fall-back-to-(b) is deliberate and was
        forced by measurement: Playwright enables CDP drag interception while
        drag_to() runs, and that interception SWALLOWS most subsequent synthesized
        mouse moves. Measured on the harness's own drag test page, a mouse sequence
        that delivers 14 mousemove events on a clean page delivers only 4 after a
        drag_to() attempt - far too few to satisfy any activation constraint, so the
        fallback silently did nothing. Order is therefore not a free choice: (b) may
        follow (a) only never, while (a) may safely follow (b).

        Accordingly: mechanism (a) elements use drag_to alone; everything else uses
        the mouse sequence and, only if the DOM did not change, tries drag_to as a
        second attempt (safe in that direction). The report names the mechanism used
        and says whether the page actually changed, so a model that drags something
        unmovable is told plainly instead of being left to assume success.

        WHEN A DRAG FAILS, the call reports WHY. An event probe (_DRAG_PROBE_JS) runs
        for the duration of the call and records which drag/mouse events the page
        actually received and which reached the drop target, so the feedback names the
        defect - "dragstart fired, but the target never received dragover" - rather
        than listing three possible causes. Observed in a real run: an agent's kanban
        board attached drop handlers to CARDS only and none to the columns, so a card
        could never be dropped into an empty column; the old message described the
        symptom, this one names the cause. The probe reports browser facts, exactly as
        the console-error capture does; it changes nothing about the page and never
        suggests a fix.

        DOM-change detection is a heuristic, not a correctness check: an app may
        legitimately re-render to an identical DOM. It is reported, never enforced.
        """
        try:
            page, restarted = self._ensure_page()
        except Exception as e:  # noqa: BLE001
            return f"ERROR: could not start the browser: {e}"
        try:
            src = page.locator(source).first
            tgt = page.locator(target).first
            # Fail early and clearly if either side does not exist: "drag did nothing"
            # is a much worse message than "the target selector matched no element".
            for label, loc, sel in (("source", src, source), ("target", tgt, target)):
                if loc.count() == 0:
                    return (f"ERROR: the {label} selector {sel!r} matched no element. "
                            f"Call browser_read to see the current page's elements.")

            # GEOMETRY PRE-FLIGHT, before either mechanism is attempted. An element can
            # have a bounding box and still have no AREA — an empty container with no
            # min-height collapses to zero height, the canonical kanban defect. On the
            # mouse path the drop point would be a degenerate point on a line; on the
            # HTML5 path Playwright's actionability check simply times out after 10s and
            # reports "Timeout exceeded", which tells the model nothing at all. Measure
            # first and say what was measured.
            for lbl, loc, sel in (("source", src, source), ("target", tgt, target)):
                try:
                    bx = loc.bounding_box()
                except Exception:  # noqa: BLE001 - fall through to the normal paths
                    continue
                if bx is None:
                    return (f"ERROR: could not drag {source!r} onto {target!r}: the "
                            f"{lbl} element {sel!r} is not visible on the page (no "
                            f"bounding box). Scroll it into view or check the selectors "
                            f"with browser_read.")
                if bx["width"] < 1 or bx["height"] < 1:
                    return (f"ERROR: could not drag {source!r} onto {target!r}: the "
                            f"{lbl} element {sel!r} measures "
                            f"{round(bx['width'])}x{round(bx['height'])} pixels, so "
                            f"there is no area to drag "
                            f"{'from' if lbl == 'source' else 'to'}. The element exists "
                            f"and may be wired up correctly; it has no size.")

            # Is the drop point covered by something else? A descendant is fine (a card
            # list full of cards); an unrelated element on top is not, and it needs the
            # opposite fix to a missing handler.
            try:
                covering = page.evaluate(_OBSCURED_JS, target)
            except Exception:  # noqa: BLE001 - never let the check fail the drag
                covering = None
            if covering:
                return (f"ERROR: could not drag {source!r} onto {target!r}: the target "
                        f"exists but {covering} is painted on top of it, so the drop "
                        f"point belongs to that element. Drag onto {covering}, or move "
                        f"whatever is covering the target out of the way.")

            before = page.content()

            # Install the event probe for the duration of this call (removed below).
            try:
                page.evaluate(_DRAG_PROBE_JS, target)
            except Exception:  # noqa: BLE001 - diagnostics must never fail the drag
                pass

            def html5_drag():
                src.drag_to(tgt, timeout=ACTION_TIMEOUT_MS)
                page.wait_for_timeout(250)

            def mouse_drag() -> str | None:
                """Returns an error string, or None on success (of the attempt)."""
                sb, tb = src.bounding_box(), tgt.bounding_box()
                if not sb or not tb:      # re-checked: the page may have re-rendered
                    return (f"ERROR: could not drag {source!r} onto {target!r}: one of "
                            f"them is not visible on the page (no bounding box). "
                            f"Scroll it into view or check the selectors with "
                            f"browser_read.")
                sx, sy = sb["x"] + sb["width"] / 2, sb["y"] + sb["height"] / 2
                tx, ty = tb["x"] + tb["width"] / 2, tb["y"] + tb["height"] / 2
                page.mouse.move(sx, sy)
                page.mouse.down()
                page.wait_for_timeout(_DRAG_HOLD_MS)       # satisfy hold-to-activate
                steps = 12                                  # enough motion to register
                for i in range(1, steps + 1):
                    page.mouse.move(sx + (tx - sx) * i / steps,
                                    sy + (ty - sy) * i / steps)
                    page.wait_for_timeout(_DRAG_STEP_MS)
                page.mouse.move(tx, ty)                     # settle over the target
                page.wait_for_timeout(_DRAG_HOLD_MS)
                page.mouse.up()
                page.wait_for_timeout(300)
                return None

            # Which mechanism does this element use? draggable="true" on the element
            # or an ancestor is HTML5 DnD; anything else is a mouse-based library.
            try:
                is_html5 = bool(src.evaluate(
                    "el => !!(el.closest && el.closest('[draggable=\"true\"]'))"))
            except Exception:  # noqa: BLE001 - detection must never fail the call
                is_html5 = False

            if is_html5:
                mechanism = "html5-drag-events"
                html5_drag()
            else:
                mechanism = "mouse-sequence"
                err = mouse_drag()
                if err:
                    try:
                        page.evaluate(_DRAG_PROBE_READ_JS)   # uninstall the probe
                    except Exception:  # noqa: BLE001
                        pass
                    return err
                if page.content() == before:
                    # Safe direction: no interception has been enabled yet.
                    mechanism = "mouse-sequence+html5-retry"
                    try:
                        html5_drag()
                    except Exception:  # noqa: BLE001 - report no-change below
                        pass

            changed = page.content() != before
            try:
                seen = page.evaluate(_DRAG_PROBE_READ_JS)     # read and uninstall
            except Exception:  # noqa: BLE001
                seen = None

            if changed:
                note = "The page changed as a result."
            else:
                note = ("NOTE: the page DID NOT change."
                        + _drag_diagnosis(seen, is_html5)
                        + " Check the page structure below.")
            return self._feedback(
                f"Dragged {source!r} onto {target!r} [{mechanism}]. {note}", restarted)
        except Exception as e:  # noqa: BLE001
            self._handle_dead_session(e)
            return (f"ERROR: could not drag {source!r} onto {target!r}: {e} "
                    f"HINT: call browser_read to check both selectors exist and are "
                    f"visible.")

    def screenshot(self, save_dir: Path | None = None) -> tuple[str, str | None]:
        """Capture the CURRENT page (session state included). Returns (text, b64)."""
        try:
            page, restarted = self._ensure_page()
        except Exception as e:  # noqa: BLE001
            return f"ERROR: could not start the browser: {e}", None
        try:
            if page.url in ("about:blank", ""):
                return ("The browser session has no page loaded yet. Call "
                        "browser_navigate(url) first."), None
            png = page.screenshot(full_page=True)
            import base64
            b64 = base64.b64encode(png).decode("ascii")
            note = ""
            if save_dir is not None:
                try:
                    save_dir.mkdir(parents=True, exist_ok=True)
                    fname = f"browser_screenshot_{int(time.time())}.png"
                    (save_dir / fname).write_bytes(png)
                    note = f" Saved to {fname}."
                except OSError:
                    pass
            prefix = ("NOTE: a fresh browser session was started for this call. "
                      if restarted else "")
            return (f"{prefix}Screenshot of the current browser page captured "
                    f"({page.url}).{note}"), b64
        except Exception as e:  # noqa: BLE001
            self._handle_dead_session(e)
            return f"ERROR: screenshot failed: {e}", None
