"""
harness/llm.py
==============

Model clients — the *only* part of the harness that talks to a language model.

WHY THIS MODULE EXISTS
----------------------
Every model we want to study (local models on the RTX 6000 via LM Studio, and hosted
frontier models via OpenRouter) speaks the same wire protocol: the OpenAI
`/v1/chat/completions` HTTP API. By isolating all network/protocol concerns here, the
rest of the harness never needs to know which model it's talking to. Switching from a
local Qwen model to a hosted Claude model is purely a matter of `base_url` + `api_key` +
`model` — the agent loop, the tools, and the logging are all unchanged. That uniformity
is what lets one harness produce comparable runs across very different models, which is
the whole point of the study.

WHAT'S IN HERE
--------------
- ToolCall / Turn : small normalized data structures the rest of the code consumes, so
                    the agent loop never touches raw provider JSON.
- RealClient      : makes the actual HTTP call to LM Studio / OpenRouter.
- MockClient      : a fake model that replays a hand-written script, used by selftest.py
                    to exercise the whole loop offline (no GPU, no network).

Standard library only (urllib, json) — no SDK, no third-party HTTP client. This is
deliberate: fewer dependencies means fewer moving parts that could differ between runs
or drift between versions and quietly contaminate the experiment.
"""

from __future__ import annotations

import hashlib
import json
import os
import random
import re
import threading
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Any, Callable


# =============================================================================
# Normalized response types
# -----------------------------------------------------------------------------
# The OpenAI API returns a fairly nested JSON structure. Rather than pass that raw
# dict around the codebase, RealClient._parse() flattens it into these two tiny
# dataclasses. The agent loop only ever sees `Turn` and `ToolCall`, so if a future
# provider returns a slightly different shape, the only code that changes is the
# parser below — not the loop.
# =============================================================================

# =============================================================================
# DECODING_DEFAULTS: a FALLBACK for ad-hoc runs. NOT the study's configuration.
# -----------------------------------------------------------------------------
# Decoding parameters are a confound if they vary WITHIN a model: a temperature
# difference between two arms is a second treatment. Until v2.4.0 this dict was the
# study's one canonical configuration, greedy for every model. It is not any more.
#
# The study's decoding lives in decoding-registry.json -- per model, per thinking mode,
# taken from each vendor's documentation -- and the run wrapper reads that file and
# passes the values in as explicit flags. THIS MODULE KNOWS NOTHING ABOUT MODELS on
# purpose: it accepts sampler values, sends exactly those, and records exactly those.
# A decoding decision then lives in one file that can be read, diffed and cited, rather
# than in code that has to be grepped.
#
# What remains here is a fallback for running the agent by hand. A study run that lands
# on it has lost its configuration, so the manifest stamps decoding_source="fallback"
# and verify_smokes fails it -- silence would mean a run at the wrong temperature that
# looks exactly like a run at the right one.
# =============================================================================
# The sampler fields this client will forward. An ALLOW-LIST rather than a passthrough:
# an unrecognised key in a request body is silently ignored by llama.cpp (the same trap
# that makes a misspelled chat_template_kwargs invisible), so a typo in the registry would
# otherwise become a run at the engine's default instead of the vendor's value, with
# nothing anywhere to show for it.
SAMPLER_KEYS = ("temperature", "top_p", "top_k", "min_p",
                "presence_penalty", "frequency_penalty", "repetition_penalty", "seed")


def validate_samplers(samplers: dict) -> list[str]:
    """Reasons this sampler dict must be refused; [] if fine."""
    if not isinstance(samplers, dict):
        return [f"samplers must be a JSON object, got {type(samplers).__name__}"]
    bad = [k for k in samplers if k not in SAMPLER_KEYS]
    return ([f"unknown sampler {k!r} — llama.cpp would ignore it silently. "
             f"Known: {', '.join(SAMPLER_KEYS)}" for k in bad])


DECODING_DEFAULTS = {
    "temperature": 0.0,   # greedy-as-possible: minimizes run-to-run variance unrelated
                          # to the condition under test
    "top_p": 1.0,         # no nucleus truncation
    "max_tokens": 32768,  # per-turn cap; large enough for reasoning + a big file write
                          # (4096 caused truncated tool-call args -> stuck loops)
}


# =============================================================================
# Serving-stack failure detection
# =============================================================================
# A local server reports "my model died" and "your request was malformed" with the SAME
# HTTP status (LM Studio uses 400 for both), so the status alone cannot separate an
# infrastructure fault from a misconfiguration. These patterns match the BODY.
#
# They are regexes rather than substrings because the first version of this list used
# "no model loaded" and the server actually says "No models loaded" — one character of
# pluralisation, and a real outage was classified as a bad request. Match the shape of
# the sentence, not one vendor's phrasing.
_SERVER_DOWN_PATTERNS = [
    re.compile(p, re.I) for p in (
        r"models?\s+(?:has|have)?\s*crashed",
        r"no\s+models?\s+(?:are\s+|is\s+)?loaded",
        r"failed\s+to\s+load\s+(?:the\s+)?model",
        r"model\s+(?:is\s+)?(?:not\s+loaded|unloaded)",
        r"exit\s+code:",
        r"model\s+.{0,40}\bnot\s+found\b",
    )
]


# Template failures caused by an assistant message carrying reasoning ALONGSIDE tool
# calls. llama.cpp has a live, twice-regressed bug here (ggml-org/llama.cpp#19703, and
# #20500 when the fix was lost in a later merge), and some model templates simply have no
# slot for prior reasoning. Without this, the failure is a bare 400 from deep inside a
# Jinja renderer, arriving on step 2 of an unattended batch, with nothing tying it to the
# setting that caused it. Matched only to ATTRIBUTE the error — never to retry it, since
# retrying a template that cannot render the message will fail identically forever.
_REASONING_TEMPLATE_PATTERNS = [
    re.compile(p, re.I) for p in (
        r"cannot\s+pass\s+both\s+content\s+and\s+thinking",
        r"(?:thinking|reasoning)\S*\s+.{0,60}\bwith\s+tool\s+calls\b",
        r"unknown\s+.{0,20}\b(?:reasoning_content|thinking)\b",
        r"\b(?:reasoning_content|thinking)\b.{0,60}\bnot\s+(?:supported|allowed|expected)\b",
    )
]


# The model emitting output its own server cannot parse. gpt-oss speaks "harmony", and
# llama.cpp parses it with a PEG grammar; when the model produces a malformed channel
# sequence the server answers 500. Observed 2026-09-23, one run in six:
#
#   <|channel|>functions.write_file<|channel|>commentary json<|message|>{"path": ...}
#
# — two <|channel|> tokens in a row, the function name sitting in the channel slot. That
# is the MODEL's output, not a server fault and not ours.
#
# It is not retried at the call level. The first reason given here was greedy decoding:
# the same prompt produced the same tokens, so the run above burned five retries over ~62
# seconds on six byte-identical failures. That stopped being true in plan v2.4.0 -- runs
# are sampled now, and a re-sample might well parse. The reason that stands (plan v2.5.9)
# is the study's own: a re-sample selected for parseability would hide a failure caused by
# what the model generated, and these failures are counted per arm, because they are not
# missing at random (plan §10). So the run ends as a void, the batch driver re-runs the
# slot at most twice, and every failed smoke attempt is kept so that each failure stays
# countable. llama-server logs what the model wrote at its default verbosity, as a line
# "unparsed peg-native output: ..." -- observed again on 2026-09-25, for example
#
#   <|channel|>functions.list_dir to=assistant<|channel|>commentary json<|message|>{"path": ""}
_UNPARSEABLE_OUTPUT_PATTERNS = [
    re.compile(p, re.I) for p in (
        r"peg[-\s]?native",
        r"output\s+that\s+does\s+not\s+match\s+the\s+expected\s+\S+\s+format",
        r"unparsed\s+\S*\s*output",
        r"failed\s+to\s+parse\s+.{0,40}\b(?:harmony|channel)\b",
    )
]


def model_output_unparseable(body: str) -> bool:
    """True when a 5xx is the server refusing to parse what the MODEL produced.

    Distinguished from a genuine server error because the remedy is different: there is
    none at run time. It is recorded so the void can be counted per arm rather than
    disappearing into a generic api_error.
    """
    return any(p.search(body or "") for p in _UNPARSEABLE_OUTPUT_PATTERNS)


# The conversation outgrowing the context window (plan 42 v2.5.28). llama.cpp refuses such a
# request with HTTP 400 before generating anything -- observed 2026-10-01 on b10964:
#
#   {"error":{"code":400,"message":"request (132135 tokens) exceeds the available context
#    size (131072 tokens), try increasing it","type":"exceed_context_size_error",
#    "n_prompt_tokens":132135,"n_ctx":131072}}
#
# That is an OUTCOME, not a fault: keeping reasoning visible fills the window faster, which is
# part of what the study measures, so the run ends as context_overflow, is never retried at
# the call level (a 400 is not transient anyway) and exits 0 so the batch driver does not
# re-run the slot either.
_CONTEXT_OVERFLOW_PATTERNS = [
    re.compile(p, re.I) for p in (
        r"exceed_context_size_error",
        r"exceeds\s+the\s+available\s+context\s+size",
    )
]


def context_overflow(body: str):
    """A dict describing the refusal when a 4xx says the request outgrew the context window,
    else None. Carries the server's own token counts when it gives them."""
    if not any(p.search(body or "") for p in _CONTEXT_OVERFLOW_PATTERNS):
        return None
    info = {"n_prompt_tokens": None, "n_ctx": None}
    try:
        err = json.loads(body).get("error") or {}
        info["n_prompt_tokens"] = err.get("n_prompt_tokens")
        info["n_ctx"] = err.get("n_ctx")
    except (ValueError, AttributeError):
        pass
    if info["n_prompt_tokens"] is None:
        m = re.search(r"request\s+\((\d+)\s+tokens\)\s+exceeds\s+the\s+available\s+context"
                      r"\s+size\s+\((\d+)\s+tokens\)", body or "", re.I)
        if m:
            info["n_prompt_tokens"], info["n_ctx"] = int(m.group(1)), int(m.group(2))
    return info


def reasoning_replay_rejected(body: str) -> bool:
    """True when a 4xx looks like the server refusing replayed reasoning.

    Lets the harness say "your server will not round-trip reasoning_content; re-run with
    --no-replay-reasoning" instead of surfacing an opaque template error, which is the
    difference between a five-minute fix and an evening.
    """
    return any(p.search(body or "") for p in _REASONING_TEMPLATE_PATTERNS)


# Keys the harness owns in the request payload. An escape hatch that can silently
# rewrite the treatment is worse than no escape hatch, and there are TWO silent failure
# modes here, on opposite sides of one line of code:
#
#   CLOBBERED — `model`, `messages` and `max_tokens` are written into the payload BEFORE
#               `**extra_body` is spread, so a key here overwrites them. Pushing a
#               different max_tokens through this route would change decoding while
#               bypassing the registry comparison AND the `decoding_overridden` manifest
#               field that exists precisely to catch a changed decoding parameter.
#
#   IGNORED   — `temperature`, `top_p`, `tools` and `tool_choice` are written AFTER the
#               spread, so a key here does nothing whatsoever. The operator believes they
#               changed a treatment and did not, and the manifest agrees with them. That
#               is worse than a crash.
#
#   UNSUPPORTED — the loop reads choices[0] of a non-streamed response; `stream` would
#               break parsing outright and `n` would silently discard sampled
#               alternatives, making the run un-reproducible for an invisible reason.
_EXTRA_BODY_CLOBBERS = ("model", "messages", "max_tokens")
_EXTRA_BODY_IGNORED = ("temperature", "top_p", "tools", "tool_choice")
_EXTRA_BODY_UNSUPPORTED = ("stream", "n")


def validate_extra_body(extra: dict) -> list[str]:
    """Return human-readable reasons this extra-body dict must be refused; [] if fine.

    Checked before the workspace is touched, so a misconfigured batch stops at run 1
    rather than producing 576 runs whose manifests misdescribe them.
    """
    problems = []
    if not isinstance(extra, dict):
        return [f"extra body must be a JSON object, got {type(extra).__name__}"]
    for k in extra:
        if k in _EXTRA_BODY_CLOBBERS:
            problems.append(
                f"{k!r} would OVERWRITE the harness's own value silently — it is set "
                f"before extra-body is merged. Use the dedicated flag instead "
                f"({'--model' if k == 'model' else '--max-tokens' if k == 'max_tokens' else 'the task file'}).")
        elif k in _EXTRA_BODY_IGNORED:
            problems.append(
                f"{k!r} would be SILENTLY IGNORED — the harness sets it after extra-body "
                f"is merged, so passing it here changes nothing while looking like it "
                f"did. Use --{k.replace('_', '-')} instead.")
        elif k in _EXTRA_BODY_UNSUPPORTED:
            problems.append(
                f"{k!r} is not supported: the loop parses a single non-streamed "
                f"choices[0], so this would break or discard output invisibly.")
    return problems


def server_is_down(body: str) -> bool:
    """True when a response body says the SERVER failed, not the request.

    Used to decide whether a 4xx is worth retrying, and recorded in the manifest so a
    void run can be told apart from a model result. Deliberately narrow: it must never
    match a rejected decoding parameter, which is a real misconfiguration that should
    fail loudly and immediately.
    """
    return any(p.search(body or "") for p in _SERVER_DOWN_PATTERNS)


@dataclass
class ToolCall:
    """A single tool/function call the model wants to make.

    Attributes:
        id:        The provider's id for this call (e.g. "call_abc123"). We echo it
                   back when we return the tool result, so the model can match result
                   to request. May be empty for some providers; the loop fills a
                   fallback id if so.
        name:      The function name the model chose (e.g. "write_file"). Must match a
                   method on tools.Tools.
        arguments: The call arguments, already parsed from JSON into a Python dict
                   (e.g. {"path": "app.py", "content": "..."}).
    """
    id: str
    name: str
    arguments: dict


@dataclass
class Turn:
    """One assistant turn — the model's complete response to one request.

    A turn can contain free-form text, one or more tool calls, or both at once.

    Attributes:
        text:       The assistant's natural-language text, if any (may be None/empty
                    when the model only makes tool calls).
        tool_calls: Zero or more ToolCall objects. An empty list means the model chose
                    NOT to call any tool this turn — which the agent loop treats as a
                    signal that the model is done (or stuck).
        raw:        The provider's original `message` dict, kept untouched purely so the
                    logger can record exactly what came back over the wire. Never used
                    for control flow — only for the audit trail.
        usage:      The usage statistics from the provider (e.g. prompt_tokens,
                    completion_tokens). May be missing or empty for some providers.
    """
    text: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)
    raw: dict | None = None
    usage: dict | None = None
    # The provider's stop reason for this turn (e.g. "stop", "tool_calls", "length").
    # "length" means the response was cut off at max_tokens — the prime cause of a tool
    # call whose `arguments` JSON is truncated and therefore unparseable. The agent loop
    # uses this to give the model an actionable error instead of silently looping.
    finish_reason: str | None = None
    # Chain-of-thought text, when the provider returns it in a channel separate from
    # `content` (LM Studio: reasoning_content; OpenRouter: reasoning). Captured for the
    # AUDIT TRAIL ONLY — verbose output and traces show it so a turn that produced
    # thinking but no visible content is diagnosable instead of looking like an empty
    # response. It is deliberately NOT echoed back in the assistant message: replaying
    # reasoning into the next request would change what the model is conditioned on and
    # would differ between reasoning and non-reasoning models, i.e. a second treatment.
    reasoning: str | None = None


# =============================================================================
# RealClient — talks to a live model server
# =============================================================================


# --- request heartbeat --------------------------------------------------------
# Responses are NOT streamed: urlopen blocks for the entire generation, so a
# 40-minute reply and a wedged server look identical from the outside. That
# ambiguity cost an hour of watching a live run on 2026-09-24. This prints
# elapsed time while a request is in flight so the two are distinguishable.
#
# PRINT-ONLY BY CONSTRUCTION. It never touches the request, the payload, the
# response, or any sampler, so it cannot change what a run produces. That is what
# makes it safe to add to an otherwise frozen harness: it is observationally
# inert with respect to the experiment. It is also a daemon thread that is never
# joined for more than a second, so it cannot wedge the process it is reporting on.
#
# The interval comes from the environment rather than a CLI flag, deliberately:
# adding a flag would change the frozen argument surface that the verifier gates
# check. Set HARNESS_HEARTBEAT_SECONDS=0 to disable.
HEARTBEAT_SECONDS = float(os.environ.get("HARNESS_HEARTBEAT_SECONDS", "30") or 0)


class _RequestHeartbeat:
    """Report elapsed time while a blocking HTTP request is outstanding."""

    def __init__(self, timeout: float, label: str = "",
                 every: float = HEARTBEAT_SECONDS):
        self.timeout = float(timeout)
        self.label = label
        self.every = every
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._t0 = 0.0

    def __enter__(self) -> "_RequestHeartbeat":
        if self.every <= 0:
            return self
        self._t0 = time.monotonic()
        self._thread = threading.Thread(target=self._tick, daemon=True)
        self._thread.start()
        return self

    def _tick(self) -> None:
        warned = False
        while not self._stop.wait(self.every):
            elapsed = time.monotonic() - self._t0
            frac = (elapsed / self.timeout) if self.timeout else 0.0
            print(f"[RealClient] waiting for model reply{self.label} - "
                  f"{elapsed:.0f}s elapsed, {frac:.0%} of the "
                  f"{self.timeout:.0f}s timeout", flush=True)
            # The failure mode worth shouting about: on timeout this client does not
            # fail, it RETRIES, and the generation restarts from zero. Say so BEFORE
            # it happens, while the operator can still intervene. Discovering it
            # afterwards costs however long the retries ran.
            if not warned and frac >= 0.8:
                warned = True
                print(f"[RealClient] WARNING: approaching the {self.timeout:.0f}s "
                      f"socket timeout. If it trips, this request is RETRIED from "
                      f"scratch, not failed - the whole generation starts over.",
                      flush=True)

    def __exit__(self, *exc) -> bool:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
        return False


class RealClient:
    """Calls an OpenAI-compatible chat-completions endpoint and returns a Turn.

    The same class drives both backends; only the constructor arguments differ:
        LM Studio (local) : base_url="http://localhost:1234/v1", api_key="anything"
        OpenRouter (hosted): base_url="https://openrouter.ai/api/v1", api_key="sk-or-..."
    """

    def __init__(self, base_url: str, model: str, api_key: str = "not-needed",
                 temperature: float | None = 0.0, top_p: float | None = 1.0,
                 max_tokens: int = 32768, extra_body: dict | None = None,
                 timeout: int = 3600, max_retries: int = 5, retry_backoff: float = 2.0,
                 samplers: dict | None = None):
        """
        Args:
            base_url:    Root of the API, INCLUDING the /v1 segment. Trailing slash is
                         stripped so we can safely append "/chat/completions".
            model:       The model id the server expects. For LM Studio this must match
                         the id shown in the Developer/Local Server panel (or returned
                         by GET /v1/models) — a wrong id is a common cause of the model
                         silently misbehaving.
            api_key:     Bearer token. LM Studio ignores it (pass any placeholder);
                         OpenRouter requires a real key.
            temperature: Sampling temperature. Default 0.0 for maximum determinism —
                         important for an experiment, since it minimizes run-to-run
                         variance that has nothing to do with the condition being tested.
                         Pass None to OMIT the field entirely from the request: some
                         hosted models have deprecated `temperature` and reject any
                         request that sends it with a 400. Omitting means the provider's
                         own default sampling applies — see the warning logged by the
                         agent when this happens.
            top_p:       Nucleus sampling parameter. Held constant across conditions.
                         Pass None to omit (same rationale as temperature).
            max_tokens:  Cap on tokens per single model response (one turn), NOT the
                         whole run.
            extra_body:  Optional dict merged into the request payload — an escape hatch
                         for provider-specific knobs (e.g. a reasoning-effort field)
                         without changing this class. Keep it identical across conditions
                         or you introduce a confound.
            timeout:     Socket timeout in seconds for a single HTTP call. 60 min
                         (raised from 10 min on 2026-09-18): responses are not
                         streamed, so the read blocks for the WHOLE generation, and a
                         full-length reply (max_tokens 32768) takes longer than 10 min
                         at local speeds. A shorter value cuts exactly the longest
                         reasoning replies and retries them — a bias against the
                         thinking arms of a study, not a safety net. 60 min still
                         bounds a genuinely hung server (times max_retries).
        """
        self.base_url = base_url.rstrip("/")     # tolerate a trailing "/"
        self.model = model
        self.api_key = api_key
        self.temperature = temperature
        self.top_p = top_p
        self.max_tokens = max_tokens
        self.extra_body = extra_body or {}
        # Sampler fields beyond temperature/top_p (top_k, min_p, penalties, seed). Sent
        # AFTER extra_body for the same reason temperature and top_p are: a treatment
        # value must not be silently overwritable by a body field.
        self.samplers = dict(samplers or {})
        self.timeout = timeout
        # Retry policy for TRANSIENT failures only (upstream 5xx, 429, dropped
        # connections, read timeouts). max_retries=0 restores the old fail-fast
        # behavior. This never retries a 4xx (other than 429): those are real
        # config/decoding errors and must still stop the run loudly.
        self.max_retries = max_retries
        self.retry_backoff = retry_backoff
        # RETRY RECORD (plan 42 v2.5.8). A retried call is a RE-ROLLED generation: the
        # server starts the reply again from zero and only the last attempt reaches the
        # trace. A read timeout is the case that matters -- it falls on exactly the
        # longest replies, so re-rolling them into shorter ones hides a run's own
        # runaways -- and until v2.5.8 nothing recorded that it had happened. Every retry
        # in this client's lifetime (one client per run) is appended here; the agent
        # writes the list into the manifest as api_retries, and verify_smokes.py's gate
        # G16 fails any set that contains a timeout retry.
        self.retry_log: list[dict] = []

    def chat(self, messages: list[dict], tools: list[dict]) -> Turn:
        """Send one request to the model and return its response as a Turn.

        Args:
            messages: The full conversation so far, in OpenAI message format
                      (system / user / assistant / tool roles). We always send the
                      ENTIRE history every call — the model is stateless between calls,
                      so the running message list IS the memory.
            tools:    The JSON tool schemas the model is allowed to use THIS turn. The
                      agent loop passes only the tools permitted by the current
                      condition, which is exactly how the experimental variable is
                      enforced — an out-of-condition tool is simply never offered.

        Returns:
            A Turn parsed from the model's reply.
        """
        # ---- Build the request body in the shape the OpenAI API expects ----
        # temperature/top_p are included ONLY when set (not None). Passing None omits the
        # field entirely — required for models that have DEPRECATED it and 400 on any
        # request that carries it (e.g. Claude Opus 4.6/4.7/4.8). max_tokens is always
        # sent; it is required by Anthropic-format models. WHICH fields to omit is decided
        # up front by the caller (run.sh's per-model rules, surfaced as --temperature none
        # / --top-p none). We deliberately do NOT auto-retry on a rejected parameter: an
        # unexpected rejection means the harness is MISCONFIGURED for that model, and we
        # want the run to STOP loudly rather than burn tokens silently adapting decoding.
        payload = {
            "model": self.model,
            "messages": messages,
            "max_tokens": self.max_tokens,
            **self.extra_body,   # provider-specific extras (e.g. seed), if any
        }
        if self.temperature is not None:
            payload["temperature"] = self.temperature
        if self.top_p is not None:
            payload["top_p"] = self.top_p
        # After extra_body, so these cannot be clobbered by it. A value of None means
        # "do not send this field"; 0 is a real value (top_k 0 = disabled) and IS sent.
        for _k, _v in self.samplers.items():
            if _v is not None:
                payload[_k] = _v
        # Only advertise tools if we actually have some. "tool_choice": "auto" lets the
        # model decide whether to call a tool or just talk — we never force a specific
        # tool, because forcing would distort the behavior we're trying to observe.
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"

        # ---- Issue the HTTP POST using only the standard library ----
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
                # These two headers are conventions OpenRouter uses for attribution.
                # LM Studio ignores them, so sending them always is harmless.
                "HTTP-Referer": "https://localhost/research",
                "X-Title": "tool-regression-study",
            },
            method="POST",
        )
        # We fail the run loudly on any error — a half-failed run must not masquerade as a
        # real data point. On an HTTP error we first PRINT the response body and re-raise:
        # the body is where the provider puts the actual reason (e.g. "`top_p` is
        # deprecated for this model"), which the default HTTPError str() hides. That
        # message tells the operator exactly which per-model decoding rule to add.
        # Transient provider/infra failures (upstream 5xx, rate-limit 429, dropped
        # connections, read timeouts) are RETRIED with exponential backoff + jitter:
        # a single blip must not throw away a multi-million-token run. Everything else
        # -- notably a 4xx other than 429 (bad request, deprecated decoding param,
        # auth) -- still fails loudly and immediately, because retrying it would only
        # burn tokens masking a real misconfiguration.
        TRANSIENT_STATUS = {429, 500, 502, 503, 504}
        attempt = 0
        # A LOCAL SERVER CRASHING IS NOT A BAD REQUEST. LM Studio reports a crashed or
        # unloaded model as HTTP 400 with the reason in the body — the same status it
        # uses for a genuinely malformed request. The rule above (4xx = permanent
        # misconfiguration, do not retry) is right for a rejected decoding parameter and
        # wrong here: the server reloads the model and the next request succeeds.
        # Observed mid-run: {"error":"The model has crashed without additional
        # information. (Exit code: ...)"} killed a run outright. Matching is on the BODY,
        # never the status, so a real 400 still fails immediately.
        # Regexes, not substrings: the first version of this list said "no model loaded"
        # and the server said "No models loaded", so a real outage sailed straight past
        # it. Match the shape of the sentence, not one server's exact phrasing.
        CRASH_MARKERS = _SERVER_DOWN_PATTERNS
        # A crashed model has to be reloaded from disk before anything can succeed, so
        # the usual 2s first retry just hammers a dead server. Floor the wait.
        CRASH_MIN_DELAY = 15.0
        # Per-instance call counter, so the heartbeat can say WHICH request is
        # outstanding. getattr-with-default rather than an __init__ field: this
        # is diagnostics, and it should not widen the constructor.
        self._call_n = getattr(self, "_call_n", 0) + 1
        while True:
            try:
                _hb = (f" #{self._call_n} (retry {attempt})" if attempt
                       else f" #{self._call_n}")
                _t0 = time.monotonic()      # when THIS attempt began (retry record)
                with _RequestHeartbeat(self.timeout, _hb):
                    with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                        body = json.loads(resp.read().decode("utf-8"))
                break
            except urllib.error.HTTPError as e:      # subclass of URLError -> catch first
                try:
                    err_body = e.read().decode("utf-8", "replace")
                except Exception:
                    err_body = "<no response body>"
                print(f"[RealClient] HTTP {e.code} from "
                      f"{self.base_url}/chat/completions (model={self.model})\n"
                      f"  response body: {err_body}", flush=True)
                # Stash the body on the exception: HTTPError.read() is single-shot, so
                # without this the caller cannot record WHY the run died in its manifest.
                e.harness_body = err_body
                e.harness_model_crash = server_is_down(err_body)
                # ATTRIBUTE a reasoning-replay template failure at the point it happens.
                # It is not transient and not a crash, so it must not be retried — but
                # left unexplained it is a bare Jinja error arriving mid-batch with no
                # visible connection to the setting that caused it.
                e.harness_reasoning_rejected = reasoning_replay_rejected(err_body)
                e.harness_output_unparseable = model_output_unparseable(err_body)
                e.harness_context_overflow = (context_overflow(err_body)
                                              if 400 <= e.code < 500 else None)
                if e.harness_context_overflow:
                    print("[RealClient] the conversation has OUTGROWN the context window "
                          f"({e.harness_context_overflow}). The run ends as "
                          "context_overflow -- an outcome, never retried (plan 42 "
                          "v2.5.28).", flush=True)
                if e.harness_output_unparseable:
                    print("[RealClient] the SERVER could not parse what the MODEL "
                          "produced — malformed harmony/channel output, not a server "
                          "fault. Not retrying this call: a re-sample would hide a "
                          "failure caused by what the model generated, and the study "
                          "counts these per arm (plan §10). The run ends as a void; "
                          "llama-server.log records the output as 'unparsed "
                          "peg-native output'.", flush=True)
                if e.harness_reasoning_rejected:
                    print("[RealClient] this looks like the server REFUSING replayed "
                          "reasoning: an assistant message carrying reasoning_content "
                          "alongside tool_calls could not be rendered by the chat "
                          "template. Re-run with --no-replay-reasoning, or use a build/"
                          "template that supports the round-trip. Not retrying — the "
                          "same message will fail identically every time.", flush=True)
                if (e.code in TRANSIENT_STATUS or e.harness_model_crash) \
                        and not e.harness_reasoning_rejected \
                        and not e.harness_output_unparseable \
                        and not e.harness_context_overflow \
                        and attempt < self.max_retries:
                    attempt += 1
                    delay = min(self.retry_backoff * (2 ** (attempt - 1)), 60.0) + random.uniform(0, 1.0)
                    if e.harness_model_crash:
                        delay = max(delay, CRASH_MIN_DELAY)
                        print(f"[RealClient] the SERVER's model crashed (HTTP {e.code}); "
                              f"waiting for it to reload — retry "
                              f"{attempt}/{self.max_retries} in {delay:.1f}s", flush=True)
                    else:
                        print(f"[RealClient] transient HTTP {e.code}; retry "
                              f"{attempt}/{self.max_retries} in {delay:.1f}s", flush=True)
                    self._record_retry("server_crash" if e.harness_model_crash
                                       else f"http_{e.code}", attempt, err_body, _t0, delay)
                    time.sleep(delay)
                    continue
                raise
            except (urllib.error.URLError, TimeoutError) as e:  # conn reset/refused/DNS, read timeout
                if attempt < self.max_retries:
                    attempt += 1
                    delay = min(self.retry_backoff * (2 ** (attempt - 1)), 60.0) + random.uniform(0, 1.0)
                    print(f"[RealClient] network error ({e}); retry "
                          f"{attempt}/{self.max_retries} in {delay:.1f}s", flush=True)
                    self._record_retry("timeout" if self._is_timeout(e) else "connection",
                                       attempt, str(e), _t0, delay)
                    time.sleep(delay)
                    continue
                raise
        return self._parse(body)

    @staticmethod
    def _is_timeout(e: BaseException) -> bool:
        """A socket/read timeout, however urllib chose to wrap it."""
        import socket
        reason = getattr(e, "reason", None)
        return (isinstance(e, (TimeoutError, socket.timeout))
                or isinstance(reason, (TimeoutError, socket.timeout))
                or "timed out" in str(e).lower())

    def _record_retry(self, kind: str, attempt: int, detail: str, t0: float,
                      delay: float) -> None:
        """Append one retried call to retry_log (plan 42 v2.5.8; see __init__)."""
        failed_after = time.monotonic() - t0
        self.retry_log.append({
            "call": getattr(self, "_call_n", 0),   # the agent's step: one call per step
            "retry": attempt,                      # 1 = the first re-send of this call
            "kind": kind,                          # timeout | connection | http_<code> | server_crash
            "failed_after_s": round(failed_after, 1),
            "retry_in_s": round(delay, 1),
            "detail": (detail or "")[:300],
        })
        if kind == "timeout":
            print(f"[RealClient] call #{getattr(self, '_call_n', 0)} TIMED OUT after "
                  f"{failed_after:.0f}s and is being RE-ROLLED from zero. Recorded in this "
                  f"run's manifest (api_retries); verify_smokes.py gate G16 fails any set "
                  f"that contains one.", flush=True)

    def preflight(self, timeout: int = 15) -> tuple[bool, str]:
        """Check the server is up and serving THIS model, before the run starts.

        Returns (ok, message). Cheap (one GET /models) and worth doing because the
        alternative is discovering the problem after the workspace has been wiped and
        the run directory created — and, in an unattended batch, discovering it once per
        remaining run rather than once.

        It also catches the model-name class of error directly. The server's id must
        match exactly; a near-miss produces a listing of what is actually loaded instead
        of an opaque 400 several seconds later.

        Deliberately permissive in one direction: if /models cannot be parsed, or the
        provider does not expose it, this PASSES with a note. Some providers have no
        such endpoint, and a preflight that blocks runs on an unrecognised response
        shape would be worse than no preflight at all. It only fails when it positively
        establishes that the server is unreachable, is serving nothing, or is not
        serving the requested model.
        """
        url = f"{self.base_url}/models"
        req = urllib.request.Request(
            url, headers={"Authorization": f"Bearer {self.api_key}"}, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                text = e.read().decode("utf-8", "replace")
            except Exception:  # noqa: BLE001
                text = ""
            if server_is_down(text):
                return False, (f"the server at {self.base_url} has no model loaded "
                               f"(HTTP {e.code}): {text.strip()[:300]}")
            return True, f"(preflight inconclusive: HTTP {e.code} from {url})"
        except Exception as e:  # noqa: BLE001 - connection refused, DNS, timeout
            return False, (f"cannot reach the model server at {self.base_url}: {e}. "
                           f"Is it running, and is the host/port right?")

        try:
            ids = [m["id"] for m in body["data"]]
        except (KeyError, TypeError, IndexError):
            return True, f"(preflight inconclusive: unrecognised /models response)"
        if not ids:
            return False, (f"the server at {self.base_url} is running but has NO model "
                           f"loaded. Load one (LM Studio: `lms load <model>`), then "
                           f"re-run.")
        if self.model in ids:
            return True, f"server OK, serving {self.model!r}"

        # NAMESPACE TOLERANCE. LM Studio lists a namespaced id (google/gemma-4-31b) but
        # HAPPILY SERVES the bare suffix (gemma-4-31b) — every earlier run in this
        # project used the short form successfully. A strict equality check therefore
        # rejects a model the server would have answered, which is a worse failure than
        # the one it was written to prevent: it blocks working runs, and the obvious
        # "fix" (switch to the namespaced id) can collide with run.sh's local-vs-remote
        # routing. Mirror what the server actually does: match on the final path
        # segment, and require the match to be UNIQUE so a real ambiguity still stops.
        def _leaf(x: str) -> str:
            return x.rsplit("/", 1)[-1]

        hits = [i for i in ids if _leaf(i) == _leaf(self.model)]
        if len(hits) == 1:
            if hits[0] == self.model:
                return True, f"server OK, serving {self.model!r}"
            return True, (f"server OK, serving {hits[0]!r}; requests will be sent as "
                          f"{self.model!r}, which this server accepts as the same model")
        if len(hits) > 1:
            return False, (f"{self.model!r} is ambiguous — the server has "
                           f"{', '.join(sorted(hits))}. Pass the full id.")

        shown = ", ".join(sorted(ids)[:12]) + (" ..." if len(ids) > 12 else "")
        return False, (f"the server is not serving anything matching {self.model!r}. "
                       f"Currently loaded: {shown}")

    def props(self, timeout: int = 10) -> dict | None:
        """Ask the server what it is ACTUALLY serving. Returns None if it will not say.

        Everything else we record about the serving stack is a DECLARATION — the
        operator tells the manifest which quantization they believe they loaded. This is
        the one measurement available, and it is the measurement that matters, because
        every serving fault this project has hit looked like a model result until
        somebody read the server's own view: a context silently served at 4096 despite a
        262144 setting, a model unloaded mid-batch, an id that resolved to a different
        file than intended.

        llama.cpp's llama-server answers GET /props with the loaded model's path, the
        effective context size and the chat template in force. LM Studio and hosted
        providers generally do not have this endpoint; that is fine and expected, and a
        missing probe is never an error — the field simply records that the server
        declined to say.

        The chat template is HASHED rather than stored: it can be tens of kilobytes, and
        what matters for a run's provenance is only whether it was the same template as
        the other runs in its cell (the unsloth Gemma templates are exactly the kind of
        thing that differs between builds of a nominally identical model).
        """
        roots = [self.base_url]
        # /props lives at the server root on llama-server, while base_url carries the
        # OpenAI-compatible /v1 prefix. Try both rather than assuming either layout.
        if self.base_url.endswith("/v1"):
            roots.append(self.base_url[: -len("/v1")])
        for root in roots:
            url = f"{root}/props"
            req = urllib.request.Request(
                url, headers={"Authorization": f"Bearer {self.api_key}"}, method="GET")
            try:
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    body = json.loads(resp.read().decode("utf-8"))
            except Exception:  # noqa: BLE001 - absent endpoint is the normal case
                continue
            if not isinstance(body, dict):
                continue
            out: dict = {"endpoint": url, "keys_seen": sorted(body)[:40]}
            # Shapes differ across llama.cpp versions, so pull by name wherever a key
            # turns up rather than assuming one nesting. Unknown shape -> fewer fields,
            # never an exception.
            flat = dict(body)
            for nest in ("default_generation_settings", "generation_settings"):
                if isinstance(body.get(nest), dict):
                    for k, v in body[nest].items():
                        flat.setdefault(k, v)
            for key in ("model_path", "model", "n_ctx", "n_ctx_per_seq", "total_slots",
                        "build_info", "chat_template_tool_use"):
                if key in flat and not isinstance(flat[key], (dict, list)):
                    out[key] = flat[key]
            tmpl = flat.get("chat_template")
            if isinstance(tmpl, str) and tmpl:
                out["chat_template_sha"] = hashlib.sha256(
                    tmpl.encode("utf-8")).hexdigest()[:16]
                out["chat_template_chars"] = len(tmpl)
            return out
        return None

    @staticmethod
    def _parse(body: dict) -> Turn:
        """Flatten the provider's JSON response into our Turn structure.

        The response shape we care about:
            body["choices"][0]["message"] = {
                "content": "...text...",            # may be null
                "tool_calls": [                      # may be absent
                    {"id": "...", "function": {"name": "...", "arguments": "<json str>"}},
                    ...
                ]
            }
        """
        choice0 = body["choices"][0]
        msg = choice0["message"]
        finish_reason = choice0.get("finish_reason")
        calls = []
        # `tool_calls` may be absent or null; `or []` handles both safely.
        for tc in (msg.get("tool_calls") or []):
            fn = tc["function"]
            # Per the OpenAI spec, arguments arrive as a JSON *string*, not a dict, so
            # we parse it. Defensive default of "{}" handles a missing/empty field.
            args = fn.get("arguments") or "{}"
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except json.JSONDecodeError:
                    # Some models (especially smaller local ones) emit slightly
                    # malformed JSON for arguments. Rather than crash the whole run, we
                    # stash the raw string under "__raw__". When the loop later calls the
                    # tool with these args, the tool will raise a clean argument error
                    # that gets fed back to the model as text — giving it a chance to
                    # retry. Robustness over brittleness.
                    args = {"__raw__": args}
            calls.append(ToolCall(id=tc.get("id", ""), name=fn["name"], arguments=args))
        # msg.get("content") is the free text; may be None when the model only tool-calls.
        usage = body.get("usage", {})
        # Reasoning arrives under different keys by provider; some nest it as a dict.
        reasoning = msg.get("reasoning_content")
        if reasoning is None:
            reasoning = msg.get("reasoning")
        if isinstance(reasoning, dict):
            reasoning = reasoning.get("content") or reasoning.get("text")
        if reasoning is not None and not isinstance(reasoning, str):
            reasoning = str(reasoning)
        # WHITESPACE IS NOT REASONING. Some servers populate reasoning_content with "\n"
        # on every turn for models that are not reasoning at all (observed: Gemma 4 via
        # LM Studio). A whitespace-only string is truthy, so it used to survive as
        # "reasoning present": every step printed an empty "Reasoning (0 chars):" line
        # and the run's reasoning_turns counter climbed to the step count, turning a
        # recorded study measure into noise. Normalize to None here, once, rather than
        # at each of the places that consume it.
        if reasoning is not None and not reasoning.strip():
            reasoning = None
        return Turn(text=msg.get("content"), tool_calls=calls, raw=msg, usage=usage,
                    finish_reason=finish_reason, reasoning=reasoning or None)


# =============================================================================
# MockClient — a scripted fake model for offline testing
# =============================================================================

class MockClient:
    """A drop-in replacement for RealClient that replays a predetermined script.

    This is what makes selftest.py possible: we can prove the entire agent loop —
    request, response handling, tool dispatch, condition gating, screenshot injection,
    and logging — works correctly WITHOUT a GPU, a model, or a network connection.
    Because it exposes the same `.chat(messages, tools)` method and the same attributes
    RealClient has, the agent loop cannot tell the difference.

    The `script` is a list of callables rather than static Turns so that a mock response
    can depend on what came before — e.g. "if the previous tool result shows the build
    failed, return a turn that edits the file." Each callable receives the running
    message list and returns the next Turn.
    """

    def __init__(self, script: list[Callable[[list[dict]], Turn]]):
        self.script = list(script)        # copy so we can pop without mutating caller's
        # These attributes mirror RealClient so logging/manifest code works unchanged.
        self.model = "mock-model-v0"
        self.temperature = 0.0
        self.top_p = 1.0
        self.max_tokens = 0

    def chat(self, messages: list[dict], tools: list[dict]) -> Turn:
        """Return the next scripted Turn, ignoring `tools` (the script decides behavior).

        If the script runs out before the loop ends, we return an empty no-tool-call
        turn, which the loop interprets as "model is done" — a safe way to terminate a
        test that ran longer than scripted.
        """
        if not self.script:
            return Turn(text="(mock exhausted)", tool_calls=[])
        return self.script.pop(0)(messages)
