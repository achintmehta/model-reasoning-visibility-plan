"""
harness/tools.py
================

The agent's hands. Every action the model can take in the world is a method on the
Tools class here, and every such method has a matching JSON schema in SCHEMAS so the
model knows how to call it.

TWO LAYERS OF TOOLS
-------------------
1. BASE tools (read_file, write_file, edit_file, list_dir, finish)
   Always available in every condition. Without them the model literally cannot write
   code, so they are infrastructure, not part of the experiment.

2. VERIFICATION-SURFACE tools (run_command, run_tests, run_typecheck, run_lint, screenshot)
   These are the experimental treatment. Which of them the model may call is decided by
   the condition (see conditions.py). They let the model OBSERVE the consequences of its
   work — run it, test it, type-check it, or look at it.

A CRUCIAL SEPARATION OF CONCERNS
--------------------------------
These verification tools are what the model uses to check its work WHILE BUILDING. They
are NOT how the study grades the result. The harness always runs its own objective
evaluation afterward, against the finished workspace, identically for every condition.
So a model in the "none" condition is graded by exactly the same yardstick as one in the
"visual" condition — the condition only changes what the model could see while working,
never how the output is judged. Keeping these separate is what makes the comparison fair.

SAFETY / ROBUSTNESS PROPERTIES (all enforced here)
--------------------------------------------------
- Path containment: file operations cannot touch anything outside the workspace.
- Output truncation: a chatty command can't flood the context window.
- Command timeout: a hung process can't hang the whole run.
- Graceful errors: bad inputs come back to the model as error *text*, not exceptions,
  so the model can recover instead of the run crashing.
"""

from __future__ import annotations

import base64
import hashlib
import os
import re
import signal
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


# Maximum characters of tool output we'll feed back to the model. Beyond this we keep the
# head and tail and drop the middle (see _truncate). This protects the context window:
# e.g. a failing test suite or a verbose build can emit tens of thousands of lines, and
# dumping all of it would blow the model's context and crowd out the actual task.
MAX_OUTPUT = 6000


def _truncate(s: str) -> str:
    """Shorten long tool output to MAX_OUTPUT chars, preserving the start and end.

    The beginning and end of command output are usually the most informative parts (the
    command echoed + the final error), so we keep both halves and elide the middle with a
    marker noting how much was removed.
    """
    if len(s) <= MAX_OUTPUT:
        return s
    head = s[: MAX_OUTPUT // 2]
    tail = s[-MAX_OUTPUT // 2:]
    return f"{head}\n...[truncated {len(s) - MAX_OUTPUT} chars]...\n{tail}"


@dataclass
class ToolResult:
    """The return type of every tool method.

    Attributes:
        text:      The textual result fed back to the model as the tool's output.
        image_b64: Base64-encoded PNG, set ONLY by screenshot(). When present, the agent
                   loop injects it as a separate image message to the model, because most
                   OpenAI-compatible endpoints don't accept images inside a tool-result
                   slot. For every other tool this stays None.
    """
    text: str
    image_b64: str | None = None


def _kill_session(sid: int, sig: int = signal.SIGKILL) -> None:
    """Signal EVERY process of the session `sid` -- the session a tool command was started
    in with start_new_session=True, whose id is the command's own pid.

    plan 42 v2.5.40. Killing the command's process GROUP is not enough: a child can move to a
    group of its own and still hold the tool's pipes. GNU `timeout` does exactly that (it
    calls setpgid), so `timeout 3 bash -c '(curl -N <stream> > f &); ...' 2>&1` left a curl
    that outlived the group kill with the tool's stderr open, and the tool waited for EOF
    forever: the smoke of 2026-10-07 hung at Qwen3.6-35B-A3B's OFF message-board/interactive
    run, twice, on that call. A process stays in its session unless it calls setsid() itself,
    so the session is the right boundary. Linux /proc is read; elsewhere only the group is
    signalled, and the caller still must not wait on the pipes unboundedly."""
    try:
        os.killpg(sid, sig)
    except (ProcessLookupError, PermissionError, OSError):
        pass
    try:
        entries = os.listdir("/proc")
    except OSError:
        return
    me = os.getpid()
    for d in entries:
        if not d.isdigit() or int(d) == me:
            continue
        try:
            with open(f"/proc/{d}/stat", "rb") as f:
                stat = f.read().decode("utf-8", "replace")
            # fields after the command name: state ppid pgrp session ...
            fields = stat[stat.rfind(")") + 2:].split()
            if int(fields[3]) == sid:
                os.kill(int(d), sig)
        except (OSError, ValueError, IndexError):
            continue


def _collect_after_kill(proc) -> tuple[str, str]:
    """After a kill: collect what output there is, but never wait on the pipes for long. A
    process that left the session (setsid) can still hold them open."""
    try:
        out, err = proc.communicate(timeout=2)
        return out or "", err or ""
    except subprocess.TimeoutExpired:
        for f in (proc.stdout, proc.stderr):
            try:
                f.close()
            except Exception:  # noqa: BLE001
                pass
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass
        return "", ""


class Tools:
    """All tool implementations, bound to one workspace directory.

    One Tools instance serves one run. Every file path the model supplies is interpreted
    relative to `workspace`, and command execution happens with `workspace` as the cwd —
    so a run is sandboxed to its own directory and cannot interfere with other runs.
    """

    def __init__(self, workspace: Path, test_cmd: str = "npm test",
                 lint_cmd: str = "npm run lint", typecheck_cmd: str = "npx tsc --noEmit",
                 cmd_timeout: int = 180, screenshot_dir: Path | None = None):
        """
        Args:
            workspace:     Directory the agent reads from and writes to. Created if absent.
            test_cmd:      Shell command the run_tests tool executes. Default suits Node
                           projects; override per task if the stack differs.
            lint_cmd:      Shell command the run_lint tool executes.
            typecheck_cmd: Shell command the run_typecheck tool executes.
            cmd_timeout:   Per-command wall-clock limit in seconds. A command exceeding
                           this is killed and reported as a timeout to the model, so a
                           hung dev server or infinite loop can't stall the whole run.
            screenshot_dir:Directory to save screenshots in. Defaults to workspace.
        """
        self.ws = workspace
        self.ws.mkdir(parents=True, exist_ok=True)
        self.test_cmd = test_cmd
        self.lint_cmd = lint_cmd
        self.typecheck_cmd = typecheck_cmd
        self.cmd_timeout = cmd_timeout
        self.screenshot_dir = screenshot_dir or self.ws
        self.screenshot_dir.mkdir(parents=True, exist_ok=True)
        self.background_pids = []
        # pid -> the Popen object that started it. Kept ONLY so _live_background() can
        # call .poll() and reap the child when it dies. Without a reap the dead process
        # stays a zombie, and a zombie keeps its process group alive, so the os.killpg
        # existence check below reports a killed server as "still running" forever.
        # (Observed: a model killed its server with `ps aux | grep | kill -9`, then
        # run_background_command refused to restart it because the zombie still answered
        # the liveness probe. The model looped on kill -9 / restart for ~40 steps.)
        self._bg_procs: dict[int, subprocess.Popen] = {}
        # Persistent browser session for the interactive conditions (harness/browser.py).
        # Created lazily on the first browser_* call, so non-interactive conditions never
        # import Playwright; closed in teardown().
        self._browser_session = None
        # FILE-STATE HISTORY (plan v2.5.13; see _file_state_note). The agent loop numbers
        # every tool call it dispatches and sets call_index before each one, so the note
        # can say how many calls ago something happened. It stays None when Tools is
        # driven directly, as in the unit tests; the note then gives the count alone.
        self.call_index: int | None = None
        # (resolved path, sha256 of the bytes) -> [calls so far, call_index of the latest]
        self._file_states: dict[tuple[str, str], list] = {}
        # Per-run tallies, copied into the manifest as file_state_repeats (agent.py).
        self.file_state_repeats = {"count": 0, "writes": 0, "edits": 0, "reverts": 0,
                                   "max_times": 0}

    # -------------------------------------------------------------------------
    # Path safety
    # -------------------------------------------------------------------------
    def _resolve(self, path: str) -> Path:
        """Resolve a model-supplied path against the workspace and refuse escapes.

        The model could (accidentally or otherwise) pass something like "../../etc/passwd"
        or an absolute path. We resolve the path to its real absolute form and verify it
        still lives inside the workspace; if not, we raise. This guarantees the agent can
        never read or clobber anything outside its sandbox.
        """
        ws_resolved = self.ws.resolve()
        p = (self.ws / path).resolve()
        try:
            p.relative_to(ws_resolved)
        except ValueError:
            raise ValueError(f"path escapes workspace: {path}")
        return p

    # -------------------------------------------------------------------------
    # BASE tools — always available (file authoring + finish)
    # -------------------------------------------------------------------------
    def read_file(self, path: str) -> ToolResult:
        """Return the contents of a workspace file (truncated), or an error if missing."""
        p = self._resolve(path)
        if not p.exists():
            # Returned as text, not raised: the model can react ("oh, wrong path").
            return ToolResult(f"ERROR: no such file: {path}")
        # The dispatch in agent.py now turns any OSError into a tool result, so a
        # directory here would no longer kill the run -- but "IsADirectoryError" is a
        # diagnosis, not an instruction. Granite spent its first step of a run calling
        # read_file on the workspace root; naming the tool it wanted costs one line.
        if p.is_dir():
            return ToolResult(f"ERROR: {path} is a directory, not a file. "
                              f"Use list_dir to see what is inside it.")
        return ToolResult(_truncate(p.read_text(errors="replace")))

    # -------------------------------------------------------------------------
    # FACTUAL-FEEDBACK NOTE (applies to write_file / edit_file below)
    # -------------------------------------------------------------------------
    # Editing a file does NOT change an already-running process. Observed repeatedly
    # in real runs: a model fixes a validation bug, greps the file to confirm the old
    # text is gone, still receives the old behavior from the server it started before
    # the edit, and concludes there is "caching at the Node.js level" - one run burned
    # ~14 steps on this before thinking to restart. The harness KNOWS which background
    # processes predate the edit, so it says so.
    #
    # SCOPE DISCIPLINE: this reports an ENVIRONMENTAL fact about processes the harness
    # itself started, exactly like the EADDRINUSE hint. It says nothing about whether
    # the file's CONTENT is correct. Content validation (e.g. "your JSON is invalid")
    # would hand every arm a free syntax checker and destroy the no_verification
    # baseline - never add that here.
    def _stale_process_note(self) -> str:
        """Name background processes that were started before the edit just made."""
        live = self._live_background()
        if not live:
            return ""
        listing = "; ".join(f"PID {pid} ({cmd})" for pid, cmd in live)
        return (f"\nNOTE: background process(es) started earlier in this run are still "
                f"running: {listing}. A running process does not pick up file changes "
                f"unless it watches files or is restarted.")

    # -------------------------------------------------------------------------
    # FILE-STATE HISTORY NOTE (plan v2.5.13; applies to write_file / edit_file)
    # -------------------------------------------------------------------------
    # The no-op notes in write_file and edit_file say that ONE call changed nothing. They
    # cannot say how often that has happened, and they are silent when a file is put back
    # to content it held earlier, because then the bytes on disk DID move. In the 93 runs
    # of the September 2026 smoke sets, write_file's no-op note fired on 75 of 759 writes
    # and edit_file's on 108 of 406 edits, and neither could say how often: one run wrote
    # vite.config.js with the same content 28 times, another made the same identical-
    # string edit 31 times, and a GLM-4.7-Flash run added and removed the same <link> tag
    # with alternating edits until the cycle guard ended it -- real edits, so neither note
    # fired, and nothing in any result said the file had held that content before. So the
    # harness records the content every write or edit call leaves a file with, and when
    # that content has been there before it says how many write or edit calls have now
    # left the file with exactly this content, and how many tool calls ago the previous
    # one was.
    #
    # SCOPE DISCIPLINE, as for the notes around it: this is a fact about the tool calls
    # and the file's bytes -- exact bytes, nothing fuzzier -- and it says nothing about
    # whether the content is any good, so it adds no verification surface; and the file
    # tools are present in every condition. It describes an OUTCOME, the content a file
    # was left with, not a pattern of calls: calls that merely alternate are not flagged,
    # since alternating calls can have different outcomes. It is a note, not a guard --
    # it ends nothing -- and it reaches healthy runs too, which is acceptable only
    # because it is purely factual.
    #
    # What counts: every write_file call that wrote -- a rewrite of identical bytes
    # included, since the write still happens -- and every edit_file call that did not
    # fail: one that applied an edit, and one whose old_str and new_str were identical,
    # which leaves the file with the content it had. An edit that errored has no outcome
    # and records nothing. Content is compared as the exact bytes on disk after the call,
    # paths after resolution, so "./a.js" and "a.js" are one file. A change made by a
    # shell command is not recorded: this is the history of what the file tools left
    # behind. "Calls ago" counts every tool call the agent loop dispatched since, of any
    # kind, refused and malformed ones included, since each is a result the model sees --
    # so "1 call ago" is the immediately preceding call.
    def _file_state_note(self, p: Path, path: str, tool: str, changed: bool) -> str:
        """Record the bytes a write or edit call just left `p` with; if they recurred, say so.

        `changed` is whether this call moved the bytes on disk: a recurrence that did is a
        return to an earlier content, one that did not left the bytes as they were.
        """
        try:
            digest = hashlib.sha256(p.read_bytes()).hexdigest()
        except OSError:
            return ""                   # unreadable: say nothing rather than guess
        key = (str(p), digest)
        now = self.call_index
        entry = self._file_states.get(key)
        if entry is None:
            self._file_states[key] = [1, now]
            return ""
        times, last = entry[0] + 1, entry[1]
        self._file_states[key] = [times, now]
        tally = self.file_state_repeats
        tally["count"] += 1
        tally["writes" if tool == "write_file" else "edits"] += 1
        if changed:
            tally["reverts"] += 1
        tally["max_times"] = max(tally["max_times"], times)
        note = (f"\nNOTE: {times} write or edit calls in this run, this one included, have "
                f"left {path} with exactly this content")
        if now is not None and last is not None and now > last:
            ago = now - last
            note += f"; the previous one was {ago} call{'' if ago == 1 else 's'} ago"
        return note + "."

    def write_file(self, path: str, content: str) -> ToolResult:
        """Create or overwrite a file, creating parent directories as needed."""
        p = self._resolve(path)
        # A model can create a FILE and then try to write inside it as though it were a
        # directory. Granite did exactly that in the 2026-09-23 smoke: it wrote an empty
        # `app/server`, reasoned "I can't write directories directly", and then called
        # write_file on `app/server/index.js`. mkdir(exist_ok=True) forgives an existing
        # DIRECTORY and nothing else, so this raised FileExistsError out of the tool,
        # up through run_agent, and killed the run with a traceback.
        #
        # That is the wrong outcome twice over. The run is lost rather than continued,
        # and the loss is CAUSED BY WHAT THE MODEL CHOSE TO DO, so it lands unevenly
        # across the ladder -- 1 SEEN and 1 UNSEEN of 9 runs in that smoke. Attrition
        # correlated with the treatment is worse than attrition at random: it biases the
        # comparison rather than just shrinking it. A filesystem conflict the model
        # created belongs in the model's own transcript, as a tool error it can read and
        # recover from exactly as it would in any real agent, not in the harness's stderr.
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
        except (FileExistsError, NotADirectoryError):
            blocker = p.parent
            for anc in reversed(list(p.parents)):
                if anc.is_file():
                    blocker = anc
                    break
            try:
                shown = blocker.relative_to(self.ws.resolve()).as_posix()
            except ValueError:
                shown = blocker.name
            return ToolResult(
                f"ERROR: cannot create the parent directory for {path}: '{shown}' already "
                f"exists as a file, so it cannot also be a directory. Delete or rename it "
                f"first, or write to a different path.")
        if p.is_dir():
            return ToolResult(
                f"ERROR: {path} is an existing directory, not a file. Write to a path "
                f"inside it, or choose another name.")
        # NO-OP DETECTION, mirroring edit_file's. Rewriting a file with the bytes it
        # already holds used to report a plain "wrote N chars", which is a success
        # message for an operation that changed nothing — and a model that believes the
        # file is wrong then has no evidence against that belief, because the only thing
        # in its context after the write is a success. In the pilot, 18 of 98 write_file
        # calls rewrote identical bytes, all 18 inside runs that ended stuck_looping, and
        # this comment concluded that the note reached only the pathology. That did not
        # hold up (plan v2.5.13): in the 93 runs of the September 2026 smoke sets the note
        # fired on 75 of 759 writes, in 21 runs, 13 of which finished. It reaches healthy
        # runs too, which is acceptable only because it is a plain fact about the call.
        #
        # Like edit_file's, this reports what the TOOL CALL did — whether the bytes on
        # disk moved — NOT whether the content is any good. It is an environment fact,
        # so it does not turn the file tools into a verification surface, and the file
        # tools are present in every condition, so it cannot skew the ladder.
        #
        # The write still happens. Skipping it would preserve mtime and so silently
        # change how file-watching dev servers behave, which would be a real behavioural
        # change smuggled in behind a message change.
        unchanged = False
        if p.exists():
            try:
                unchanged = p.read_text() == content
            except (OSError, UnicodeDecodeError):
                unchanged = False       # unreadable/binary: say nothing rather than guess
        p.write_text(content)
        note = ""
        if unchanged:
            note = (f"\nNOTE: {path} already contained exactly these bytes, so its "
                    f"contents are unchanged.")
        note += self._file_state_note(p, path, "write_file", changed=not unchanged)
        return ToolResult(f"wrote {len(content)} chars to {path}"
                          + note + self._stale_process_note())

    def edit_file(self, path: str, old_str: str, new_str: str) -> ToolResult:
        """Replace a UNIQUE occurrence of old_str with new_str in a file.

        Uniqueness is enforced deliberately: if old_str appears zero times we can't edit,
        and if it appears more than once the intended target is ambiguous and a blind
        replace could corrupt the file. In both cases we return an error so the model can
        supply a more specific old_str. This mirrors how careful code-editing tools behave.
        """
        p = self._resolve(path)
        if not p.exists():
            return ToolResult(f"ERROR: no such file: {path}")
        text = p.read_text()
        n = text.count(old_str)
        if n == 0:
            return ToolResult("ERROR: old_str not found")
        if n > 1:
            return ToolResult(f"ERROR: old_str matches {n} times; make it unique")
        # NO-OP DETECTION: identical old_str/new_str rewrote the file byte-for-byte and
        # reported "edited", so a model could believe it had changed something it had
        # not. Observed several times in one real run, and it fed directly into the
        # "my fix isn't taking effect" confusion the stale-process note also addresses.
        # This reports what the TOOL CALL did, not whether the content is any good.
        # The call still leaves the file with a known content, so it goes into the
        # file-state history like any edit that did not fail (plan v2.5.13).
        if old_str == new_str:
            return ToolResult(
                f"NOTE: old_str and new_str are identical, so {path} is unchanged. "
                f"No edit was applied."
                + self._file_state_note(p, path, "edit_file", changed=False))
        p.write_text(text.replace(old_str, new_str))
        # A unique old_str replaced by a different new_str changes the file, so an edit
        # that lands on an earlier content is a return to it.
        return ToolResult(f"edited {path}"
                          + self._file_state_note(p, path, "edit_file", changed=True)
                          + self._stale_process_note())

    def list_dir(self, path: str = ".") -> ToolResult:
        """List a workspace directory; directories are suffixed with '/'."""
        p = self._resolve(path)
        if not p.exists():
            return ToolResult(f"ERROR: no such dir: {path}")
        if not p.is_dir():                      # symmetric with read_file's check
            return ToolResult(f"ERROR: {path} is a file, not a directory. "
                              f"Use read_file to see its contents.")
        entries = []
        for child in sorted(p.iterdir()):
            entries.append(child.name + ("/" if child.is_dir() else ""))
        return ToolResult("\n".join(entries) or "(empty)")

    # -------------------------------------------------------------------------
    # VERIFICATION-SURFACE tools — gated by condition (the experimental treatment)
    # -------------------------------------------------------------------------

    # -------------------------------------------------------------------------
    # Background-process bookkeeping (visible to the model via lifecycle tools)
    # -------------------------------------------------------------------------
    # DESIGN NOTE (artifact removal): an earlier version silently ran
    # `pkill -f 'npm run dev'` before any command containing "npm run dev". That hidden
    # mutation (a) only handled one command spelling, so `node server.js` / `npm start` /
    # `vite` orphans still caused EADDRINUSE fights, and (b) made the harness act on the
    # world in a way the model never requested and could not observe — an uncontrolled
    # behavior difference between runs. It is replaced by an explicit, observable surface:
    #   * list_background_commands / stop_background_command tools (model-driven cleanup)
    #   * an EADDRINUSE hint appended to failing output, listing live tracked processes
    # so port management is the MODEL's decision, uniformly across all models.

    def _register_bg(self, proc: "subprocess.Popen", label: str) -> None:
        """Track a background process for liveness checks and teardown."""
        self.background_pids.append((proc.pid, label))
        self._bg_procs[proc.pid] = proc

    def _group_members(self, pgid: int) -> list[tuple[int, str]]:
        """[(pid, state_char), ...] for every process in process-group `pgid`.

        Read straight from /proc rather than shelling out to ps: this runs on every
        liveness check. Returns [] when the group has no members, or when /proc is
        unavailable (in which case the caller falls back to the killpg probe alone).
        """
        members = []
        try:
            entries = os.listdir("/proc")
        except OSError:
            return []
        for name in entries:
            if not name.isdigit():
                continue
            try:
                with open(f"/proc/{name}/stat") as fh:
                    line = fh.read()
            except (OSError, ValueError):
                continue
            # comm (field 2) is parenthesised and may contain spaces — split after the
            # last ')' so the remaining fields are positional: state ppid pgrp ...
            try:
                rest = line[line.rindex(")") + 2:].split()
                state, pgrp = rest[0], int(rest[2])
            except (ValueError, IndexError):
                continue
            if pgrp == pgid:
                members.append((int(name), state))
        return members

    def _group_proc_states(self, pgid: int) -> list[str]:
        """State characters ('R','S','Z',...) of every process in process-group `pgid`."""
        return [st for _pid, st in self._group_members(pgid)]

    def _live_background(self) -> list[tuple[int, str]]:
        """Prune dead PIDs and return [(pid, command), ...] for still-running ones.

        "Live" has to mean *something is actually still executing*, not merely "the
        kernel still knows this pid". Two ways that used to diverge, both of which made
        the harness report a dead server as running:

          1. An unreaped child killed from outside (e.g. the model's own `kill -9`)
             becomes a zombie. os.killpg(pid, 0) on a zombie group leader SUCCEEDS.
             Fixed by poll()ing the Popen, which reaps it.
          2. A process group whose every member is a zombie still answers killpg.
             Fixed by inspecting /proc states and treating an all-zombie group as dead.
        """
        live = []
        for item in self.background_pids:
            pid, cmd = item if isinstance(item, tuple) else (item, "?")
            # Reap first: poll() collects the exit status of a child we started, which
            # removes the zombie and makes the killpg probe below tell the truth.
            proc = self._bg_procs.get(pid)
            if proc is not None:
                try:
                    proc.poll()
                except Exception:  # noqa: BLE001 - never let bookkeeping break a tool call
                    pass
            try:
                os.killpg(pid, 0)          # signal 0 = existence check for the group
            except (ProcessLookupError, PermissionError, OSError):
                self._bg_procs.pop(pid, None)
                continue
            # The group answered. Confirm at least one member is not a zombie — a group
            # made up entirely of <defunct> entries is dead in every sense the model
            # cares about, and reporting it as running is what caused the restart loop.
            states = self._group_proc_states(pid)
            if states and all(s == "Z" for s in states):
                self._bg_procs.pop(pid, None)
                continue
            live.append((pid, cmd))
        self.background_pids = [(p, c) for (p, c) in live]
        return live

    @staticmethod
    def _listen_inode_ports() -> dict[int, int] | None:
        """{socket_inode: local_port} for every LISTENing TCP socket, from /proc/net.

        Returns None if /proc/net is unreadable, so callers can tell "nothing is
        listening" apart from "I could not look" — a distinction that matters because
        the difference is reported to the model as fact.
        """
        found, readable = {}, False
        for path in ("/proc/net/tcp", "/proc/net/tcp6"):
            try:
                with open(path) as fh:
                    lines = fh.read().splitlines()[1:]      # drop the header row
            except OSError:
                continue
            readable = True
            for line in lines:
                f = line.split()
                if len(f) < 10 or f[3] != "0A":             # 0A == TCP_LISTEN
                    continue
                try:
                    found[int(f[9])] = int(f[1].rsplit(":", 1)[1], 16)
                except (ValueError, IndexError):
                    continue
        return found if readable else None

    def _listening_ports_of_group(self, pgid: int) -> list[int] | None:
        """Ports with a LISTENing socket owned by some process in group `pgid`.

        Returns [] when the group holds no listening socket, and None when no probe was
        possible at all. Earlier this shelled out to `ss` and returned [] on any failure,
        which conflates the two: on a host without iproute2 every server looked like it
        was not listening. Since that answer is now reported to the model verbatim, the
        primary path reads /proc directly (always present on Linux, no dependency) and
        `ss` remains only as a fallback for platforms where /proc/net is unavailable.
        """
        inode_ports = self._listen_inode_ports()
        if inode_ports is not None:
            members = self._group_members(pgid)
            if not members:
                return []
            ports = set()
            for pid, _state in members:
                fd_dir = f"/proc/{pid}/fd"
                try:
                    fds = os.listdir(fd_dir)
                except OSError:
                    continue                     # zombie or vanished: nothing to inspect
                for fd in fds:
                    try:
                        target = os.readlink(f"{fd_dir}/{fd}")
                    except OSError:
                        continue
                    if target.startswith("socket:["):
                        try:
                            inode = int(target[8:-1])
                        except ValueError:
                            continue
                        if inode in inode_ports:
                            ports.add(inode_ports[inode])
            return sorted(ports)
        # Fallback for non-/proc platforms.
        try:
            out = subprocess.run(["ss", "-ltnp"], capture_output=True, text=True,
                                 timeout=5).stdout
        except Exception:  # noqa: BLE001 - ss missing/odd platform: we genuinely cannot tell
            return None
        ports = set()
        for line in out.splitlines():
            for m in re.finditer(r"pid=(\d+)", line):
                try:
                    if os.getpgid(int(m.group(1))) == pgid:
                        pm = re.search(r":(\d+)\s", line)
                        if pm:
                            ports.add(int(pm.group(1)))
                except (ProcessLookupError, OSError):
                    continue
        return sorted(ports)

    def _addr_in_use_hint(self, output: str) -> str:
        """If output shows a port conflict, explain how to resolve it with the
        lifecycle tools instead of letting the model reach for pkill."""
        if not re.search(r"EADDRINUSE|address already in use", output, re.I):
            return ""
        live = self._live_background()
        if live:
            def _entry(pid, cmd):
                ports = self._listening_ports_of_group(pid)
                suffix = f" (listening on {', '.join(map(str, ports))})" if ports else ""
                return f"  PID {pid}: {cmd}{suffix}"
            listing = "\n".join(_entry(pid, cmd) for pid, cmd in live)
            return ("\nHINT: the port is already taken. Background processes you started "
                    "earlier in this run:\n" + listing +
                    "\nUse stop_background_command(pid) to stop one, or start your server "
                    "on a different port. Avoid name-based killers like `pkill -f node` — "
                    "they match this shell too and kill themselves.\n")
        return ("\nHINT: the port is already taken by a process not started in this run. "
                "Start your server on a different port.\n")
    # Common termination signals -> readable names, used to explain a signal-kill instead
    # of returning a bare "[exit -9]" that tells the model nothing.
    _SIGNAL_NAMES = {
        int(signal.SIGKILL): "SIGKILL", int(signal.SIGTERM): "SIGTERM",
        int(signal.SIGINT): "SIGINT", int(signal.SIGSEGV): "SIGSEGV",
        int(signal.SIGABRT): "SIGABRT", int(signal.SIGHUP): "SIGHUP",
        int(signal.SIGQUIT): "SIGQUIT",
    }

    def _run(self, command: str) -> ToolResult:
        """Shared helper: run a shell command in the workspace and format the result.

        Captures exit code, stdout, and stderr into a single readable block. A timeout is
        caught and reported as text rather than propagating, so one stuck command degrades
        gracefully into a recoverable error the model can see.

        Two robustness features matter here:
          * start_new_session=True runs the command in its OWN session/process group, so a
            command (or a model's stray `pkill`/`kill`) cannot signal the harness or sibling
            runs through the shared process group. NOTE: name-based killers like
            `pkill -f node` scan ALL processes by command line and can still match this
            command's own shell — which is exactly how models self-kill (see the hint below).
          * A signal-kill (returncode < 0) is explained in plain language instead of the
            baffling bare "[exit -9]", and a self-kill via `pkill/kill ... node` is called
            out specifically, because that pattern silently loops models forever otherwise.
        """
        # plan 42 v2.5.33: Popen + communicate instead of subprocess.run, so that on a
        # timeout the WHOLE process group is killed. subprocess.run(timeout=...) kills only
        # its direct child -- the `sh -c` shell -- and a server the shell started (`cd x &&
        # node index.js`) lived on in its own group, still holding its port, while this
        # tool told the model it had been "terminated". Observed 2026-10-04: a model
        # cycled for 50+ steps killing, by pid, the server each timed-out call had left
        # behind, then restarting it in the foreground again.
        proc = subprocess.Popen(
            command, shell=True, cwd=self.ws, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, start_new_session=True,
        )
        try:
            stdout, stderr = proc.communicate(timeout=self.cmd_timeout)
        except subprocess.TimeoutExpired:
            # the whole session: the shell, its children, and (v2.5.40) any that moved to
            # a process group of their own, as children of GNU `timeout` do
            _kill_session(proc.pid, signal.SIGKILL)
            try:
                proc.communicate(timeout=2)           # reap, and close the pipes
            except subprocess.TimeoutExpired:
                # A grandchild that left the group can still hold our pipes open; the
                # group itself is dead, so stop waiting on its output.
                for _f in (proc.stdout, proc.stderr):
                    try:
                        _f.close()
                    except Exception:  # noqa: BLE001
                        pass
                proc.wait(timeout=5)
            return ToolResult(
                f"ERROR: '{command}' timed out after {self.cmd_timeout}s and was "
                f"terminated, together with every process it started.\nNOTE: this tool "
                f"waits for a command to EXIT. If the "
                f"command is meant to keep running (a server, a watcher, `tail -f`, an "
                f"SSE stream), it will always time out here: use "
                f"run_background_command for servers and watchers, or "
                f"run_command_and_capture_output with a short duration to sample "
                f"output from a stream.")
        proc = subprocess.CompletedProcess(command, proc.returncode, stdout, stderr)
        out = f"$ {command}\n[exit {proc.returncode}]\n"
        # A negative returncode means the process was terminated by signal -returncode.
        if proc.returncode is not None and proc.returncode < 0:
            sig = -proc.returncode
            signame = self._SIGNAL_NAMES.get(sig, f"signal {sig}")
            out += (f"NOTE: the command was terminated by {signame} before it could "
                    f"finish, so it produced little or no output.\n")
            # The specific footgun: `pkill -f node` / `killall node` also matches the
            # shell running THIS command (its command line contains "node"), so the
            # command kills itself every time and never takes effect.
            if re.search(r"\b(pkill|killall|kill)\b[^\n]*\bnode\b", command):
                out += (
                    "HINT: this command kills processes matching \"node\" (e.g. "
                    "`pkill -f node`). The shell running this very command also has "
                    "\"node\" in its command line, so that pattern kills its own shell "
                    "and the command dies with no effect — repeating it will not help. "
                    "To stop a server, kill a specific PID, use a more specific match, "
                    "or use the run_background_command / start_server tools to manage "
                    "the server lifecycle.\n")
        if proc.stdout:
            out += "STDOUT:\n" + proc.stdout + "\n"
        if proc.stderr:
            out += "STDERR:\n" + proc.stderr + "\n"
        return ToolResult(_truncate(out))

    def run_command(self, command: str) -> ToolResult:
        """Run an arbitrary shell command (execution / visual / self_built conditions)."""
        note = ""
        if "npm create" in command and "--no-interactive" not in command:
            command += " --no-interactive"
            # The mutation is reported IN the tool result so the model (and the trace)
            # knows the executed command differs from the requested one.
            note = "NOTE: --no-interactive was appended (interactive prompts would hang).\n"
        res = self._run(command)
        return ToolResult(note + res.text + self._addr_in_use_hint(res.text),
                          res.image_b64)

    def run_background_command(self, command: str) -> ToolResult:
        """Run an arbitrary shell command in the background (returns PID).

        ARTIFACT-HYGIENE NOTE: output logs live under .agent_logs/ inside the workspace
        (still readable by the model via read_file) instead of the workspace root.
        Earlier versions wrote cmd_out_*.log next to the app's source, polluting the
        graded artifact with harness-generated files.
        """
        note = ""
        if "npm create" in command and "--no-interactive" not in command:
            command += " --no-interactive"
            note = "NOTE: --no-interactive was appended (interactive prompts would hang).\n"

        # If the identical command is already running, say so instead of silently
        # stacking a second copy that will lose the port race.
        #
        # The note CARRIES ITS EVIDENCE rather than asserting liveness. "Already running"
        # with nothing to back it is exactly the claim that misled a model whose server
        # had in fact died: it could not tell a healthy server from a stale record, so it
        # reached for `ps aux | grep | kill -9` instead of the lifecycle tools. Reporting
        # the listening port (or the absence of one) lets the model decide correctly.
        for pid, cmd in self._live_background():
            if cmd == command:
                ports = self._listening_ports_of_group(pid)
                if ports:
                    return ToolResult(
                        f"NOTE: this exact command is already running as PID {pid}, "
                        f"listening on port(s) {', '.join(map(str, ports))}. "
                        f"It was NOT started again. Use the running one, or stop it "
                        f"first with stop_background_command(pid={pid}).")
                if ports is None:
                    return ToolResult(
                        f"NOTE: this exact command is already running as PID {pid}. It "
                        f"was NOT started again. Use the running one, or stop it first "
                        f"with stop_background_command(pid={pid}).")
                return ToolResult(
                    f"NOTE: this exact command is already tracked as PID {pid}, but it "
                    f"is not listening on any port. It was NOT started again. The "
                    f"process is still alive, so it may be starting up, may have failed "
                    f"after launch, or may not be a server at all. To replace it, call "
                    f"stop_background_command(pid={pid}) and then start it again.")
        try:
            log_dir = self.ws / ".agent_logs"
            log_dir.mkdir(exist_ok=True)
            log_filename = f".agent_logs/cmd_out_{int(time.time())}.log"
            log_path = self.ws / log_filename
            log_file = open(log_path, "w")

            # Popen runs the command in the background. We use start_new_session=True
            # so it gets its own process group. Output is routed to a log file so we can
            # catch immediate errors without deadlocking on pipes.
            proc = subprocess.Popen(
                command, shell=True, cwd=self.ws,
                stdin=subprocess.DEVNULL, stdout=log_file, stderr=subprocess.STDOUT,
                start_new_session=True
            )

            # Wait briefly to see if it crashes immediately (e.g., missing npm script)
            time.sleep(1.5)
            if proc.poll() is not None and proc.returncode != 0:
                log_file.close()
                error_output = log_path.read_text(errors="replace")
                return ToolResult(
                    f"{note}ERROR: Background command '{command}' failed immediately "
                    f"with exit code {proc.returncode}.\nOutput:\n"
                    f"{_truncate(error_output)}{self._addr_in_use_hint(error_output)}")

            self._register_bg(proc, command)
            # Report which port(s) the process is serving, so the model doesn't have to
            # guess or probe — removes a whole class of "is it up yet?" churn.
            ports = self._listening_ports_of_group(proc.pid)
            if ports:
                port_note = f" Listening on port(s): {', '.join(map(str, ports))}."
            elif ports is None:
                port_note = ""      # no probe on this host: say nothing rather than guess
            else:
                port_note = (" Not listening on any port yet; check the log if you "
                             "expected a server.")
            return ToolResult(
                f"{note}Background command '{command}' started with PID {proc.pid}."
                f"{port_note} Output is logged to {log_filename} (use read_file).")
        except Exception as e:
            return ToolResult(f"ERROR: failed to start '{command}' in background: {e}")

    def list_background_commands(self) -> ToolResult:
        """List background processes started in this run, with PIDs and listening ports."""
        live = self._live_background()
        if not live:
            return ToolResult("No background commands are currently running.")
        lines = []
        for pid, cmd in live:
            ports = self._listening_ports_of_group(pid)
            if ports:
                suffix = f" [listening on {', '.join(map(str, ports))}]"
            elif ports is None:
                suffix = " [running; could not check for listening ports on this host]"
            else:
                suffix = " [running, but not listening on any port]"
            lines.append(f"PID {pid}: {cmd}{suffix}")
        return ToolResult("\n".join(lines))

    def stop_background_command(self, pid: int) -> ToolResult:
        """Stop a background process previously started with run_background_command."""
        tracked = {p for p, _ in self._live_background()}
        if pid not in tracked:
            return ToolResult(f"ERROR: PID {pid} is not a live background command of this "
                              f"run. Use list_background_commands to see what is running.")
        try:
            os.killpg(pid, signal.SIGTERM)
            time.sleep(0.5)
            try:
                os.killpg(pid, 0)
                os.killpg(pid, signal.SIGKILL)   # still alive -> force
            except (ProcessLookupError, OSError):
                pass
            _kill_session(pid, signal.SIGKILL)   # v2.5.40: and anything that left the group
            self.background_pids = [(p, c) for (p, c) in self.background_pids if p != pid]
            # Reap so the killed child does not linger as a zombie holding its process
            # group open — see _live_background().
            proc = self._bg_procs.pop(pid, None)
            if proc is not None:
                try:
                    proc.wait(timeout=2)
                except Exception:  # noqa: BLE001
                    pass
            return ToolResult(f"Stopped background PID {pid}.")
        except Exception as e:  # noqa: BLE001
            return ToolResult(f"ERROR: could not stop PID {pid}: {e}")

    def run_command_and_capture_output(self, command: str, duration: int) -> ToolResult:
        """Run a command for a maximum duration and return its captured output."""
        import os
        import signal
        try:
            proc = subprocess.Popen(
                command, shell=True, cwd=self.ws,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                start_new_session=True
            )
            try:
                stdout, stderr = proc.communicate(timeout=duration)
                out = f"$ {command}\n[exit {proc.returncode}]\n"
                if stdout:
                    out += "STDOUT:\n" + stdout + "\n"
                if stderr:
                    out += "STDERR:\n" + stderr + "\n"
                return ToolResult(_truncate(out))
            except subprocess.TimeoutExpired:
                # plan v2.5.40: SIGTERM to the whole SESSION (so streams can flush what they
                # have), then SIGKILL to whatever is left, and never an unbounded wait on the
                # pipes. Until v2.5.40 this was a group SIGTERM followed by a bare
                # communicate(), which hung forever on a child outside the group.
                _kill_session(proc.pid, signal.SIGTERM)
                try:
                    stdout, stderr = proc.communicate(timeout=2)
                except subprocess.TimeoutExpired:
                    _kill_session(proc.pid, signal.SIGKILL)
                    stdout, stderr = _collect_after_kill(proc)
                out = f"$ {command}\n[timed out after {duration}s]\n"
                if stdout:
                    out += "STDOUT (partial):\n" + stdout + "\n"
                if stderr:
                    out += "STDERR (partial):\n" + stderr + "\n"
                # Models repeatedly "sample" long-running servers this way and never get
                # anywhere (observed: a model re-ran `npm run dev` with duration=10 in a
                # loop until the run was killed). Point them at the right tool.
                out += ("NOTE: the command was still running when the time limit hit and "
                        "has been terminated. If this is a long-running process (dev "
                        "server, watcher), use run_background_command instead and read "
                        "its log file; do not re-run it here with a longer duration.\n")
                return ToolResult(_truncate(out) + self._addr_in_use_hint(out))
        except Exception as e:
            return ToolResult(f"ERROR: '{command}' failed to run: {e}")

    def teardown(self):
        """Clean up any resources tied to this Tools instance (e.g. background processes)."""
        import os
        import signal
        # Close the interactive browser session first (it may hold connections to
        # servers we are about to kill below).
        if self._browser_session is not None:
            try:
                _b = self._browser_session
                _pages = _b.pages_opened
                _b.close()
                print(f"[Tools] Closed browser session (pages opened: {_pages}, "
                      f"page restarts: {_b.page_restart_count}, "
                      f"browser restarts: {_b.restart_count})")
            except Exception as e:  # noqa: BLE001
                print(f"[Tools] Failed to close browser session: {e}")
            self._browser_session = None
        if self.background_pids:
            print(f"[Tools] Tearing down background PIDs: {self.background_pids}")
        for item in self.background_pids:
            pid = item[0] if isinstance(item, tuple) else item
            try:
                # Since start_new_session=True, the pid is also the process group ID.
                os.killpg(pid, signal.SIGTERM)
                print(f"[Tools] Successfully killed background PID {pid}")
            except Exception as e:
                print(f"[Tools] Failed to kill background PID {pid}: {e}")
            proc = self._bg_procs.pop(pid, None)
            if proc is not None:
                try:
                    proc.wait(timeout=2)      # reap; avoids leaving zombies behind
                except Exception:  # noqa: BLE001
                    pass
            # plan v2.5.40: and anything the command started that left its group, so that
            # nothing of this run outlives it (a server under `timeout`, say, holding a port
            # the next run needs).
            _kill_session(pid, signal.SIGKILL)
        self.background_pids.clear()
        self._bg_procs.clear()

    def start_server(self, port: int = 8000) -> ToolResult:
        """Start a local HTTP server rooted at the workspace and return the URL.

        WHY THIS EXISTS INSTEAD OF JUST USING run_command
        --------------------------------------------------
        Two problems plagued the naive approach (model calls run_command with
        `python3 -m http.server 8000 &`):

        1. The model doesn't know the workspace path and guesses wrong (/workspace,
           /tmp, ~, ...). This tool starts the server in the right place automatically.
        2. `subprocess.run` with `&` returns the moment the shell forks — the server
           isn't actually listening yet. This tool blocks until the port is open (up to
           3 seconds) before returning the URL, so a screenshot call immediately after
           always finds a live server.

        The model calls start_server(), gets back "http://localhost:8000", then passes
        that URL to screenshot(). No path guessing, no race condition.

        A methodological note: this tool is only offered in the VISUAL condition. It is
        part of the visual surface, not a base tool. Its existence slightly prescribes
        *how* the model verifies (via HTTP server + screenshot) but not *whether* it
        verifies or what it does after seeing the result — so the dependent variables
        (architecture, robustness, upfront investment) are unaffected.
        """
        import socket
        import sys

        # Kill anything already holding the port (e.g. a server from a previous step) so
        # repeated start_server calls don't fail.
        self._run(f"fuser -k {port}/tcp 2>/dev/null; true")

        # SAFETY BOUNDARY: launch the static server as a SUBPROCESS, never as an in-process
        # thread. The listener on `port` must be a child process — NOT the harness itself.
        # In the old in-process design, a model cleanup command like
        # `kill $(lsof -ti:PORT)` or `fuser -k PORT/tcp` resolved the port to the harness's
        # OWN pid and killed the entire run. As a subprocess in its own session, killing the
        # port stops only this child; the harness survives and the next screenshot() simply
        # reports a connection error the model can react to.
        #
        # `python -m http.server --directory <ws>` reproduces the workspace-cwd control the
        # thread used to give us, without the model needing to know the path.
        log_path = self.ws / f"http_server_{port}.log"
        log_file = open(log_path, "w")
        proc = subprocess.Popen(
            [sys.executable, "-m", "http.server", str(port), "--directory", str(self.ws)],
            cwd=str(self.ws), stdin=subprocess.DEVNULL,
            stdout=log_file, stderr=subprocess.STDOUT, start_new_session=True,
        )
        # Register for teardown using the same (pid, label) shape as background commands.
        # start_new_session=True means pid == process-group id, so teardown's os.killpg
        # cleans it up. The label is not "npm run dev", so _kill_existing_npm_run_dev skips it.
        self._register_bg(proc, f"http.server:{port}")

        # Poll until the port is open, up to 3 seconds. This is what prevents the race
        # condition — screenshot() won't be called until we return, and we don't return
        # until the server is actually accepting connections.
        deadline = time.time() + 3.0
        while time.time() < deadline:
            # If the server process died before binding (e.g. port already in use),
            # surface why instead of waiting out the full timeout.
            if proc.poll() is not None:
                log_file.flush()
                tail = log_path.read_text(errors="replace")[-500:]
                return ToolResult(f"ERROR: server on port {port} exited immediately "
                                  f"(code {proc.returncode}).\n{tail}")
            try:
                with socket.create_connection(("localhost", port), timeout=0.1):
                    break
            except OSError:
                time.sleep(0.1)
        else:
            return ToolResult(f"ERROR: server did not start on port {port} within 3s")

        url = f"http://localhost:{port}"
        return ToolResult(f"HTTP server started at {url} (serving {self.ws})")


    # -------------------------------------------------------------------------
    # check_boot — the boot_check condition's ONLY verification surface
    # -------------------------------------------------------------------------
    _ENTRY_CANDIDATES = ["server/index.js", "server.js", "server/server.js",
                         "backend/index.js", "backend/server.js", "backend/src/server.js",
                         "src/server/index.js", "server/index.mjs", "server/main.js",
                         "index.js", "app.js"]

    def _find_server_entry(self) -> str | None:
        """Locate the server entry file using a fixed, documented candidate list."""
        for c in self._ENTRY_CANDIDATES:
            p = self.ws / c
            if p.is_file():
                try:
                    txt = p.read_text(errors="replace")
                except OSError:
                    continue
                if "express" in txt or "createServer" in txt:
                    return c
        return None

    def _npm_install_all(self, timeout: int = 300) -> list[str]:
        """Run npm install for every package.json in the workspace root or one level
        deep (backend/, frontend/, ...). Returns human-readable result lines."""
        notes = []
        manifests = []
        if (self.ws / "package.json").is_file():
            manifests.append(self.ws)
        for sub in sorted(self.ws.iterdir()):
            if sub.is_dir() and sub.name not in ("node_modules", ".agent_logs") \
                    and (sub / "package.json").is_file():
                manifests.append(sub)
        if not manifests:
            return ["no package.json found - nothing to install"]
        for d in manifests:
            if (d / "node_modules").is_dir():
                notes.append(f"{d.relative_to(self.ws) or '.'}: node_modules present, skipped")
                continue
            try:
                r = subprocess.run("npm install --no-audit --no-fund", shell=True,
                                   cwd=d, capture_output=True, text=True,
                                   timeout=timeout, start_new_session=True)
                tail = (r.stdout + r.stderr).strip().splitlines()[-3:]
                notes.append(f"{d.relative_to(self.ws) or '.'}: npm install exit "
                             f"{r.returncode}" + (f" | {' / '.join(tail)}" if r.returncode else ""))
            except subprocess.TimeoutExpired:
                notes.append(f"{d.relative_to(self.ws) or '.'}: npm install timed out")
        return notes

    def check_boot(self) -> ToolResult:
        """One-shot, self-contained boot probe (the entire surface of `boot_check`).

        Fixed protocol, identical for every model and run:
          1. npm install wherever a package.json exists (root + one level deep),
             skipped where node_modules already exists.
          2. Locate the server entry from a fixed candidate list and start it.
          3. Wait up to 20s for it to LISTEN on a port, or to crash.
          4. Report: install results, entry used, port reached or the first ~50 lines
             of the crash/startup log.
          5. Always kill the process before returning — check_boot never leaves
             servers running, so repeated calls are idempotent.

        Deliberately NOT a shell: the model cannot run arbitrary commands with this,
        only learn whether its project installs and boots.
        """
        report = ["[check_boot]"]
        report += self._npm_install_all()
        entry = self._find_server_entry()
        if not entry:
            report.append("BOOT: no server entry found (looked for: "
                          + ", ".join(self._ENTRY_CANDIDATES) + ")")
            return ToolResult("\n".join(report))
        log_dir = self.ws / ".agent_logs"
        log_dir.mkdir(exist_ok=True)
        log_path = log_dir / f"check_boot_{int(time.time())}.log"
        with open(log_path, "w") as lf:
            proc = subprocess.Popen(f"node {entry}", shell=True, cwd=self.ws,
                                    stdin=subprocess.DEVNULL, stdout=lf,
                                    stderr=subprocess.STDOUT, start_new_session=True)
            port = None
            deadline = time.time() + 20
            while time.time() < deadline:
                if proc.poll() is not None:
                    break
                ports = self._listening_ports_of_group(proc.pid)
                if ports:
                    port = ports[0]
                    break
                time.sleep(0.5)
        log_head = "\n".join(
            log_path.read_text(errors="replace").splitlines()[:50])
        if port:
            report.append(f"BOOT: OK - `node {entry}` is listening on port {port}.")
            if log_head.strip():
                report.append(f"--- first lines of server log ---\n{log_head}")
        elif proc.poll() is not None:
            report.append(f"BOOT: FAILED - `node {entry}` exited with code "
                          f"{proc.returncode} before listening.")
            report.append(f"--- first lines of server log ---\n{log_head}")
        else:
            report.append(f"BOOT: TIMEOUT - `node {entry}` ran 20s without listening "
                          f"on any port.")
            if log_head.strip():
                report.append(f"--- first lines of server log ---\n{log_head}")
        # Never leave the probe process running.
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except (ProcessLookupError, OSError):
            pass
        return ToolResult(_truncate("\n".join(report)))

    # -------------------------------------------------------------------------
    # start_app — the visual_no_shell condition's harness-managed app launcher
    # -------------------------------------------------------------------------
    def start_app(self) -> ToolResult:
        """Install dependencies and start the project's own dev/start script; return URLs.

        The visual_no_shell condition's only way to get the app running: the model
        cannot run arbitrary commands, so the HARNESS starts the app by a fixed,
        documented protocol:
          1. npm install wherever needed (root + one level deep).
          2. Pick the launch command from the root package.json scripts: "dev" if
             present, else "start"; with no scripts, fall back to `node <entry>` using
             the same candidate list as check_boot.
          3. Any app previously started by start_app is stopped first (visible,
             deterministic restart semantics - calling start_app after editing code
             gives a fresh app).
          4. Wait up to 30s for listening ports and return them as URLs for
             screenshot().
        """
        report = ["[start_app]"]
        report += self._npm_install_all()
        # Stop a previously started app (restart semantics).
        for pid, cmd in list(self._live_background()):
            if cmd.startswith("start_app:"):
                try:
                    os.killpg(pid, signal.SIGTERM)
                    time.sleep(0.8)
                    os.killpg(pid, signal.SIGKILL)
                except (ProcessLookupError, OSError):
                    pass
                self.background_pids = [(p_, c_) for (p_, c_) in self.background_pids
                                        if p_ != pid]
                proc_ = self._bg_procs.pop(pid, None)
                if proc_ is not None:
                    try:
                        proc_.wait(timeout=2)     # reap; see _live_background()
                    except Exception:  # noqa: BLE001
                        pass
                report.append(f"stopped previously started app (PID {pid})")
        # Decide the launch command.
        launch = None
        pj = self.ws / "package.json"
        if pj.is_file():
            try:
                import json as _json
                scripts = _json.loads(pj.read_text()).get("scripts", {})
                if "dev" in scripts:
                    launch = "npm run dev"
                elif "start" in scripts:
                    launch = "npm start"
            except Exception:  # noqa: BLE001
                pass
        if launch is None:
            entry = self._find_server_entry()
            if entry is None:
                report.append("ERROR: no npm dev/start script and no recognizable "
                              "server entry - nothing to launch.")
                return ToolResult("\n".join(report))
            launch = f"node {entry}"
        log_dir = self.ws / ".agent_logs"
        log_dir.mkdir(exist_ok=True)
        log_rel = f".agent_logs/start_app_{int(time.time())}.log"
        lf = open(self.ws / log_rel, "w")
        proc = subprocess.Popen(launch, shell=True, cwd=self.ws,
                                stdin=subprocess.DEVNULL, stdout=lf,
                                stderr=subprocess.STDOUT, start_new_session=True)
        self._register_bg(proc, f"start_app: {launch}")
        ports: list[int] = []
        deadline = time.time() + 30
        while time.time() < deadline:
            if proc.poll() is not None:
                tail = (self.ws / log_rel).read_text(errors="replace")[-800:]
                report.append(f"ERROR: `{launch}` exited with code {proc.returncode} "
                              f"before serving.\n--- log tail ---\n{tail}")
                return ToolResult(_truncate("\n".join(report)))
            ports = self._listening_ports_of_group(proc.pid)
            if ports:
                # brief grace so a second port (vite + api) can appear too
                time.sleep(2.0)
                ports = self._listening_ports_of_group(proc.pid)
                break
            time.sleep(0.5)
        if not ports:
            report.append(f"ERROR: `{launch}` ran 30s without listening on any port. "
                          f"Log: {log_rel} (use read_file).")
            return ToolResult(_truncate("\n".join(report)))
        urls = ", ".join(f"http://localhost:{p_}" for p_ in ports)
        report.append(f"App started via `{launch}` (PID {proc.pid}). "
                      f"Serving at: {urls}. Pass one of these URLs to screenshot(). "
                      f"Log: {log_rel}. Calling start_app again restarts the app.")
        return ToolResult("\n".join(report))

    def run_tests(self) -> ToolResult:
        """Run the project's configured test command (behavioral condition)."""
        return self._run(self.test_cmd)

    def run_typecheck(self) -> ToolResult:
        """Run the configured type checker (static condition)."""
        return self._run(self.typecheck_cmd)

    def run_lint(self) -> ToolResult:
        """Run the configured linter (static condition)."""
        return self._run(self.lint_cmd)

    def screenshot(self, url: str, wait_ms: int = 5000) -> ToolResult:
        """Render a URL in headless Chromium and return a full-page screenshot.

        This is the visual condition's defining capability. The flow:
          1. Launch headless Chromium via Playwright.
          2. Navigate to `url` (the model must have already started the app — that's why
             the visual condition also includes run_command).
          3. Wait for the network to settle, then an extra `wait_ms` for late rendering.
          4. Capture a full-page PNG and return it base64-encoded.

        The PNG is returned in ToolResult.image_b64, NOT in the text. The agent loop sees
        the image and injects it to the model as a separate user-role image message,
        because tool-result slots generally can't carry images. The text just acknowledges
        the capture so the tool-result slot isn't empty.

        Failure modes (missing Playwright, page load error) return error TEXT rather than
        raising, so a broken visual run degrades into something the model can react to.
        """
        try:
            # Bypass OS validation for environments like WSL/unsupported Ubuntu
            os.environ["PLAYWRIGHT_SKIP_VALIDATE_HOST_REQUIREMENTS"] = "1"
            os.environ["PLAYWRIGHT_HOST_PLATFORM_OVERRIDE"] = "ubuntu22.04-x64"
            # Imported lazily so the harness has zero hard dependency on Playwright unless
            # a visual run actually needs it — non-visual conditions never import it.
            from playwright.sync_api import sync_playwright
        except ImportError:
            return ToolResult("ERROR: playwright not installed on run host "
                              "(pip install playwright && playwright install chromium)")
        try:
            # Same env-driven launch settings as the interactive session, so
            # HARNESS_BROWSER_HEADED makes the visual condition watchable too.
            from .browser import _launch_kwargs
            with sync_playwright() as pw:
                browser = pw.chromium.launch(**_launch_kwargs())
                page = browser.new_page(viewport={"width": 1280, "height": 800})
                page.goto(url, wait_until="networkidle", timeout=15000)
                page.wait_for_timeout(wait_ms)
                png = page.screenshot(full_page=True)
                browser.close()

            # Save the screenshot to disk
            timestamp = int(time.time())
            filename = f"screenshot_{timestamp}.png"
            screenshot_path = self.screenshot_dir / filename
            screenshot_path.write_bytes(png)
            import base64
            b64 = base64.b64encode(png).decode("ascii")
            print(f"[Tools] Screenshot saved successfully to {filename}")
            return ToolResult(f"Screenshot taken and saved to {filename}", image_b64=b64)
        except Exception as e:
            print(f"[Tools] Error taking screenshot: {e}")
            return ToolResult(f"ERROR: screenshot failed: {e}")

    # -------------------------------------------------------------------------
    # browser_* — the interactive conditions' persistent-browser tools
    # -------------------------------------------------------------------------
    # One BrowserSession per run (state persists across calls: what the model clicked
    # is still clicked on the next call). All implementation lives in
    # harness/browser.py; these thin wrappers exist so the agent loop's
    # getattr(tools, name) dispatch and the SCHEMAS registry stay uniform.

    def _get_browser(self):
        if self._browser_session is None:
            # Lazy import: zero Playwright dependency unless a browser tool is called.
            from .browser import BrowserSession
            self._browser_session = BrowserSession(artifacts_dir=self.ws / ".agent_logs")
        return self._browser_session

    def browser_navigate(self, url: str) -> ToolResult:
        """Open a URL in the persistent browser session (interactive conditions)."""
        return ToolResult(_truncate(self._get_browser().navigate(url)))

    def browser_click(self, selector: str) -> ToolResult:
        """Click an element in the current browser page (interactive conditions)."""
        return ToolResult(_truncate(self._get_browser().click(selector)))

    def browser_type(self, selector: str, text: str,
                     press_enter: bool = False) -> ToolResult:
        """Fill text into an input in the current browser page (interactive conditions)."""
        return ToolResult(_truncate(
            self._get_browser().type_text(selector, text, press_enter=press_enter)))

    def browser_drag(self, source: str, target: str) -> ToolResult:
        """Drag one element onto another in the current page (interactive conditions).

        Handles both web drag mechanisms (HTML5 native drag events and mouse-based
        drag libraries); see BrowserSession.drag for why both are needed.
        """
        return ToolResult(_truncate(self._get_browser().drag(source, target)))

    def browser_read(self, selector: str = "") -> ToolResult:
        """Return the current page's structure and new console errors (interactive)."""
        return ToolResult(_truncate(self._get_browser().read(selector or None)))

    def browser_wait(self, ms: int = 0, selector: str = "") -> ToolResult:
        """Wait for time or for an element to appear (interactive conditions)."""
        return ToolResult(_truncate(
            self._get_browser().wait(ms or None, selector or None)))

    def browser_new_page(self, url: str = "") -> ToolResult:
        """Open an additional page (tab) in the same browser and make it active."""
        return ToolResult(_truncate(self._get_browser().new_page(url or None)))

    def browser_switch_page(self, page: str) -> ToolResult:
        """Change which open page the other browser tools act on."""
        return ToolResult(_truncate(self._get_browser().switch_page(page)))

    def browser_close_page(self, page: str = "") -> ToolResult:
        """Close an open page (defaults to the active one)."""
        return ToolResult(_truncate(self._get_browser().close_page(page or None)))

    def browser_screenshot(self) -> ToolResult:
        """Capture the browser session's CURRENT page (interactive_screens condition).

        Unlike screenshot(url), this does NOT navigate: it captures the live session
        page, including any state built up by clicks and typing — which is the whole
        point of pairing sight with hands.
        """
        text, b64 = self._get_browser().screenshot(save_dir=self.screenshot_dir)
        return ToolResult(text, image_b64=b64)

    def finish(self, summary: str = "") -> ToolResult:
        """Signal that the model considers the task complete."""
        return ToolResult(f"FINISHED: {summary}")


def _schema(name, desc, props, required):
    """Build one OpenAI 'function' tool schema. Small helper to keep SCHEMAS readable."""
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": desc,
            "parameters": {"type": "object", "properties": props, "required": required},
        },
    }


SCHEMAS: dict[str, dict] = {
    "read_file": _schema("read_file", "Read a file in the workspace.",
                         {"path": {"type": "string"}}, ["path"]),
    # "Create or overwrite a file." was the whole description until 2026-09-23, and it
    # cost two runs. write_file has ALWAYS created missing parents, but only its Python
    # docstring said so -- the model was told nothing. In no_verification the tool list is
    # five entries with no shell, so a model that wants a directory has no mkdir, no
    # run_command, and no statement that writing a nested path would do it for free.
    # Granite reasoned its way to the only move left ("I can't write directories
    # directly"), wrote an empty file named `server`, then tried to write
    # `server/index.js` inside it. Correct reasoning from incomplete information: the
    # defect was ours. One sentence removes it, and it is information rather than
    # capability -- no tool is added, no condition gains an ability, and every arm reads
    # the identical text, so it cannot touch the ladder.
    "write_file": _schema("write_file",
                          "Create or overwrite a file. Any missing parent directories in "
                          "`path` are created automatically.",
                          {"path": {"type": "string"}, "content": {"type": "string"}},
                          ["path", "content"]),
    "edit_file": _schema("edit_file", "Replace a unique substring in a file.",
                         {"path": {"type": "string"}, "old_str": {"type": "string"},
                          "new_str": {"type": "string"}}, ["path", "old_str", "new_str"]),
    "list_dir": _schema("list_dir", "List a directory in the workspace.",
                        {"path": {"type": "string"}}, []),
    "run_command": _schema("run_command", "Run a shell command in the workspace and "
                           "see its stdout/stderr.", {"command": {"type": "string"}},
                           ["command"]),
    "run_background_command": _schema("run_background_command",
                                      "Run a shell command in the workspace in the background and return its PID. "
                                      "Useful for long-running processes like dev servers.",
                                      {"command": {"type": "string"}}, ["command"]),
    "run_command_and_capture_output": _schema("run_command_and_capture_output",
                                              "Run a command for a maximum duration and return its captured output. "
                                              "Useful for commands where you just want to sample output for a few seconds. "
                                              "NOT for starting servers - use run_background_command for those.",
                                              {"command": {"type": "string"}, "duration": {"type": "integer"}},
                                              ["command", "duration"]),
    "list_background_commands": _schema("list_background_commands",
                                        "List background processes you started in this run, "
                                        "with their PIDs and the ports they are listening on.",
                                        {}, []),
    "stop_background_command": _schema("stop_background_command",
                                       "Stop a background process you started earlier "
                                       "(e.g. to free its port before restarting a server).",
                                       {"pid": {"type": "integer"}}, ["pid"]),
    "check_boot": _schema("check_boot",
                          "Install dependencies and try to boot the project's server. "
                          "Reports whether it starts listening, or the crash log. "
                          "Always stops the server before returning.", {}, []),
    "start_app": _schema("start_app",
                         "Install dependencies and start the application using its own "
                         "npm dev/start script. Returns the URL(s) it is serving on, "
                         "for use with screenshot(). Calling it again restarts the app.",
                         {}, []),
    "run_tests": _schema("run_tests", "Run the project's test suite.", {}, []),
    "run_typecheck": _schema("run_typecheck", "Run the type checker.", {}, []),
    "run_lint": _schema("run_lint", "Run the linter.", {}, []),
    "start_server": _schema("start_server",
                            "Start a local HTTP server rooted at the workspace. "
                            "Returns the URL (e.g. http://localhost:8000). "
                            "Call this before screenshot() to serve your HTML files. "
                            "The server is ready to accept connections when this returns.",
                            {"port": {"type": "integer"}}, []),
    "screenshot": _schema("screenshot", "Open a URL in a browser and capture a "
                          "screenshot of the rendered page.",
                          {"url": {"type": "string"}}, ["url"]),
    "browser_navigate": _schema(
        "browser_navigate",
        "Open a URL in a persistent headless-browser session. The session keeps its "
        "state (page, JavaScript state, prior clicks and typed text) across all "
        "browser_* calls in this run. Returns the HTTP status, page title, page "
        "structure, and any console errors.",
        {"url": {"type": "string"}}, ["url"]),
    "browser_click": _schema(
        "browser_click",
        "Click an element in the browser session's current page. selector is a CSS "
        "selector (e.g. '#add-btn', 'button.save') or a text selector (e.g. "
        "'text=Add task'). Returns the updated page structure and any console errors.",
        {"selector": {"type": "string"}}, ["selector"]),
    "browser_type": _schema(
        "browser_type",
        "Clear the input/textarea matched by selector in the browser session's current "
        "page and type text into it. Set press_enter to true to press Enter afterwards "
        "(e.g. to submit). Returns the updated page structure.",
        {"selector": {"type": "string"}, "text": {"type": "string"},
         "press_enter": {"type": "boolean"}}, ["selector", "text"]),
    "browser_drag": _schema(
        "browser_drag",
        "Drag the element matched by source onto the element matched by target in "
        "the browser session's current page (e.g. moving a card between columns). "
        "Both are CSS or text selectors. Works with HTML5 draggable elements and "
        "with mouse-based drag libraries. Returns the updated page structure, "
        "reports whether the page actually changed, and when it did not, which drag "
        "events the page received.",
        {"source": {"type": "string"}, "target": {"type": "string"}},
        ["source", "target"]),
    "browser_read": _schema(
        "browser_read",
        "Return the browser session's current page structure (interactive elements "
        "and text) plus any new console errors, without performing an action. With a "
        "selector, returns just that element's content.",
        {"selector": {"type": "string"}}, []),
    "browser_wait": _schema(
        "browser_wait",
        "Wait up to ms milliseconds (default 1000, max 15000), or until the element "
        "matched by selector appears, then return the page state. Useful after "
        "starting a server or triggering a slow update.",
        {"ms": {"type": "integer"}, "selector": {"type": "string"}}, []),
    "browser_new_page": _schema(
        "browser_new_page",
        "Open an ADDITIONAL page in the same browser session and make it the active "
        "page, so a later browser_switch_page can come back to the earlier one. Pages "
        "behave like tabs of one browser: they share cookies and local storage, but "
        "each holds its own DOM, its own JavaScript state and its own open network "
        "connections. Optionally navigate the new page to url immediately. All other "
        "browser_* tools always act on the active page.",
        {"url": {"type": "string"}}, []),
    "browser_switch_page": _schema(
        "browser_switch_page",
        "Make an already-open page the active one, so subsequent browser_* calls act "
        "on it. page is a label such as 'page-1' (the labels are listed in the OPEN "
        "PAGES line of any browser result once more than one page is open). Returns "
        "that page's current structure.",
        {"page": {"type": "string"}}, ["page"]),
    "browser_close_page": _schema(
        "browser_close_page",
        "Close an open page, given its label (e.g. 'page-2'); with no argument, closes "
        "the active page. Another open page becomes active if there is one.",
        {"page": {"type": "string"}}, []),
    "browser_screenshot": _schema(
        "browser_screenshot",
        "Capture a screenshot of the browser session's CURRENT page, including any "
        "state from your clicks and typing, and return the image. Does not navigate; "
        "use browser_navigate first.",
        {}, []),
    "finish": _schema("finish", "Signal that the task is complete.",
                      {"summary": {"type": "string"}}, []),
}
