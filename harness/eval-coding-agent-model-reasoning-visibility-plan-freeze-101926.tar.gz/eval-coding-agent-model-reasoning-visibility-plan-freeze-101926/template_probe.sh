#!/usr/bin/env bash
# template_probe.sh — prove, per model, what each arm actually puts in the prompt.
#
#   ./template_probe.sh <model-key> [<model-key> ...]
#   ./template_probe.sh gemma-q4 qwen-q4 seed-q4 magistral-q4xl gptoss-20b
#
# For each model it boots llama-server on that model's GGUF, sends ONE canonical agentic
# exchange to llama.cpp's /apply-template endpoint three times — once per arm, with
# exactly the chat_template_kwargs the run wrapper sends and with reasoning_content
# present only in SEEN — and reports whether each turn's reasoning text survived into the
# rendered prompt. Then it stops the server.
#
# WHY THIS EXISTS. Rendering a template by hand answers what the TEMPLATE does; it does
# not answer what the SERVER does, and the two differ. Magistral's template has no
# reasoning_content branch at all and gpt-oss's reads a differently-named field, so
# rendering either one directly discards the reasoning and the SEEN and UNSEEN prompts
# come out byte-identical — a null treatment. llama.cpp may put the reasoning back before
# rendering (inlining [THINK] into content, or mapping reasoning_content to `thinking`),
# and only the server can say whether it does. A study whose treatment is "what the model
# can see" cannot take that on trust.
#
# Output per arm: the rendered prompt's length, whether each of the two reasoning strings
# is present, and a verdict. Prompts are written to probe-prompts/<model>.<arm>.txt so the
# diff between arms can be read directly.
#
# Environment: SERVER_EXE, PORT, SERVER_HOST, OUT_DIR (probe-prompts).

set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUNNER="${RUNNER:-$SCRIPT_DIR/run_one_with_server.sh}"
PORT="${PORT:-7777}"
SERVER_HOST="${SERVER_HOST:-192.168.1.110}"
BASE_URL="http://${SERVER_HOST}:${PORT}"
OUT_DIR="${OUT_DIR:-$SCRIPT_DIR/probe-prompts}"
SERVER_EXE_WSL="${SERVER_EXE:-/mnt/d/tools/llama-b10964-bin-win-cuda-13.3-x64/llama-server.exe}"
MODELS_ROOT_WSL="${MODELS_ROOT:-/mnt/d/llm_models/LM Studio/unsloth}"

say() { printf '[%s] %s\n' "$(date +%H:%M:%S)" "$*"; }
die() { say "FATAL: $*" >&2; exit 1; }

[ -f "$RUNNER" ] || die "cannot find $RUNNER — the model map lives there"
# Reuse the runner's own model map rather than keeping a second copy that can drift.
eval "$(sed -n '/^PLAIN_BODY=/,/^}/p' "$RUNNER")"
eval "$(sed -n '/^resolve_model()/,/^}/p' "$RUNNER")"
# think_body() too, so the probe sends the bytes the RUN sends rather than a second
# hand-maintained copy of them. The copy had already drifted: it omitted
# preserve_thinking for Gemma and Qwen, which this probe happened not to expose only
# because its canonical exchange carries no finish nudge. A probe that renders a
# different body than the run is not evidence about the run.
eval "$(awk '/^think_body\(\)/,/^}/' "$RUNNER")"

mkdir -p "$OUT_DIR"

# Same gate as run_one_with_server.sh, and for the same reason: a binary the OS refuses
# to load reports nothing, and every symptom downstream points at the model instead.
ENG_VER="$(timeout 30 "$SERVER_EXE_WSL" --version 2>&1)" || ENG_VER=""
[ -n "$ENG_VER" ] || die "engine preflight failed: '$SERVER_EXE_WSL --version' printed nothing.
     The loader is refusing the image before main() runs (exit 0xC0E90002 = Bad Image,
     typically Smart App Control blocking unsigned binaries). Check:
       reg query \"HKLM\\SYSTEM\\CurrentControlSet\\Control\\CI\\Policy\" /v VerifiedAndReputablePolicyState"
say "engine: $(printf '%s' "$ENG_VER" | head -n 1)"
[ $# -ge 1 ] || die "usage: $0 <model-key> [<model-key> ...]"

for MODEL_KEY in "$@"; do
  resolve_model "$MODEL_KEY" || die "unknown model key '$MODEL_KEY'"
  # Absolute keys bypass MODELS_ROOT (see run_one_with_server.sh) -- kept identical here
  # so the probe and the run resolve the same file.
  case "$GGUF_REL" in
    /*) GGUF_WSL="$GGUF_REL" ;;
    *)  GGUF_WSL="$MODELS_ROOT_WSL/$GGUF_REL" ;;
  esac
  [ -f "$GGUF_WSL" ] || die "model file not found: $GGUF_WSL"
  GGUF_WIN="$(wslpath -w "$GGUF_WSL")"

  # An empty OFF body means think_body() refused the arm — this model has no
  # off-switch — which is how the probe learns gpt-oss runs two arms without being
  # told a second time, in a second place, by hand.
  ARM_BODY_ON="$(think_body on 2>/dev/null)"   || ARM_BODY_ON=""
  ARM_BODY_OFF="$(think_body off 2>/dev/null)" || ARM_BODY_OFF=""

  # Refuse to start on top of an existing llama-server. Two reasons, and the second one
  # is the nasty one. The obvious: it already holds $PORT. The subtle: THIS SCRIPT'S OWN
  # cleanup ends with `taskkill /IM llama-server.exe /F`, which kills by image name, so a
  # second invocation begun while a first is still tearing down gets shot by the first --
  # and because the victim dies before writing a single line, the only evidence left is an
  # EMPTY server log and a "server died" that points at the model. Stop here instead.
  if tasklist.exe 2>/dev/null | grep -qi 'llama-server.exe'; then
    die "an llama-server.exe is already running. Let the previous probe finish its cleanup
     (it waits up to 30s, then force-kills by image name), or stop it yourself:
       taskkill.exe /IM llama-server.exe /F
     Starting now would either clash on port $PORT or be killed by the other run's cleanup,
     and the second case looks exactly like '$MODEL_KEY failed to load'."
  fi

  say "=== $MODEL_KEY ($ALIAS) — booting server"
  "$SERVER_EXE_WSL" -m "$GGUF_WIN" -c "$CTX" --alias "$ALIAS" \
      -np 1 -ngl 999 -fa on -b 2048 --cache-type-k f16 --cache-type-v f16 \
      --jinja --seed 0 --host 0.0.0.0 --port "$PORT" >"$OUT_DIR/$MODEL_KEY.server.log" 2>&1 &
  SERVER_PID=$!
  for _ in $(seq 1 240); do
    curl -sf "$BASE_URL/health" >/dev/null 2>&1 && break
    kill -0 "$SERVER_PID" 2>/dev/null || { say "server died — see $OUT_DIR/$MODEL_KEY.server.log"; break; }
    sleep 2
  done
  if ! curl -sf "$BASE_URL/health" >/dev/null 2>&1; then
    say "server never came up for $MODEL_KEY"
    # Show the reason here rather than leaving a path to go and read. The distinction that
    # matters is between "said nothing" and "said something": llama-server flushes each log
    # line as it writes it and its first line lands within a fifth of a second, so an EMPTY
    # log is not a truncated one -- it means the process never reached its own logging, and
    # the fault is in launching it, not in the model. A non-empty log that stops before
    # "listening on" is the opposite: the model is the problem.
    LOG="$OUT_DIR/$MODEL_KEY.server.log"
    if [ ! -s "$LOG" ]; then
      say "  the server log is EMPTY. llama-server produced no output at all, so it died"
      say "  before loading anything — this is not a problem with $MODEL_KEY. Run the exe"
      say "  by hand with the same flags and watch the terminal:"
      say "    \"$SERVER_EXE_WSL\" -m \"$GGUF_WIN\" -c 8192 --port $PORT --host 0.0.0.0"
      say "  Check too that nothing else holds port $PORT (tasklist.exe | grep -i llama)."
    else
      say "  last lines of $LOG:"
      tail -n 15 "$LOG" | sed 's/^/    /'
      grep -q 'listening on' "$LOG" \
        && say "  NOTE: the server DID bind. It is reachable-from-here that failed, not the"  \
        && say "  model — check the firewall on $SERVER_HOST:$PORT, or try SERVER_HOST=\$(ip route show default | awk '"'"'{print \$3}'"'"')"
    fi
    kill "$SERVER_PID" 2>/dev/null; wait "$SERVER_PID" 2>/dev/null
    continue
  fi

  THINK_PREAMBLE_KEY="${THINK_PREAMBLE_KEY:-}" REPLAY_FORMAT_KEY="${REPLAY_FORMAT_KEY:-field}" \
  ARM_BODY_ON="$ARM_BODY_ON" ARM_BODY_OFF="$ARM_BODY_OFF" \
  MODEL_KEY="$MODEL_KEY" ALIAS="$ALIAS" THINK_KIND="$THINK_KIND" \
  THINK_ON_BODY="${THINK_ON_BODY:-}" BASE_URL="$BASE_URL" OUT_DIR="$OUT_DIR" \
  python3 "$SCRIPT_DIR/template_probe.py"

  say "stopping server"
  kill "$SERVER_PID" 2>/dev/null
  for _ in $(seq 1 30); do kill -0 "$SERVER_PID" 2>/dev/null || break; sleep 1; done
  kill -0 "$SERVER_PID" 2>/dev/null && taskkill.exe /IM llama-server.exe /F >/dev/null 2>&1
  wait "$SERVER_PID" 2>/dev/null
  sleep 3
done

say "prompts written to $OUT_DIR — diff two arms to see exactly what the treatment changes:"
say "  diff <(cat $OUT_DIR/<model>.UNSEEN.txt) <(cat $OUT_DIR/<model>.SEEN.txt)"
