# Testing the interactive conditions

Two tests, in order. The first proves the tools work when the **harness** calls
them; the second proves a **model** can drive them through the agent loop. Both
are needed: the first can pass while the second fails (schema wording, gating,
briefing), and the second can pass by luck while an untested code path is broken.

All commands assume WSL, from the harness repo:

```bash
cd /mnt/d/eval-coding-agent
```

Requirements: Python 3.10+, Node, `curl`, and Playwright Chromium on this host
(`pip install playwright && playwright install chromium`). On a host where the
managed download is unavailable (e.g. aarch64), point the harness at a system
browser instead: `export HARNESS_CHROMIUM_PATH=/usr/bin/chromium`.

---

## Watching it happen (headed mode)

By default the browser is headless, which is the study configuration and why you
see nothing. To open a real window and watch the agent click, type and drag:

```bash
export HARNESS_BROWSER_HEADED=1      # visible window
export HARNESS_BROWSER_SLOWMO=500    # optional; ms between operations
```

Both work everywhere the browser is used — `test_browser_tools.py`, the
model-driven smoke run, and the `visual` condition's `screenshot` tool. Unset
them to go back to headless:

```bash
unset HARNESS_BROWSER_HEADED HARNESS_BROWSER_SLOWMO
```

`HARNESS_BROWSER_SLOWMO` defaults to 300 ms when headed (at 0 ms the actions flash
past faster than you can follow) and 0 ms when headless. Raise it to 700–1000 for
demos.

Headed mode needs a display. On WSL2 that means WSLg — check `echo $DISPLAY`
returns something non-empty. If it doesn't, the browser tools return an error
naming the problem rather than failing obscurely.

**Do not use headed mode for study runs.** A visible window renders through a
different path than headless and slow-motion changes timing, so either could move
outcomes. The harness prints a warning when they are on, and every run's manifest
records the settings under `browser`, so such runs stay mechanically identifiable:

```bash
python3 -c "import json;print(json.load(open('<run>/smoke/logs/manifest.json'))['browser'])"
# study configuration: {'headed': False, 'slow_mo_ms': 0, 'executable_path': None}
```

---

## Test 1 — mechanical (no model, no API, ~1 minute)

```bash
python3 test_browser_tools.py                              # headless
HARNESS_BROWSER_HEADED=1 python3 test_browser_tools.py     # watch it
```

Expect `ALL CHECKS PASSED`. It stands up its own pages on a free port and drives
every tool through the same `getattr(tools, name)` dispatch the agent loop uses.
Its first line reports which browser mode is in force. In headed mode, note that
the crash-recovery check closes the window on purpose near the end — that is the
test working, not a failure.

What it covers: registry sanity (every condition's tools have schemas and Tools
methods; `interactive` = execution + browser tools; `interactive_screens` adds
only `browser_screenshot`; `interactive` is NOT a vision condition); navigation
with HTTP status, title, page structure and console-error capture; **session
persistence** (clicks accumulate state across separate tool calls, and typed text
survives into later calls); text selectors; **drag on both web mechanisms** (an
HTML5 `draggable` board and a mouse-library imitation with a realistic activation
constraint); the honest "page DID NOT change" report on an undroppable target;
every error path (bad click selector, typing into a non-fillable element, waiting
for an element that never appears, both bad drag selectors, a dead server);
screenshot capture and save; **multiple pages** (see below); **crash recovery**
(page-level and browser-level, which are now distinguished); and teardown ordering.

On the multi-page half specifically: it checks that a single-page run still produces
no `OPEN PAGES:` line at all (so nothing about existing behavior moved), that state is
genuinely per-page (a click on one leaves the other's counter at 0), that labels
resolve from `page-2`, `page 2`, `2` and the integer `2` alike, and — the check the
feature exists for — it stands up its own threaded SSE broadcast server and asserts a
message posted in one page **arrives in the other over `EventSource`**, in both
directions. That page never appends optimistically, so nothing can reach its DOM
except through SSE.

Also worth running after any harness change, since both are fast and need no browser:

```bash
python3 test_loop_guards.py      # the three loop guards, incl. false-positive checks
python3 test_shell_tools.py      # factual-feedback behavior of the shell/file tools:
                                 # edit_file no-op detection, the stale-background-
                                 # process note, the run_command timeout note, and
                                 # background liveness (a server killed from outside
                                 # must be restartable, and the duplicate-command note
                                 # must name a port rather than assert health)
python3 test_agent_status.py     # truncated_no_tool_call vs stopped_no_tool_call, and
                                 # reasoning capture — including the guarantee that
                                 # reasoning is never replayed back to the model
```

---

## Test 1b — roster screening with `agent-canary` (~1 minute per model)

Run this **before** spending an hour on a real spec with an unfamiliar model. It asks
for two tiny files and the exact line the second one prints — no network, no install,
no server — so anything that goes wrong is the model or the way it is being served,
never the project environment.

```bash
MAX_STEPS=15 OPENROUTER_API_KEY=unused \
./run.sh agent-canary execution <model-id> 1 --verbose \
  --base-url "http://<host>:1234/v1" --api-key lm-studio
```

**Pass:** status `finished`, and the final summary contains
`REPORT 10 bebd11ddbd1a v<something>`. The count and digest are fixed; the Node version
varies by host and cannot be produced without actually running the program, which is
what makes the line proof of execution rather than of recall.

**Reading a failure.** The terminal status now tells you where to look:

| status | what it means | where to look |
|---|---|---|
| `truncated_no_tool_call` | the reply was cut off, not a choice to stop | `truncation_detected` in the manifest — a small `prompt_tokens` with a tiny `completion_tokens` and a large `max_tokens_requested` means the **server's** context window is binding, not the model's budget |
| `stopped_no_tool_call` | the model narrated instead of calling a tool | tool-calling support for that model/template |
| `stuck_looping` | a loop guard fired | `loop_guard_fired` for which of the three |
| `finished`, wrong REPORT line | it never ran the program | a real model result — record it |

```bash
python3 -c "
import json; m=json.load(open('/tmp/runs/final-runs/agent-canary/execution/runs/1/smoke/logs/manifest.json'))
print({k: m.get(k) for k in ('status','truncation_detected','reasoning_turns','loop_guard_fired')})"
```

Like `browser-smoke`, this is a screening task rather than a study spec — remove it
before any batch (`rm tasks/agent-canary`). It is written to a completion criterion
rather than a process mandate, so it does not prescribe verification behavior, but it is
still not one of the graded specs.

---

## Test 2 — model-driven (needs a served model, ~2–5 minutes)

```bash
./setup_browser_smoke.sh          # defaults to port 8799; pass a port to override
```

This writes a page that **requires every browser tool to complete** — a counter to
click, an input to type into, a status line that only appears after four seconds, an
HTML5 drag board, a mouse-library drag board, and a cross-page beacon — serves it, and
writes `tasks/browser-smoke` asking for exactly those actions. It prints the run
command when it finishes.

The beacon is the multi-page step, and it cannot be faked: it fires a `storage` event,
which reaches only the *other* pages of the browser, so the page that clicks Broadcast
never fills in its own box. A one-page run physically cannot make that element change.

```bash
MAX_STEPS=25 OPENROUTER_API_KEY=unused \
./run.sh browser-smoke interactive <model-id> 1 --verbose \
  --base-url "http://<host>:1234/v1" --api-key lm-studio --temperature 0.3
```

Notes on that command. `OPENROUTER_API_KEY=unused` only satisfies run.sh's
required-variable check for slash-containing model ids; the explicit `--base-url`
is what actually routes to your server. `MAX_STEPS=25` bounds the run — this task
needs about eight steps. Drop `--temperature 0.3` if your model behaves at the
study default of 0.

**What success looks like.** `browser_navigate` returns `[HTTP 200]` with a
`PAGE STRUCTURE:` block; the counter reaches 2; `alpha-widget` appears in the
list; the status line reads `STATUS: systems nominal`; both cards end up in their
right-hand columns; the second page's received box reads `RECEIVED: beacon-1`; and
teardown prints `Closed browser session (pages opened: 2, page restarts: 0, browser
restarts: 0)`.

`pages opened: 1` means the model never tried the second page — a tool-neglect result,
not a harness failure.

**Check which tools were actually used** (a model can pass by leaning on only
some of them):

```bash
python3 -c "
import json, collections
p='/tmp/runs/final-runs/browser-smoke/interactive/runs/1/smoke/logs/commands.json'
c=json.load(open(p))
print(collections.Counter(x['tool'] for x in c))
print([(x['step'], x['tool'], x['args_head'][:60]) for x in c if x['tool'].startswith('browser_')])"
```

If a browser tool never appears, that is a **model** result (tool neglect), not a
harness failure — Test 1 already proved the tool works. Record it and move on.

**Clean up before any study batch:**

```bash
rm tasks/browser-smoke
fuser -k 8799/tcp
```

`tasks/browser-smoke` prescribes behavior ("click this, drag that"), which study
specs must never do. Leaving it in `tasks/` risks it entering a batch and breaking
the tool-silent spec discipline.

---

## Test 3 — the vision variant (optional, needs a vision-capable model)

`interactive_screens` adds `browser_screenshot`, which captures the session's
current page *including* state built up by clicks and typing — unlike the
stateless `screenshot(url)` tool, which re-navigates and loses it.

```bash
MAX_STEPS=25 OPENROUTER_API_KEY=unused \
./run.sh browser-smoke interactive_screens <vision-model-id> 1 --verbose \
  --base-url "http://<host>:1234/v1" --api-key lm-studio
```

Confirm the image reached the model: the trace's `tool_result` line for
`browser_screenshot` should carry `"had_image": true`, and the following request
should contain an `image_url` message.

---

## Test 4 — grader against a locally produced artifact

The other half of the pipeline. After any real run finishes:

```bash
cd /mnt/d/eval-coding-agent-runs/grader
python3 automatic_probes.py /tmp/runs/final-runs/<task>/<condition>/runs/<n> \
  --emit-scorecards --out /tmp/probe-smoketest.jsonl --csv /tmp/probe-smoketest.csv
```

Expect one row with `boot_ok`, `functional_pct`, `fidelity_score`, `tool_uptake`
(which should show the browser calls) and a blank scorecard emitted next to the
manifest. Note that `automatic_probes.py --out` **appends** — use a scratch path
for smoke tests, never the batch's real results file.
