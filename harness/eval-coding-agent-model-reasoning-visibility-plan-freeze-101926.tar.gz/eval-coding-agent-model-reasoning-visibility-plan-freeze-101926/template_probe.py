#!/usr/bin/env python3
"""template_probe.py — ask a running llama-server to render one exchange under each arm.

Driven by template_probe.sh, which sets MODEL_KEY, ALIAS, THINK_KIND, THINK_ON_BODY,
THINK_PREAMBLE_KEY, BASE_URL and OUT_DIR and has a server up on that model's GGUF.

The question is narrow and the answer has to be bytes, not reasoning: when the SEEN arm
sends the model's own past reasoning back, does that text end up in the prompt the model
is given? /apply-template runs the request through exactly the path a real completion
takes — llama.cpp's own pre-processing, then the GGUF's Jinja template — and hands back
the string. So a "missing" verdict here is not a guess about the template, it is the
prompt the model would have been given.

Two of the five templates in this study have no slot for reasoning_content (Magistral's
has no branch for it; gpt-oss's reads a field of another name), and for those the SEEN and
UNSEEN prompts can come back byte-identical. That is a null treatment, and it is invisible
in every manifest, because the harness faithfully records that it SENT the reasoning.
"""
import difflib
import json
import os
import sys
import urllib.error
import urllib.request

R1 = "The task needs a package.json before anything else, so write that first."
R2 = "The server file comes next; it has to import express and listen on 3000."
# The assistant's own visible prose, one per turn. These are the strings Magistral's SEEN
# prompt silently LOST before the inline-think fix, so the verdict below tests for them by
# name rather than by diffing lines: these prompts are nearly one continuous line, and a
# line diff reports an insertion as a removal-plus-addition, which produced three false
# alarms the first time this check ran.
C1 = "Starting with the manifest."
C2 = "Now the server."
PREAMBLE = ("\n\nFirst draft your thinking process (inner monologue) until you arrive at "
            "a response. [MAGISTRAL-PREAMBLE]")

BASE = os.environ["BASE_URL"]
MODEL_KEY = os.environ["MODEL_KEY"]
KIND = os.environ["THINK_KIND"]
ON_BODY = os.environ.get("THINK_ON_BODY") or ""
PREAMBLE_KEY = os.environ.get("THINK_PREAMBLE_KEY") or ""
OUT = os.environ.get("OUT_DIR", ".")


REPLAY_FORMAT = os.environ.get("REPLAY_FORMAT_KEY") or "field"


NUDGE = {"role": "user",
         "content": "You did not call any tool. If the task is complete, call finish."}
# Only the ROLE matters for what this tests. Gemma's, Qwen's and Granite's templates all
# gate a past turn's visible reasoning on whether it sits after the LAST user message, so
# any user message appended to the history moves that boundary. The harness appends one --
# the finish nudge -- whenever a model returns a turn with no tool call, and it fired in 5
# of 15 SEEN runs in the 2026-09-21 smoke set.


def messages(seen: bool, preamble: bool, nudge: bool = False):
    sysmsg = "You are a software engineer. [SYSTEM]"
    if preamble:
        sysmsg += PREAMBLE
    a1 = {"role": "assistant", "content": C1,
          "tool_calls": [{"id": "c1", "type": "function",
                          "function": {"name": "write_file",
                                       "arguments": '{"path": "package.json"}'}}]}
    a2 = {"role": "assistant", "content": C2,
          "tool_calls": [{"id": "c2", "type": "function",
                          "function": {"name": "write_file",
                                       "arguments": '{"path": "server.js"}'}}]}
    if seen:
        # Mirror harness/agent.py exactly: "field" attaches reasoning_content, "inline-think"
        # rebuilds the reply the way the model emitted it and attaches no field at all.
        # Probing a route the harness does not take would test nothing.
        if REPLAY_FORMAT == "inline-think":
            a1["content"] = f"[THINK]{R1}[/THINK]" + a1["content"]
            a2["content"] = f"[THINK]{R2}[/THINK]" + a2["content"]
        else:
            a1["reasoning_content"] = R1
            a2["reasoning_content"] = R2
    msgs = [
        {"role": "system", "content": sysmsg},
        {"role": "user", "content": "Build a message board. [TASK]"},
        a1,
        {"role": "tool", "tool_call_id": "c1", "content": "wrote package.json"},
        a2,
        {"role": "tool", "tool_call_id": "c2", "content": "wrote server.js"},
    ]
    return msgs + [NUDGE] if nudge else msgs


BODY_ON = os.environ.get("ARM_BODY_ON") or ""
BODY_OFF = os.environ.get("ARM_BODY_OFF") or ""


def arm_kwargs(arm):
    """The chat_template_kwargs the RUN sends for this arm — not a second copy of them.

    template_probe.sh evaluates the wrapper's own think_body() and hands the result in, so
    exactly one place decides what an arm sends. This function used to re-implement that
    per THINK_KIND, and it had already drifted: it dropped preserve_thinking for Gemma and
    Qwen. That went unnoticed because this probe's exchange carries no finish nudge and the
    flag only bites once one exists — but a probe whose entire job is to show what the
    model is given cannot be rendering a body the model is never given. It also means a new
    model needs no edit here: Granite's truncate_history_thinking arrives by itself.
    """
    body = BODY_OFF if arm == "OFF" else BODY_ON
    if not body:
        return {}
    return (json.loads(body) or {}).get("chat_template_kwargs", {})


def render(arm, nudge=False):
    seen = arm == "SEEN"
    # Magistral's switch is the system preamble, not a template kwarg.
    preamble = bool(PREAMBLE_KEY) and arm in ("UNSEEN", "SEEN")
    body = {"messages": messages(seen, preamble, nudge),
            "tools": [{"type": "function", "function": {
                "name": "write_file", "description": "write a file",
                "parameters": {"type": "object",
                               "properties": {"path": {"type": "string"}}}}}]}
    kw = arm_kwargs(arm)
    if kw:
        body["chat_template_kwargs"] = kw
    req = urllib.request.Request(f"{BASE}/apply-template",
                                 data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read()).get("prompt", ""), kw, None
    except urllib.error.HTTPError as e:
        return None, kw, f"HTTP {e.code}: {e.read()[:200].decode('utf-8', 'replace')}"
    except (urllib.error.URLError, OSError, json.JSONDecodeError) as e:
        return None, kw, str(e)


def main():
    if not (BODY_ON or BODY_OFF):
        sys.exit("ARM_BODY_ON/ARM_BODY_OFF are unset — run this through template_probe.sh, "
                 "which reads them from the wrapper's think_body(). Rendering a guessed "
                 "body would prove nothing about the run.")
    # No OFF body means think_body() refused that arm: this model has no off-switch.
    arms = ["OFF", "UNSEEN", "SEEN"] if BODY_OFF else ["UNSEEN", "SEEN"]
    print(f"\n  replay_format={REPLAY_FORMAT}")
    print(f"  {'arm':8}{'chars':>8}{'R1':>6}{'R2':>6}   kwargs / verdict")
    print("  " + "-" * 86)
    prompts = {}
    args_missing = []
    for arm in arms:
        prompt, kw, err = render(arm)
        if err:
            print(f"  {arm:8}{'-':>8}{'-':>6}{'-':>6}   {err}")
            if "404" in err:
                print("     /apply-template is missing on this build — reading the prompt "
                      "needs a newer llama-server, or `-lv 4` and the server log.")
            continue
        prompts[arm] = prompt
        has1, has2 = R1 in prompt, R2 in prompt
        if arm == "SEEN":
            verdict = ("both turns' reasoning is in the prompt" if has1 and has2 else
                       "ONLY the latest turn's reasoning survives" if has2 else
                       "*** REASONING IS NOT IN THE PROMPT — this arm is not a treatment ***")
        else:
            verdict = "no reasoning sent, none present" if not (has1 or has2) else \
                      "*** LEAKED: reasoning present in an arm that did not send it ***"
        print(f"  {arm:8}{len(prompt):8}{str(has1):>6}{str(has2):>6}   {json.dumps(kw)}  {verdict}")
        with open(f"{OUT}/{MODEL_KEY}.{arm}.txt", "w", encoding="utf-8") as fh:
            fh.write(prompt)
        # PAST TOOL-CALL ARGUMENTS, counted rather than pattern-matched, so one check fits
        # every template's call syntax. Qwen's, Seed's and Nemotron's templates render a past
        # call's arguments only when they are a MAPPING, with no else-branch: handed the JSON
        # STRING the wire format carries, they render an empty call and raise nothing
        # (Granite's raises instead). The whole roster therefore leans on llama.cpp parsing
        # arguments into a mapping before rendering -- shown once, on Granite's probe. This
        # makes it a per-model verdict instead of an inherited assumption. In this exchange
        # 'package.json' appears once in its tool result, once in R1 when the reasoning is
        # present, and once in the call's arguments; 'server.js' once in its result and once
        # in its arguments. Nothing else mentions either file.
        a1 = prompt.count("package.json") - 1 - (1 if has1 else 0)
        a2 = prompt.count("server.js") - 1
        if a1 < 1 or a2 < 1:
            args_missing.append(arm)
            print(f"     *** {arm}: past tool-call ARGUMENTS are not in the prompt -- the model "
                  "would see its own earlier calls with no parameters. ***")

    # The primary contrast is UNSEEN -> SEEN, and "the prompts differ" is NOT the test.
    # An earlier version of this check asked only whether the two strings were identical,
    # and it passed Magistral — whose SEEN prompt differs from UNSEEN by having the
    # assistant's own prose DELETED and the reasoning never added. Different, and strictly
    # worse. A gate that reports that as "the treatment is real" is worse than no gate, so
    # the verdict now requires all three of:
    #   1. the reasoning IS in the SEEN prompt,
    #   2. it is NOT in the UNSEEN prompt,
    #   3. SEEN is a SUPERSET of UNSEEN's history — nothing the model could see in UNSEEN
    #      has gone missing in SEEN.
    if "UNSEEN" in prompts and "SEEN" in prompts:
        u, sp = prompts["UNSEEN"], prompts["SEEN"]
        has_rsn = R1 in sp and R2 in sp
        clean = R1 not in u and R2 not in u
        # Did the assistant's own prose survive? Tested by name, NOT by line diff: these
        # prompts are close to one continuous line, so an inserted thought reads as a
        # removed line plus an added one and every model looks like it lost something.
        kept_u = C1 in u and C2 in u
        kept_s = C1 in sp and C2 in sp
        swapped = kept_u and not kept_s
        # A swap is not a loss when the reasoning replaced it: harmony renders EITHER
        # content OR thinking as the analysis message, never both, so gpt-oss legitimately
        # substitutes. A loss with NO reasoning gained is the fatal case — the model sees
        # strictly less in the arm meant to show it more, which is what Magistral did.
        ok = has_rsn and clean
        print()
        if u == sp:
            print(f"  *** {MODEL_KEY}: UNSEEN and SEEN render BYTE-IDENTICAL prompts. The "
                  "primary contrast is NULL — whatever the manifest records, the server was "
                  "given the same input in both arms. ***")
        elif not has_rsn:
            print(f"  *** {MODEL_KEY}: the prompts differ ({len(sp) - len(u):+d} chars) but "
                  "the reasoning is NOT in the SEEN prompt. This is not a weaker treatment, "
                  "it is a DIFFERENT one, and the difference is not what the study claims to "
                  "manipulate. ***")
            if swapped:
                print("      Worse: the assistant's own prose is in the UNSEEN prompt and "
                      "GONE from SEEN, with nothing put in its place — the model sees "
                      "strictly LESS in the arm meant to show it more. Any effect measured "
                      "here would point the wrong way.")
        elif not clean:
            print(f"  *** {MODEL_KEY}: reasoning text is present in the UNSEEN prompt, which "
                  "should not contain it. ***")
        else:
            if swapped:
                print(f"  {MODEL_KEY}: UNSEEN -> SEEN adds {len(sp) - len(u):+d} chars and the "
                      "reasoning is present — the treatment is real. NOTE: this template "
                      "renders either the prose or the reasoning, not both, so SEEN "
                      "SUBSTITUTES rather than adds. Registered asymmetry, not a fault; in "
                      "real runs it costs little, since only 2% of this model's tool-calling "
                      "turns carry any prose at all.")
            else:
                print(f"  {MODEL_KEY}: UNSEEN -> SEEN adds {len(sp) - len(u):+d} chars, the "
                      "reasoning is present, and the assistant's own prose survives intact "
                      "— the treatment is real and purely additive.")
        # THE FLAG THAT KEEPS HISTORY IS A NO-OP UNTIL A NUDGE EXISTS. Every render above
        # has exactly one user message, so no assistant turn can fall before the last one
        # and the gate cannot fire -- which means the three rows above pass whether or not
        # preserve_thinking / truncate_history_thinking is set correctly. That is precisely
        # how the missing preserve_thinking went unseen for days. So: render SEEN again
        # with a nudge appended, and report whether the reasoning is still there.
        sn, _, err = render("SEEN", nudge=True)
        if err:
            print(f"  nudged SEEN render failed: {err}")
        else:
            kept = R1 in sn and R2 in sn
            print(f"  nudged SEEN: {'both turns still visible' if kept else 'REASONING LOST'}"
                  f" ({len(sn)} chars, {len(sn) - len(sp):+d} vs un-nudged)")
            if not kept:
                print("     *** The history flag is not doing its job. In a real run the "
                      "nudge fires whenever a model returns a turn with no tool call, and "
                      "from that point on SEEN means 'sees its reasoning since the last "
                      "nudge'. Check the flag's NAME and its POLARITY for this template "
                      "before gridding -- Gemma and Qwen want preserve_thinking TRUE, "
                      "Granite and Nemotron want truncate_history_thinking FALSE, GLM wants clear_thinking FALSE; "
                      "Muse Glimmer's published template needs no flag at all (plan v2.5.19). ***")
                ok = False
        if args_missing:
            print(f"  *** past tool-call arguments missing in: {', '.join(args_missing)} ***")
        else:
            print(f"  past tool-call arguments: rendered in every arm")
        return 0 if (ok and not args_missing) else 1
    return 0 if not args_missing else 1


if __name__ == "__main__":
    sys.exit(main())
