"""Verification that a timed-out run_command kills every process it started (plan 42 v2.5.33).

Until v2.5.33 the shell tool used subprocess.run(timeout=...), which on a timeout killed
only the `sh -c` shell: a server the command had started (`cd x && node index.js`) survived
in its own process group, still holding its port, while the tool reported it "terminated".
This check starts a foreground server that never exits, lets the call time out, and
requires the port to be free afterwards. It also checks that ordinary output, exit codes and
the signal note are unchanged, and that a child which escaped the group cannot hang the call.
"""
import os
import signal
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from harness.tools import Tools  # noqa: E402

FAILS = []


def check(cond, msg):
    print(("ok   " if cond else "FAIL ") + msg)
    if not cond:
        FAILS.append(msg)


def port_open(port):
    s = socket.socket()
    s.settimeout(0.5)
    try:
        s.connect(("127.0.0.1", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    p = s.getsockname()[1]
    s.close()
    return p


ws = Path(tempfile.mkdtemp())
(ws / "sub").mkdir()
t = Tools(workspace=ws, test_cmd=None, screenshot_dir=ws)
t.cmd_timeout = 3

port = free_port()
t0 = time.time()
r = t._run(f"cd sub && {sys.executable} -m http.server {port} --bind 127.0.0.1")
check(time.time() - t0 < 8, "a never-exiting foreground server returns at the timeout")
check("timed out" in r.text and "every process it started" in r.text,
      "the timeout message says the command and its children were terminated")
time.sleep(0.5)
check(not port_open(port), "the server's port is free after the timeout (its group was killed)")

r = t._run("echo hi; echo err 1>&2; exit 3")
check("[exit 3]" in r.text and "hi" in r.text and "err" in r.text,
      "ordinary command: exit code, stdout and stderr reported as before")
r = t._run("kill -9 $$")
check("[exit -9]" in r.text and "SIGKILL" in r.text, "signal-killed command: note unchanged")

t0 = time.time()
r = t._run("setsid sleep 37 & sleep 10")
check(time.time() - t0 < 10, "a child that left the group and holds the pipes cannot hang the call")

for line in subprocess.run(["ps", "-eo", "pid,args"], capture_output=True, text=True).stdout.splitlines():
    if "sleep 37" in line and "ps -eo" not in line:
        try:
            os.kill(int(line.split()[0]), signal.SIGKILL)
        except (ValueError, ProcessLookupError, PermissionError):
            pass

print("\nALL CHECKS PASSED" if not FAILS else f"\n{len(FAILS)} CHECK(S) FAILED")
sys.exit(1 if FAILS else 0)
