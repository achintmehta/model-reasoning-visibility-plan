"""Verification of the finish nudge after every turn without a tool call (plan v2.5.14).

Run:  python3 test_nudges.py

Every turn without a tool call gets the same nudge; a run ends as stopped_no_tool_call only
when the reply right after a nudge has no tool call either. Truncated and runaway replies
still end the run at once, un-nudged. The manifest records finish_nudges (a count) and
finish_nudge_steps (the step of every nudge).

No model, no network, no browser - just run_agent with a scripted client.
"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from harness.agent import run_agent, build_messages
from harness.llm import ToolCall, Turn
from harness.runlog import RunLog
from harness.tools import Tools

FAILURES = []
NUDGE = ("You did not call any tool. If the task is complete, call the finish tool now; "
         "otherwise continue working using the provided tools.")


def check(name, cond, detail=""):
    print(f"[{'ok ' if cond else 'FAIL'}] {name}" + (f"  -- {detail}" if not cond else ""))
    if not cond:
        FAILURES.append(name)


class ScriptedClient:
    """Returns whatever Turn `fn(step_number)` asks for, recording what it was sent."""

    max_tokens = 32768

    def __init__(self, fn):
        self.fn, self.n = fn, 0
        self.seen = []

    def chat(self, messages, schemas):
        self.n += 1
        self.seen.append([dict(m) for m in messages])
        return self.fn(self.n)


def silent(n):
    return Turn(text="", raw={}, finish_reason="stop", tool_calls=[],
                usage={"prompt_tokens": 1, "completion_tokens": 1})


def prose(n):
    return Turn(text="The app is done: it has a server and a client.", raw={},
                finish_reason="stop", tool_calls=[],
                usage={"prompt_tokens": 1, "completion_tokens": 1})


def work(n):
    return Turn(text="", raw={}, finish_reason="tool_calls",
                usage={"prompt_tokens": 1, "completion_tokens": 1},
                tool_calls=[ToolCall(id=f"c{n}", name="write_file",
                                     arguments={"path": f"f{n}.txt", "content": f"v{n}"})])


def finish(n):
    return Turn(text="", raw={}, finish_reason="tool_calls",
                usage={"prompt_tokens": 1, "completion_tokens": 1},
                tool_calls=[ToolCall(id=f"c{n}", name="finish", arguments={"summary": "done"})])


def drive(script, max_steps=30):
    """script: step number -> Turn factory; returns (status, extra, client, messages)."""
    d = Path(tempfile.mkdtemp())
    tools = Tools(workspace=d / "ws")
    log = RunLog(d / "logs", {"condition": "execution"})
    client = ScriptedClient(lambda n: script(n)(n))
    messages = build_messages("task", str(d / "ws"))
    try:
        status, extra = run_agent(client, tools, "execution", messages, log,
                                  max_steps=max_steps)
        return status, extra, client, messages
    finally:
        tools.teardown()
        log.trace.close()


def nudges_in(messages):
    return [m for m in messages if m.get("role") == "user" and m.get("content") == NUDGE]


# ---- 1. isolated silences are all nudged, and the run carries on ------------------------
plan = {1: silent, 2: work, 3: silent, 4: work, 5: silent, 6: work, 7: finish}
status, extra, client, messages = drive(lambda n: plan[n])
check("isolated silences: the run finishes", status == "finished", status)
check("isolated silences: every one is nudged", extra.get("finish_nudges") == 3,
      str(extra.get("finish_nudges")))
check("isolated silences: the steps of the nudges are recorded",
      extra.get("finish_nudge_steps") == [1, 3, 5], str(extra.get("finish_nudge_steps")))
check("isolated silences: three nudges in the conversation", len(nudges_in(messages)) == 3,
      str(len(nudges_in(messages))))
check("each nudge is what the next request ends with",
      len(client.seen) > 5
      and all(client.seen[s][-1].get("content") == NUDGE for s in (1, 3, 5)),
      str([client.seen[s][-1].get("content", "")[:40] for s in (1, 3, 5)
           if s < len(client.seen)]))

# ---- 2. two in a row end the run --------------------------------------------------------
status, extra, client, messages = drive(lambda n: silent)
check("silent, nudge, silent -> stopped_no_tool_call", status == "stopped_no_tool_call",
      status)
check("two in a row: one nudge, at step 1", extra.get("finish_nudges") == 1
      and extra.get("finish_nudge_steps") == [1], str(extra.get("finish_nudge_steps")))
check("two in a row: the run ends at step 2", client.n == 2, str(client.n))

# ---- 3. working between silences, then two in a row ------------------------------------
plan = {1: silent, 2: work, 3: work, 4: silent, 5: silent}
status, extra, client, messages = drive(lambda n: plan[n])
check("work, then two in a row -> stopped_no_tool_call", status == "stopped_no_tool_call",
      status)
check("work, then two in a row: nudged at steps 1 and 4",
      extra.get("finish_nudge_steps") == [1, 4], str(extra.get("finish_nudge_steps")))
check("work, then two in a row: ends at step 5", client.n == 5, str(client.n))

# ---- 4. a reply in prose counts the same as a silent one --------------------------------
plan = {1: prose, 2: work, 3: prose, 4: finish}
status, extra, client, messages = drive(lambda n: plan[n])
check("prose without a call is nudged and the run goes on", status == "finished", status)
check("prose without a call: nudged at steps 1 and 3",
      extra.get("finish_nudge_steps") == [1, 3], str(extra.get("finish_nudge_steps")))
plan = {1: prose, 2: finish}
status, extra, _, _ = drive(lambda n: plan[n])
check("a narrated summary, the nudge, then finish -> finished", status == "finished", status)

# ---- 5. many separated silences: no limit ------------------------------------------------
plan = {n: (silent if n % 2 else work) for n in range(1, 21)}
plan[21] = finish
status, extra, _, _ = drive(lambda n: plan[n])
check("ten separated silences: all nudged, the run finishes",
      status == "finished" and extra.get("finish_nudges") == 10,
      f"{status} {extra.get('finish_nudges')}")

# ---- 6. a run that never goes quiet is never nudged ---------------------------------------
plan = {1: work, 2: work, 3: finish}
status, extra, _, messages = drive(lambda n: plan[n])
check("no silence: no nudge, empty step list",
      extra.get("finish_nudges") == 0 and extra.get("finish_nudge_steps") == []
      and not nudges_in(messages), str(extra.get("finish_nudge_steps")))

# ---- 7. truncated and runaway replies still end the run at once, un-nudged ------------------
status, extra, _, _ = drive(lambda n: (lambda k: Turn(
    text="", raw={}, finish_reason="length", tool_calls=[],
    usage={"prompt_tokens": 4041, "completion_tokens": 55})))
check("truncation still ends the run on the first bad turn",
      status == "truncated_no_tool_call" and extra.get("finish_nudges") == 0,
      f"{status} {extra.get('finish_nudges')}")
plan = {1: silent, 2: work}
status, extra, _, _ = drive(lambda n: plan.get(n) or (lambda k: Turn(
    text="x " * 10, raw={}, finish_reason="length", tool_calls=[],
    usage={"prompt_tokens": 100, "completion_tokens": 32768})))
check("a runaway after a nudged silence ends the run as a runaway",
      status == "runaway_no_tool_call" and extra.get("finish_nudge_steps") == [1],
      f"{status} {extra.get('finish_nudge_steps')}")

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILURE(S): " + ", ".join(FAILURES))
    sys.exit(1)
print("ALL CHECKS PASSED")
