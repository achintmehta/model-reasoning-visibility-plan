"""
harness/runlog.py
=================

Per-run logging — the evidentiary backbone of the study.

WHY THIS MATTERS MORE THAN IT LOOKS
-----------------------------------
The central claim of the experiment is "the ONLY thing that differed between conditions
was the verification surface." A claim like that is only credible if it can be checked,
not merely asserted. This module records, for every run, the complete model-facing input
and the full interaction trace, so that after a batch you can mechanically PROVE that the
system prompt and the task were byte-identical across all conditions, and that the sole
difference was the allowed tool set. (verify_inputs.py does that proof using the hashes
written here.)

The motivating cautionary tale: in earlier work an off-the-shelf agent turned out to be
injecting a hidden system prompt that silently changed the output. The defense against
that class of error is to log your own inputs exhaustively and diff them — making it
impossible for a hidden difference to go unnoticed.

WHAT EACH RUN PRODUCES (in its --run-dir)
-----------------------------------------
- manifest.json : a one-object summary of the run's identity and outcome (model, condition,
                  allowed tools, decoding params, prompt hashes, status, step count, ...).
- trace.jsonl   : one JSON object per line, one line per loop event (each request sent,
                  each response received, each tool result). The complete play-by-play.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path


def sha(text: str) -> str:
    """Return a short, stable SHA-256 hex digest of a string.

    Used to fingerprint the system prompt and the task prompt. Two runs with the same
    fingerprint provably received the same text. We truncate to 16 hex chars — plenty to
    rule out accidental collisions for this purpose, and easier to eyeball in a manifest.
    """
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


class RunLog:
    """Writes manifest.json and trace.jsonl for a single run.

    Lifecycle:
        log = RunLog(run_dir, manifest)     # opens trace.jsonl, stamps start time
        log.log_request(...)                 # called once per loop iteration
        log.log_response(...)
        log.log_tool_result(...)             # zero or more per iteration
        ...
        log.finalize(status)                 # writes manifest.json, closes trace
    """

    def __init__(self, run_dir: Path, manifest: dict):
        """
        Args:
            run_dir:  Directory to write logs into (created if absent).
            manifest: The initial manifest dict (model, condition, hashes, etc.). We add
                      timing/status/step fields to it over the run's life and write it out
                      in finalize().
        """
        self.dir = run_dir
        self.dir.mkdir(parents=True, exist_ok=True)
        # trace.jsonl is opened now and appended to line-by-line as the run proceeds, so
        # that even if a run crashes mid-way, the partial trace up to the failure survives.
        self.trace = (self.dir / "trace.jsonl").open("w")
        self.manifest = dict(manifest)             # copy; we mutate our own version
        self.manifest["started_at"] = time.time()
        self.step = 0                              # incremented once per request

    def log_request(self, messages: list[dict], tools: list[dict]):
        """Record one request to the model: the FULL message list plus the tool NAMES
        offered this step. Logging the entire message list (not a summary) is what makes
        the 'identical inputs' claim verifiable after the fact."""
        self.step += 1
        self._write({"kind": "request", "step": self.step,
                     "messages": messages,
                     "tools": [t["function"]["name"] for t in tools]})

    def log_response(self, raw: dict | None, text: str | None, calls: list):
        """Record one model response: its text, the parsed tool calls (name + args), and
        the provider's raw message object for a complete audit trail."""
        self._write({"kind": "response", "step": self.step, "text": text,
                     "tool_calls": [{"name": c.name, "arguments": c.arguments}
                                    for c in calls],
                     "raw": raw})

    def log_tool_result(self, name: str, result_text: str, had_image: bool):
        """Record the outcome of executing one tool call: which tool, its text result, and
        whether it also produced an image (a screenshot)."""
        self._write({"kind": "tool_result", "step": self.step, "tool": name,
                     "result": result_text, "had_image": had_image})

    def _write(self, obj: dict):
        """Append one JSON object as a line to trace.jsonl and flush immediately.

        Flushing after every write trades a little speed for durability: the trace on disk
        is always current, so a crashed or killed run still leaves a faithful partial log.
        """
        self.trace.write(json.dumps(obj) + "\n")
        self.trace.flush()

    def finalize(self, status: str, extra: dict | None = None):
        """Close out the run: stamp end time, status, and step count, optionally merge in
        extra fields, write manifest.json, and close the trace file.

        Args:
            status: Terminal status of the run — "finished" (model called finish),
                    "stopped_no_tool_call" (model returned no tool call), or
                    "budget_exhausted" (hit the step cap).
            extra:  Optional extra manifest fields (e.g. evaluation metrics) to record.
        """
        self.manifest["ended_at"] = time.time()
        self.manifest["status"] = status
        self.manifest["steps"] = self.step
        if extra:
            self.manifest.update(extra)
        (self.dir / "manifest.json").write_text(json.dumps(self.manifest, indent=2))
        self.trace.close()
