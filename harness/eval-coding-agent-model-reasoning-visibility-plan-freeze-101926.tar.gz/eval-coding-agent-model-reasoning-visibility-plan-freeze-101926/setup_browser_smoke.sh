#!/usr/bin/env bash
# =============================================================================
# setup_browser_smoke.sh - stand up the model-driven smoke test for the
# interactive conditions (browser_navigate / _read / _click / _type / _drag /
# _wait / _new_page / _switch_page).
#
# WHY THIS EXISTS
# ---------------
# test_browser_tools.py proves the tools work when the HARNESS calls them.
# It cannot prove that a MODEL can drive them through the agent loop. This script
# stands up a page that requires every browser tool to complete, plus a task file
# that asks for exactly those actions, so one short run exercises the whole path
# end to end.
#
# The page deliberately contains BOTH drag mechanisms (HTML5 native and a
# mouse-library imitation with an activation constraint), because browser_drag
# takes a different code path for each.
#
# The cross-page beacon (section 6) fires a storage event, which reaches only the
# OTHER pages of the browser. A one-page run physically cannot make that element
# change, so it is a real test of browser_new_page / browser_switch_page rather
# than something a model can satisfy by narrating.
#
# WARNING - NOT A STUDY SPEC. tasks/browser-smoke prescribes behavior ("click
# this, drag that"), which is exactly what study specs must never do. It exists to
# test the instrument. Delete it (or keep it out of tasks/) before any real batch;
# run.sh's cleanup line at the bottom of this script does that for you.
#
# Usage:   ./setup_browser_smoke.sh [PORT]     (default 8799)
# =============================================================================
set -euo pipefail

PORT="${1:-8799}"
SITE="/tmp/smoke-site"
REPO="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$SITE"

cat > "$SITE/index.html" <<'HTML'
<!doctype html>
<html><head><meta charset="utf-8"><title>Harness Smoke Page</title>
<style>
 body{font-family:system-ui,sans-serif;margin:24px;max-width:900px}
 ul.board{min-height:80px;width:200px;border:1px solid #999;display:inline-block;
   vertical-align:top;margin:8px;padding:8px;list-style:none}
 ul.board li{background:#eee;padding:8px;margin:4px;cursor:grab}
 section{margin-bottom:28px}
</style></head>
<body>
<h1>Harness Smoke Page</h1>

<section id="counter-section">
  <h2>1. Click</h2>
  <button id="inc">Increment</button> <span id="count">0</span>
</section>

<section id="items-section">
  <h2>2. Type</h2>
  <input id="new-item" placeholder="new item name">
  <button id="add">Add item</button>
  <ul id="list"></ul>
</section>

<section id="delayed-section">
  <h2>3. Wait</h2>
  <div id="delayed-slot"><em>a status line appears here a few seconds after load</em></div>
</section>

<section id="html5-section">
  <h2>4. Drag (HTML5 native)</h2>
  <ul id="col-a" class="board col"><li id="card1" draggable="true">Card One</li></ul>
  <ul id="col-b" class="board col"></ul>
</section>

<section id="mouse-section">
  <h2>5. Drag (mouse-based library)</h2>
  <ul id="mcol-a" class="board mcol"><li id="mcard1" class="mcard">Mouse Card</li></ul>
  <ul id="mcol-b" class="board mcol"></ul>
</section>

<section id="beacon-section">
  <h2>6. Two pages</h2>
  <button id="broadcast">Broadcast</button>
  <div id="received">nothing received</div>
</section>

<script>
// --- click ------------------------------------------------------------------
let n = 0;
document.getElementById('inc').onclick = () => {
  n += 1; document.getElementById('count').textContent = String(n);
};

// --- type + add -------------------------------------------------------------
document.getElementById('add').onclick = () => {
  const v = document.getElementById('new-item').value.trim();
  if (!v) return;
  const li = document.createElement('li');
  li.textContent = v;
  document.getElementById('list').appendChild(li);
  document.getElementById('new-item').value = '';
};

// --- cross-page beacon (requires browser_new_page + browser_switch_page) ----
// The storage event fires ONLY in the OTHER pages of the same browser context, so
// #received can never be filled in by the page that clicked Broadcast. A single-page
// run cannot make this element change, which is what makes it a real multi-page check
// (and it doubles as proof that pages share one context, like tabs).
window.addEventListener('storage', (e) => {
  if (e.key === 'smoke-beacon') {
    document.getElementById('received').textContent = 'RECEIVED: ' + e.newValue;
  }
});
document.getElementById('broadcast').onclick = () => {
  const n = Number(localStorage.getItem('smoke-beacon-n') || 0) + 1;
  localStorage.setItem('smoke-beacon-n', String(n));
  localStorage.setItem('smoke-beacon', 'beacon-' + n);
};

// --- delayed element (requires browser_wait, or patience) -------------------
setTimeout(() => {
  const d = document.createElement('p');
  d.id = 'delayed';
  d.textContent = 'STATUS: systems nominal';
  document.getElementById('delayed-slot').appendChild(d);
}, 4000);

// --- HTML5 native drag and drop --------------------------------------------
document.querySelectorAll('[draggable=true]').forEach(el => {
  el.addEventListener('dragstart', e => e.dataTransfer.setData('text/plain', el.id));
});
document.querySelectorAll('.col').forEach(col => {
  col.addEventListener('dragover', e => e.preventDefault());
  col.addEventListener('drop', e => {
    e.preventDefault();
    const id = e.dataTransfer.getData('text/plain');
    if (id) col.appendChild(document.getElementById(id));
  });
});

// --- mouse-based drag with an activation constraint -------------------------
// Mirrors SortableJS / dnd-kit style behavior: needs real travel AND several
// distinct mousemove events before it treats the motion as a drag.
let dragging = null, sx = 0, sy = 0, moves = 0, active = false;
document.querySelectorAll('.mcard').forEach(el => {
  el.addEventListener('mousedown', e => {
    dragging = el; sx = e.clientX; sy = e.clientY; moves = 0; active = false;
  });
});
document.addEventListener('mousemove', e => {
  if (!dragging) return;
  moves++;
  if (Math.hypot(e.clientX - sx, e.clientY - sy) > 8 && moves >= 3) active = true;
});
document.addEventListener('mouseup', e => {
  if (dragging && active) {
    const el = document.elementFromPoint(e.clientX, e.clientY);
    const col = el && el.closest('.mcol');
    if (col) col.appendChild(dragging);
  }
  dragging = null; active = false;
});
</script>
</body></html>
HTML

cat > "$REPO/tasks/browser-smoke" <<TASK
A web page is already running at http://localhost:${PORT} and you do not need to
write, install, or start anything. Using the browser tools available to you,
carry out the following and report what you observed after each step:

1. Open the page.
2. Click the "Increment" button twice and report the number shown beside it.
3. Type "alpha-widget" into the item input, click "Add item", and report the
   contents of the list.
4. Report the status line that appears in the "Wait" section a few seconds after
   the page loads.
5. In the "Drag (HTML5 native)" section, move "Card One" from the left column
   (#col-a) into the right column (#col-b), then report which column it is in.
6. In the "Drag (mouse-based library)" section, move "Mouse Card" from #mcol-a
   into #mcol-b, then report which column it is in.
7. Open a second browser page on the same URL. Return to the first page and click
   the "Broadcast" button there. Then go back to the second page and report the
   text shown in its "received" box. (The box only ever fills in on a page that
   was already open when another page broadcast, so this cannot be done with one
   page.)

Then call finish with a one-line summary of what you observed.
TASK

# Serve the page (kill any previous instance on this port first).
if command -v fuser >/dev/null 2>&1; then fuser -k "${PORT}/tcp" >/dev/null 2>&1 || true; fi
sleep 0.3
nohup python3 -m http.server "$PORT" --directory "$SITE" >/dev/null 2>&1 &
sleep 1

if curl -sf "http://localhost:${PORT}/" >/dev/null; then
  echo "Smoke page serving at http://localhost:${PORT}  (files in $SITE)"
else
  echo "ERROR: page is not serving on port ${PORT}" >&2; exit 1
fi

cat <<EOF

Task file written: ${REPO}/tasks/browser-smoke

Run it (adjust model / base-url):

  MAX_STEPS=25 OPENROUTER_API_KEY=unused \\
  ./run.sh browser-smoke interactive devstral-small-2-24b-instruct-2512 1 --verbose \\
    --base-url "http://192.168.1.110:1234/v1" --api-key lm-studio --temperature 0.3

To WATCH the agent work in a real browser window, prefix the run with:

  HARNESS_BROWSER_HEADED=1 HARNESS_BROWSER_SLOWMO=500 \\

(headed mode needs a display - WSLg on WSL2, i.e. \$DISPLAY non-empty - and is for
debugging only; every manifest records the setting under "browser").

When finished, take the smoke task back out of tasks/ so it can never enter a
study batch:

  rm ${REPO}/tasks/browser-smoke
  fuser -k ${PORT}/tcp

EOF
