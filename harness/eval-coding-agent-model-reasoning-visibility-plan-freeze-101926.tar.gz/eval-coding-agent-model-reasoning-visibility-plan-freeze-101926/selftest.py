"""Offline self-test. No network, no GPU. Drives the real agent loop with a scripted
mock model to prove: the loop runs, tools execute, condition gating blocks
out-of-condition tools, screenshots inject as image turns, and logs are written."""

import json
import shutil
import tempfile
from pathlib import Path

from harness.agent import run_agent, build_messages, SYSTEM_PROMPT_TEMPLATE
from harness.llm import MockClient, Turn, ToolCall
from harness.runlog import RunLog, sha
from harness.tools import Tools
from harness.conditions import tools_for


def call(name, **args):
    return ToolCall(id=f"c_{name}", name=name, arguments=args)


def test_execution_condition():
    """Model writes a file, runs it, then finishes — under the 'execution' surface."""
    tmp = Path(tempfile.mkdtemp())
    ws, run = tmp / "ws", tmp / "run"

    script = [
        lambda m: Turn(tool_calls=[call("write_file", path="hello.py",
                                        content="print('hi from agent')")]),
        lambda m: Turn(tool_calls=[call("run_command", command="python3 hello.py")]),
        lambda m: Turn(text="done", tool_calls=[call("finish", summary="wrote and ran hello.py")]),
    ]
    client = MockClient(script)
    tools = Tools(workspace=ws)
    log = RunLog(run, {"model": client.model, "condition": "execution",
                       "allowed_tools": tools_for("execution"),
                       "system_prompt_sha": sha(SYSTEM_PROMPT_TEMPLATE)})
    status, extra = run_agent(client, tools, "execution", build_messages("write hello.py and run it"),
                       log, max_steps=10)
    log.finalize(status, extra=extra)

    assert status == "finished", status
    assert (ws / "hello.py").exists(), "file not written"
    trace = [json.loads(l) for l in (run / "trace.jsonl").read_text().splitlines()]
    ran = [t for t in trace if t.get("tool") == "run_command"]
    assert ran and "hi from agent" in ran[0]["result"], "command did not execute"
    print("PASS execution: file written, command ran, log captured", status)
    shutil.rmtree(tmp)


def test_gating_blocks_out_of_condition_tool():
    """Under 'none', the model is not even offered run_command; if it hallucinates a
    call to it, the loop must refuse rather than execute."""
    tmp = Path(tempfile.mkdtemp())
    ws, run = tmp / "ws", tmp / "run"

    script = [
        # model tries to use a tool it was never given
        lambda m: Turn(tool_calls=[call("run_command", command="echo SHOULD_NOT_RUN")]),
        lambda m: Turn(tool_calls=[call("finish", summary="giving up")]),
    ]
    client = MockClient(script)
    tools = Tools(workspace=ws)
    log = RunLog(run, {"condition": "none", "allowed_tools": tools_for("none")})
    status, extra = run_agent(client, tools, "none", build_messages("do nothing risky"), log, max_steps=10)
    log.finalize(status, extra=extra)

    trace = [json.loads(l) for l in (run / "trace.jsonl").read_text().splitlines()]
    blocked = [t for t in trace if t.get("tool") == "run_command"]
    assert blocked and blocked[0]["result"].startswith("ERROR: tool 'run_command' not available"), \
        "gating failed — out-of-condition tool was executed!"
    # offered tool list must not include run_command
    req = next(t for t in trace if t["kind"] == "request")
    assert "run_command" not in req["tools"], "run_command leaked into offered tools"
    print("PASS gating: out-of-condition tool refused and not offered")
    shutil.rmtree(tmp)


def test_edit_and_list():
    tmp = Path(tempfile.mkdtemp())
    ws, run = tmp / "ws", tmp / "run"
    script = [
        lambda m: Turn(tool_calls=[call("write_file", path="a.txt", content="foo bar")]),
        lambda m: Turn(tool_calls=[call("edit_file", path="a.txt", old_str="foo", new_str="baz")]),
        lambda m: Turn(tool_calls=[call("list_dir", path=".")]),
        lambda m: Turn(tool_calls=[call("finish")]),
    ]
    client = MockClient(script)
    tools = Tools(workspace=ws)
    log = RunLog(run, {"condition": "none"})
    status, extra = run_agent(client, tools, "none", build_messages("edit test"), log, max_steps=10)
    log.finalize(status, extra=extra)
    assert (ws / "a.txt").read_text() == "baz bar", (ws / "a.txt").read_text()
    print("PASS edit/list: edit applied correctly")
    shutil.rmtree(tmp)


if __name__ == "__main__":
    test_execution_condition()
    test_gating_blocks_out_of_condition_tool()
    test_edit_and_list()
    print("\nALL SELF-TESTS PASSED")
